"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asyncLocalStorage = void 0;
exports.getContext = getContext;
exports.setUserId = setUserId;
const node_async_hooks_1 = require("node:async_hooks");
exports.asyncLocalStorage = new node_async_hooks_1.AsyncLocalStorage();
function getContext() {
    return exports.asyncLocalStorage.getStore() ?? {};
}
function setUserId(userId) {
    const context = exports.asyncLocalStorage.getStore();
    if (context) {
        context.userId = userId;
    }
}

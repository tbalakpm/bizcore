"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const pino_1 = __importDefault(require("pino"));
const rfs = __importStar(require("rotating-file-stream"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const config_1 = require("../../config");
let loggerInstance;
if (config_1.config.isDevelopment) {
    const logDir = path_1.default.join(process.cwd(), 'logs');
    if (!fs_1.default.existsSync(logDir)) {
        fs_1.default.mkdirSync(logDir, { recursive: true });
    }
    const fileStream = rfs.createStream((date, index) => {
        if (!date)
            date = new Date(); //return 'bizcore.log';
        const d = date;
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `bizcore-${yyyy}${mm}${dd}${index ? `-${index}` : ""}.log`;
    }, {
        interval: '1d',
        path: logDir
    });
    const consolePrettyStream = require('pino-pretty')({
        colorize: true,
        translateTime: 'SYS:standard',
        ignore: 'pid,hostname',
    });
    const filePrettyStream = require('pino-pretty')({
        colorize: false,
        translateTime: 'SYS:standard',
        ignore: 'pid,hostname',
        destination: fileStream
    });
    loggerInstance = (0, pino_1.default)({
        level: process.env.LOG_LEVEL || 'info',
        timestamp: pino_1.default.stdTimeFunctions.isoTime,
        base: null,
    }, pino_1.default.multistream([
        { stream: consolePrettyStream },
        { stream: filePrettyStream }
    ]));
}
else {
    loggerInstance = (0, pino_1.default)({
        level: process.env.LOG_LEVEL || 'info',
        timestamp: pino_1.default.stdTimeFunctions.isoTime,
        base: null,
        transport: {
            target: 'pino-elasticsearch',
            options: {
                node: 'http://localhost:9200'
            }
        }
    });
}
exports.logger = loggerInstance;

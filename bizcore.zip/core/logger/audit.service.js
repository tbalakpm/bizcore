"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditLog = auditLog;
const db_1 = require("../../db");
const request_context_1 = require("./request-context");
/**
 * Writes an audit log entry to the database.
 * The userId is automatically pulled from the current request context.
 */
async function auditLog({ action, entity, entityId, oldValue = null, newValue = null, }) {
    const ctx = (0, request_context_1.getContext)();
    await db_1.db.insert(db_1.auditLogs).values({
        userId: ctx.userId ?? null,
        requestId: ctx.requestId ?? null,
        action,
        entity,
        entityId: String(entityId),
        oldValue: oldValue ? JSON.stringify(oldValue) : null,
        newValue: newValue ? JSON.stringify(newValue) : null,
    });
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogService = void 0;
const logger_1 = require("./logger");
const request_context_1 = require("./request-context");
/**
 * LogService - A static wrapper around the pino logger.
 * Automatically merges the current request context (requestId, userId)
 * into every log entry for traceability.
 */
class LogService {
    static info(message, data = {}) {
        logger_1.logger.info({ ...(0, request_context_1.getContext)(), ...data }, message);
    }
    static warn(message, data = {}) {
        logger_1.logger.warn({ ...(0, request_context_1.getContext)(), ...data }, message);
    }
    static error(message, err, data = {}) {
        logger_1.logger.error({ ...(0, request_context_1.getContext)(), err, ...data }, message);
    }
    static debug(message, data = {}) {
        logger_1.logger.debug({ ...(0, request_context_1.getContext)(), ...data }, message);
    }
}
exports.LogService = LogService;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PdfDocument = void 0;
const PdfPrinter = require('pdfmake/js/printer').default;
// Fonts definition for PdfPrinter - using standard PDF fonts
const fonts = {
    Helvetica: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique'
    }
};
class PdfDocument {
    res;
    docDefinition;
    marginLeft = 40;
    marginRight = 40;
    marginTop = 40;
    marginBottom = 100;
    pageWidth = 595.28; // A4 width in pt
    pageHeight = 841.89; // A4 height in pt
    usableWidth = 595.28 - 40 - 40;
    constructor(res) {
        this.res = res;
        this.docDefinition = {
            content: [],
            pageSize: 'A4',
            pageMargins: [this.marginLeft, this.marginTop, this.marginRight, this.marginBottom],
            defaultStyle: {
                font: 'Helvetica',
                fontSize: 9,
                color: '#000000',
            },
        };
    }
    /**
     * Add a pdfmake element to the document content.
     */
    addContent(element) {
        if (Array.isArray(this.docDefinition.content)) {
            this.docDefinition.content.push(element);
        }
    }
    /**
     * Set headers, footers, etc.
     */
    setHeader(header) {
        this.docDefinition.header = header;
    }
    setFooter(footer) {
        this.docDefinition.footer = footer;
    }
    /**
     * Generate the PDF and pipe it to the response.
     */
    async end() {
        const URLResolver = require('pdfmake/js/URLResolver').default;
        const virtualfs = require('pdfmake/js/virtual-fs').default;
        const printer = new PdfPrinter(fonts, virtualfs, new URLResolver(virtualfs));
        const pdfDoc = await printer.createPdfKitDocument(this.docDefinition);
        pdfDoc.pipe(this.res);
        pdfDoc.end();
    }
}
exports.PdfDocument = PdfDocument;

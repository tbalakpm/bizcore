"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchCompanyInfo = fetchCompanyInfo;
const schema_1 = require("../../../db/schema");
async function fetchCompanyInfo(db) {
    const rows = await db.select().from(schema_1.settings).all();
    const s = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return {
        name: s['company_name'] ?? 'Your Company',
        gstin: s['company_gstin'] ?? '',
        addressLine1: s['company_address_line1'] ?? '',
        city: s['company_city'] ?? '',
        state: s['company_state'] ?? '',
        postalCode: s['company_postal_code'] ?? '',
        phone: s['company_phone'] ?? '',
        bankName: s['bank_name'] ?? '',
        bankAccount: s['bank_account'] ?? '',
        bankIfsc: s['bank_ifsc'] ?? '',
        invoiceTerms: s['invoice_terms'] ?? '',
        sgstSharingRate: Number(s['sgst_sharing_rate'] ?? 50),
        igstSharingRate: Number(s['igst_sharing_rate'] ?? 100),
    };
}

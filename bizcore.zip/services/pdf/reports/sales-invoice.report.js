"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderSalesInvoice = renderSalesInvoice;
const drizzle_orm_1 = require("drizzle-orm");
const schema_1 = require("../../../db/schema");
const pdf_document_1 = require("../engine/pdf-document");
const pdf_types_1 = require("../engine/pdf-types");
const sections = __importStar(require("../engine/pdf-sections"));
async function renderSalesInvoice(id, db, res) {
    const company = await (0, pdf_types_1.fetchCompanyInfo)(db);
    // 1. Fetch Invoice
    const invoice = await db.select().from(schema_1.salesInvoices).where((0, drizzle_orm_1.eq)(schema_1.salesInvoices.id, id)).get();
    if (!invoice)
        throw new Error('Sales invoice not found');
    // 2. Fetch Customer & Addresses
    const customer = await db.select().from(schema_1.customers).where((0, drizzle_orm_1.eq)(schema_1.customers.id, invoice.customerId)).get();
    let billingAddress = null;
    let shippingAddress = null;
    if (customer?.billingAddressId) {
        billingAddress = await db.select().from(schema_1.addresses).where((0, drizzle_orm_1.eq)(schema_1.addresses.id, customer.billingAddressId)).get();
    }
    if (customer?.shippingAddressId) {
        shippingAddress = await db.select().from(schema_1.addresses).where((0, drizzle_orm_1.eq)(schema_1.addresses.id, customer.shippingAddressId)).get();
    }
    // 3. Fetch Items
    const items = await db
        .select({
        qty: schema_1.salesInvoiceItems.qty,
        unitPrice: schema_1.salesInvoiceItems.unitPrice,
        discountAmount: schema_1.salesInvoiceItems.discountAmount,
        taxPct: schema_1.salesInvoiceItems.taxPct,
        taxAmount: schema_1.salesInvoiceItems.taxAmount,
        sgstAmount: schema_1.salesInvoiceItems.sgstAmount,
        cgstAmount: schema_1.salesInvoiceItems.cgstAmount,
        igstAmount: schema_1.salesInvoiceItems.igstAmount,
        lineTotal: schema_1.salesInvoiceItems.lineTotal,
        productName: schema_1.products.name,
        gtn: schema_1.inventories.gtn,
        uom: schema_1.products.qtyPerUnit,
        hsnSac: schema_1.products.hsnSac,
    })
        .from(schema_1.salesInvoiceItems)
        .innerJoin(schema_1.inventories, (0, drizzle_orm_1.eq)(schema_1.inventories.id, schema_1.salesInvoiceItems.inventoryId))
        .innerJoin(schema_1.products, (0, drizzle_orm_1.eq)(schema_1.products.id, schema_1.inventories.productId))
        .where((0, drizzle_orm_1.eq)(schema_1.salesInvoiceItems.salesInvoiceId, id))
        .all();
    const formattedItems = items.map(item => {
        // const qty = Number(item.qty) || 1;
        const price = Number(item.unitPrice) * Number(item.qty) - Number(item.discountAmount);
        return {
            ...item,
            productName: item.gtn ? `${item.productName} - ${item.gtn}` : item.productName,
            unitPrice: price,
            taxPctAndAmount: `${Number(item.taxPct).toFixed(0)}% - ${Number(item.taxAmount).toFixed(2)}`
        };
    });
    const hsnMap = new Map();
    for (const item of items) {
        const hsn = item.hsnSac || 'NA';
        const taxableValue = (Number(item.qty) * Number(item.unitPrice)) - Number(item.discountAmount);
        if (!hsnMap.has(hsn)) {
            hsnMap.set(hsn, {
                hsnSac: hsn,
                taxableValue: 0,
                taxPct: Number(item.taxPct).toFixed(0),
                cgstAmount: 0,
                sgstAmount: 0,
                igstAmount: 0,
            });
        }
        const hsnRow = hsnMap.get(hsn);
        hsnRow.taxableValue += taxableValue;
        hsnRow.cgstAmount += Number(item.cgstAmount);
        hsnRow.sgstAmount += Number(item.sgstAmount);
        hsnRow.igstAmount += Number(item.igstAmount);
    }
    const hsnSummary = Array.from(hsnMap.values());
    const totalCgst = items.reduce((sum, i) => sum + Number(i.cgstAmount), 0);
    const totalSgst = items.reduce((sum, i) => sum + Number(i.sgstAmount), 0);
    const totalIgst = items.reduce((sum, i) => sum + Number(i.igstAmount), 0);
    // 4. Start Rendering
    const pdf = new pdf_document_1.PdfDocument(res);
    sections.renderCompanyHeader(pdf, company);
    sections.renderReportMeta(pdf, {
        title: invoice.type === 'invoice' ? 'TAX INVOICE' : 'ESTIMATE',
        number: invoice.invoiceNumber,
        date: invoice.invoiceDate,
        extraMeta: invoice.refNumber ? [{ label: 'Ref No', value: invoice.refNumber }] : [],
    });
    if (invoice.irn) {
        await sections.renderEInvoiceBlock(pdf, invoice.irn, invoice.ackNo, invoice.ackDate, invoice.signedQrCode);
    }
    sections.renderRule(pdf);
    if (customer) {
        const leftAddr = {
            name: customer.name,
            gstin: customer.gstin,
            line1: billingAddress?.addressLine1,
            city: billingAddress?.city,
            state: billingAddress?.state,
            postalCode: billingAddress?.postalCode,
            phone: billingAddress?.phone,
        };
        const rightAddr = shippingAddress ? {
            name: customer.name,
            line1: shippingAddress.addressLine1,
            city: shippingAddress.city,
            state: shippingAddress.state,
            postalCode: shippingAddress.postalCode,
            phone: shippingAddress.phone,
        } : undefined;
        sections.renderAddressBlock(pdf, leftAddr, rightAddr, 'BILL TO', 'SHIP TO');
    }
    sections.renderRule(pdf);
    const isEstimate = invoice.type === 'estimate';
    const columns = [
        { header: '#', key: 'index', align: 'right', width: 'auto' },
        { header: 'Product', key: 'productName', align: 'left', width: '*' },
        { header: 'HSN/SAC', key: 'hsnSac', align: 'left', width: 'auto' },
        { header: 'Qty', key: 'qty', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        { header: 'Price', key: 'unitPrice', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        ...(isEstimate ? [] : [{ header: 'Tax', key: 'taxPctAndAmount', align: 'right', width: 'auto' }]),
        { header: 'Total', key: 'lineTotal', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
    ];
    sections.renderItemsTable(pdf, columns, formattedItems);
    sections.renderTotals(pdf, {
        taxableAmount: Number(invoice.subtotal) - Number(invoice.discountAmount),
        cgstAmount: totalCgst,
        sgstAmount: totalSgst,
        igstAmount: totalIgst,
        roundOff: Number(invoice.roundOff ?? 0),
        netAmount: Number(invoice.netAmount ?? 0),
    }, company, hsnSummary, isEstimate);
    sections.renderFooter(pdf, company);
    await pdf.end();
}

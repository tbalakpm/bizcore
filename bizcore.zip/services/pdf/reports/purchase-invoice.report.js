"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderPurchaseInvoice = renderPurchaseInvoice;
const drizzle_orm_1 = require("drizzle-orm");
const schema_1 = require("../../../db/schema");
const pdf_document_1 = require("../engine/pdf-document");
const pdf_types_1 = require("../engine/pdf-types");
const sections = __importStar(require("../engine/pdf-sections"));
async function renderPurchaseInvoice(id, db, res) {
    const company = await (0, pdf_types_1.fetchCompanyInfo)(db);
    // 1. Fetch Invoice
    const invoice = await db.select().from(schema_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(schema_1.purchaseInvoices.id, id)).get();
    if (!invoice)
        throw new Error('Purchase invoice not found');
    // 2. Fetch Supplier & Addresses
    const supplier = await db.select().from(schema_1.suppliers).where((0, drizzle_orm_1.eq)(schema_1.suppliers.id, invoice.supplierId)).get();
    let billingAddress = null;
    let shippingAddress = null;
    if (supplier?.billingAddressId) {
        billingAddress = await db.select().from(schema_1.addresses).where((0, drizzle_orm_1.eq)(schema_1.addresses.id, supplier.billingAddressId)).get();
    }
    if (supplier?.shippingAddressId) {
        shippingAddress = await db.select().from(schema_1.addresses).where((0, drizzle_orm_1.eq)(schema_1.addresses.id, supplier.shippingAddressId)).get();
    }
    // 3. Fetch Items
    const items = await db
        .select({
        qty: schema_1.purchaseInvoiceItems.qty,
        unitPrice: schema_1.purchaseInvoiceItems.unitPrice,
        discountAmount: schema_1.purchaseInvoiceItems.discountAmount,
        taxPct: schema_1.purchaseInvoiceItems.taxPct,
        taxAmount: schema_1.purchaseInvoiceItems.taxAmount,
        lineTotal: schema_1.purchaseInvoiceItems.lineTotal,
        productName: schema_1.products.name,
        hsnSac: schema_1.inventories.hsnSac,
        gtn: schema_1.inventories.gtn,
    })
        .from(schema_1.purchaseInvoiceItems)
        .innerJoin(schema_1.inventories, (0, drizzle_orm_1.eq)(schema_1.inventories.id, schema_1.purchaseInvoiceItems.inventoryId))
        .innerJoin(schema_1.products, (0, drizzle_orm_1.eq)(schema_1.products.id, schema_1.inventories.productId))
        .where((0, drizzle_orm_1.eq)(schema_1.purchaseInvoiceItems.purchaseInvoiceId, id))
        .all();
    // 4. Start Rendering
    const pdf = new pdf_document_1.PdfDocument(res);
    sections.renderCompanyHeader(pdf, company);
    sections.renderReportMeta(pdf, {
        title: 'PURCHASE INVOICE',
        number: invoice.invoiceNumber,
        date: invoice.invoiceDate,
        extraMeta: invoice.refNumber ? [{ label: 'Ref No', value: invoice.refNumber }] : [],
    });
    sections.renderRule(pdf);
    if (supplier) {
        const leftAddr = {
            name: supplier.name,
            gstin: supplier.gstin,
            line1: billingAddress?.addressLine1,
            city: billingAddress?.city,
            state: billingAddress?.state,
            postalCode: billingAddress?.postalCode,
            phone: billingAddress?.phone,
        };
        const rightAddr = shippingAddress ? {
            name: supplier.name,
            line1: shippingAddress.addressLine1,
            city: shippingAddress.city,
            state: shippingAddress.state,
            postalCode: shippingAddress.postalCode,
            phone: shippingAddress.phone,
        } : undefined;
        sections.renderAddressBlock(pdf, leftAddr, rightAddr, 'SUPPLIER', 'SHIP TO');
    }
    sections.renderRule(pdf);
    const columns = [
        { header: '#', key: 'index', align: 'right', width: 'auto' },
        { header: 'Product', key: 'productName', align: 'left', width: '*' },
        { header: 'HSN/SAC', key: 'hsnSac', align: 'left', width: 'auto' },
        { header: 'GTN', key: 'gtn', align: 'left', width: 'auto' },
        { header: 'Qty', key: 'qty', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        { header: 'Rate', key: 'unitPrice', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        { header: 'Tax%', key: 'taxPct', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        { header: 'Tax Amt', key: 'taxAmount', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
        { header: 'Total', key: 'lineTotal', align: 'right', width: 'auto', format: (v) => Number(v).toFixed(2) },
    ];
    sections.renderItemsTable(pdf, columns, items);
    // Calculate totals if not in main invoice (or use main invoice if accurate)
    sections.renderTotals(pdf, {
        subtotal: Number(invoice.subtotal),
        discountAmount: Number(invoice.discountAmount),
        taxAmount: Number(invoice.totalTaxAmount ?? 0),
        taxPct: 0,
        roundOff: Number(invoice.roundOff ?? 0),
        netAmount: Number(invoice.netAmount ?? 0),
    }, company);
    sections.renderFooter(pdf, company);
    await pdf.end();
}

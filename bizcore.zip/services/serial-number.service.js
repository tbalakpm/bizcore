"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serialNumberService = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const db_1 = require("../db");
const serial_number_shared_1 = require("../shared/serial-number.shared");
const SERIAL_KEYS = {
    stockInvoice: 'stock_invoice',
    salesInvoice: 'sales_invoice',
    salesEstimate: 'sales_estimate',
    purchaseInvoice: 'purchase_invoice',
};
const defaultSerialConfig = {
    [SERIAL_KEYS.stockInvoice]: { prefix: 'STK-', length: 10, start: 1 },
    [SERIAL_KEYS.salesInvoice]: { prefix: 'INV-', length: 10, start: 1 },
    [SERIAL_KEYS.salesEstimate]: { prefix: 'EST-', length: 10, start: 1 },
    [SERIAL_KEYS.purchaseInvoice]: { prefix: 'PUR-', length: 10, start: 1 },
};
exports.serialNumberService = {
    keys: SERIAL_KEYS,
    generateInvoiceNumber: async (type, tx, date = new Date()) => {
        const key = SERIAL_KEYS[type];
        if (!key) {
            throw new Error(`Unsupported serial number type: ${type}`);
        }
        if (tx) {
            return exports.serialNumberService.generateNextNumberInTransaction(key, tx, date);
        }
        return db_1.db.transaction(async (transaction) => {
            return exports.serialNumberService.generateNextNumberInTransaction(key, transaction, date);
        });
    },
    generateNextNumberInTransaction: async (key, tx, date = new Date()) => {
        const config = defaultSerialConfig[key] ?? {
            prefix: `${key.toUpperCase()}-`,
            length: 10,
            start: 1,
        };
        let [currentRecord] = await tx
            .select()
            .from(db_1.serialNumbers)
            .where((0, drizzle_orm_1.eq)(db_1.serialNumbers.key, key))
            .orderBy((0, drizzle_orm_1.asc)(db_1.serialNumbers.id))
            .limit(1);
        if (!currentRecord) {
            await tx.insert(db_1.serialNumbers).values({
                key,
                prefix: config.prefix,
                current: config.start,
                length: config.length,
            });
            [currentRecord] = await tx
                .select()
                .from(db_1.serialNumbers)
                .where((0, drizzle_orm_1.eq)(db_1.serialNumbers.key, key))
                .orderBy((0, drizzle_orm_1.asc)(db_1.serialNumbers.id))
                .limit(1);
        }
        if (!currentRecord) {
            throw new Error(`Unable to initialize serial number configuration for key: ${key}`);
        }
        const [updatedRecord] = await tx
            .update(db_1.serialNumbers)
            .set({ current: (0, drizzle_orm_1.sql) `${db_1.serialNumbers.current} + 1` })
            .where((0, drizzle_orm_1.eq)(db_1.serialNumbers.id, currentRecord.id))
            .returning({ current: db_1.serialNumbers.current });
        if (!updatedRecord) {
            throw new Error(`Unable to increment serial number for key: ${key}`);
        }
        const serialValue = updatedRecord.current - 1;
        const prefix = (0, serial_number_shared_1.resolvePrefixTemplate)(currentRecord.prefix ?? config.prefix, date);
        return (0, serial_number_shared_1.formatSerialNumber)(prefix, serialValue, currentRecord.length);
    },
};

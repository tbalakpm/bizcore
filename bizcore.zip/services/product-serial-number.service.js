"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productSerialNumberService = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const db_1 = require("../db");
const serial_number_service_1 = require("./serial-number.service");
const serial_number_shared_1 = require("../shared/serial-number.shared");
const MODES = {
    manual: 'manual',
    auto: 'auto'
};
const SERIAL_TYPES = {
    code: 'code',
    batch: 'batch',
    tag: 'tag',
    manual: 'manual'
};
// const defaultConfigBySerialType: Record<ProductSerialType, SerialSequenceConfig> = {
//   [SERIAL_TYPES.tagNumber]: { prefix: 'TAG-', length: 10, start: 1 },
//   [SERIAL_TYPES.batchNumber]: { prefix: 'BAT-', length: 10, start: 1 },
// };
const requiresCounter = (mode, serialType) => mode === MODES.auto &&
    (serialType === SERIAL_TYPES.tag || serialType === SERIAL_TYPES.batch);
exports.productSerialNumberService = {
    modes: MODES,
    serialTypes: SERIAL_TYPES,
    resolveGtnConfiguration: async (productId, tx) => {
        const product = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, productId)).get();
        if (!product)
            throw new Error(`Product not found: ${productId}`);
        let useGlobal = product.useGlobal;
        let gtnMode = product.gtnMode;
        let gtnGeneration = product.gtnGeneration;
        if (useGlobal) {
            const globalSettings = await tx.select().from(db_1.settings).all();
            const settingsMap = new Map(globalSettings.map(s => [s.key, s.value]));
            const globalUseGtn = settingsMap.get('use_global_gtn');
            if (globalUseGtn === 'false') {
                return { mode: 'manual', generation: 'manual' };
            }
            gtnMode = (settingsMap.get('gtn_mode') || 'auto');
            gtnGeneration = (settingsMap.get('gtn_generation') || 'code');
        }
        // Map 'global' value to actual defaults if necessary, though the logic above should have handled it if useGlobal is true.
        // However, if useGlobal is false but the product fields are still 'global' (unlikely but possible), we should handle it.
        if (gtnMode === 'global')
            gtnMode = 'auto';
        if (gtnGeneration === 'global')
            gtnGeneration = 'code';
        return {
            mode: gtnMode,
            generation: gtnGeneration
        };
    },
    generateGtn: async (productId, tx) => {
        const config = await exports.productSerialNumberService.resolveGtnConfiguration(productId, tx);
        if (config.mode === 'manual')
            return '';
        const genType = config.generation.toLowerCase();
        if (genType === 'code') {
            const product = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, productId)).get();
            return product?.code || '';
        }
        if (genType === 'batch' || genType === 'tag') {
            const product = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, productId)).get();
            if (!product)
                throw new Error(`Product not found: ${productId}`);
            if (product.useGlobal) {
                // Use global sequence 'gtn' from serial_numbers table
                return await serial_number_service_1.serialNumberService.generateNextNumberInTransaction('gtn', tx);
            }
            else {
                // Use product specific sequence from product_serial_numbers table
                return await exports.productSerialNumberService.generateInTransaction({
                    productId,
                    mode: config.mode,
                    serialType: genType,
                    tx: tx,
                    date: new Date()
                });
            }
        }
        return '';
    },
    generate: async ({ productId, mode, serialType, date = new Date(), tx, }) => {
        if (tx) {
            return exports.productSerialNumberService.generateInTransaction({ productId, mode, serialType, date, tx });
        }
        return db_1.db.transaction(async (transaction) => {
            return exports.productSerialNumberService.generateInTransaction({
                productId,
                mode,
                serialType,
                date,
                tx: transaction,
            });
        });
    },
    generateTagNumber: async (productId, mode, tx, date = new Date()) => {
        return exports.productSerialNumberService.generate({
            productId,
            mode,
            serialType: SERIAL_TYPES.tag,
            tx,
            date,
        });
    },
    generateBatchNumber: async (productId, mode, tx, date = new Date()) => {
        return exports.productSerialNumberService.generate({
            productId,
            mode,
            serialType: SERIAL_TYPES.batch,
            tx,
            date,
        });
    },
    generateInTransaction: async ({ productId, mode, serialType, date, tx, }) => {
        const [product] = await tx.select({
            id: db_1.products.id,
            code: db_1.products.code,
            prefix: db_1.productSerialNumbers.prefix,
            current: db_1.productSerialNumbers.current,
            length: db_1.productSerialNumbers.length,
        }).from(db_1.products)
            .leftJoin(db_1.productSerialNumbers, (0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, db_1.products.id))
            .where((0, drizzle_orm_1.eq)(db_1.products.id, productId)).limit(1);
        if (!product) {
            throw new Error(`Product not found: ${productId}`);
        }
        if (!requiresCounter(mode, serialType)) {
            return product.code;
        }
        // const config = defaultConfigBySerialType[serialType];
        let [currentRecord] = await tx
            .select()
            .from(db_1.productSerialNumbers)
            .where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, productId))
            .orderBy((0, drizzle_orm_1.asc)(db_1.productSerialNumbers.id))
            .limit(1);
        if (!currentRecord) {
            // Create a default one if not exists (though the product route should have created it)
            // Use the product's configured prefix and start position if available
            await tx.insert(db_1.productSerialNumbers).values({
                productId,
                prefix: product.prefix || 'AA',
                current: product.current || 1,
                length: product.length || 10,
            });
            [currentRecord] = await tx
                .select()
                .from(db_1.productSerialNumbers)
                .where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, productId))
                .orderBy((0, drizzle_orm_1.asc)(db_1.productSerialNumbers.id))
                .limit(1);
        }
        if (!currentRecord) {
            throw new Error(`Unable to initialize product serial number for productId: ${productId}`);
        }
        let finalPrefix = currentRecord.prefix;
        let finalValue = currentRecord.current;
        // Check for overflow (numeric sequence exhaustion)
        const maxValue = Math.pow(10, currentRecord.length) - 1;
        if (finalValue > maxValue) {
            // Roll over prefix and reset current to 1
            finalPrefix = (0, serial_number_shared_1.incrementPrefixTemplate)(finalPrefix);
            finalValue = 1;
            await tx
                .update(db_1.productSerialNumbers)
                .set({
                prefix: finalPrefix,
                current: 2 // We are issuing 1 now, so next is 2
            })
                .where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.id, currentRecord.id))
                .run();
        }
        else {
            await tx
                .update(db_1.productSerialNumbers)
                .set({ current: (0, drizzle_orm_1.sql) `${db_1.productSerialNumbers.current} + 1` })
                .where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.id, currentRecord.id))
                .run();
        }
        const resolvedPrefix = (0, serial_number_shared_1.resolvePrefixTemplate)(finalPrefix, date);
        return (0, serial_number_shared_1.formatSerialNumber)(resolvedPrefix, finalValue, currentRecord.length);
    },
};

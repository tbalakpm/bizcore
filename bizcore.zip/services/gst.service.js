"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gstService = exports.GstService = void 0;
const node_crypto_1 = __importDefault(require("node:crypto"));
const node_https_1 = __importDefault(require("node:https"));
const logger_service_1 = require("../core/logger/logger.service");
// Utility to make HTTPS requests with cookies and proper TLS handling
async function httpRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
        const parsedUrl = new URL(url);
        const reqOptions = {
            hostname: parsedUrl.hostname,
            path: parsedUrl.pathname + parsedUrl.search,
            method: options.method || 'GET',
            headers: options.headers || {},
            timeout: 10000,
            rejectUnauthorized: false,
        };
        const req = node_https_1.default.request(reqOptions, (res) => {
            let data = [];
            res.on('data', (chunk) => data.push(chunk));
            res.on('end', () => {
                const buffer = Buffer.concat(data);
                let body = buffer;
                if (options.json && buffer.length > 0) {
                    try {
                        body = JSON.parse(buffer.toString());
                    }
                    catch (e) {
                        logger_service_1.LogService.error('Failed to parse JSON response', buffer.toString());
                    }
                }
                resolve({
                    body,
                    headers: res.headers,
                    status: res.statusCode || 0
                });
            });
        });
        req.on('error', (err) => reject(err));
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timed out'));
        });
        if (options.body) {
            req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
        }
        req.end();
    });
}
class GstService {
    sessions = new Map();
    SESSION_TIMEOUT = 5 * 60 * 1000; // 5 minutes
    constructor() {
        setInterval(() => {
            const now = Date.now();
            for (const [id, data] of this.sessions.entries()) {
                if (now - data.createdAt > this.SESSION_TIMEOUT) {
                    this.sessions.delete(id);
                }
            }
        }, 60000);
    }
    async getCaptcha() {
        const userAgent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
        const commonHeaders = {
            'User-Agent': userAgent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        };
        try {
            // 1. Establish session
            const searchRes = await httpRequest('https://services.gst.gov.in/services/searchtp', { headers: commonHeaders });
            if (searchRes.status !== 200)
                throw new Error('Failed to establish session');
            const initialCookies = searchRes.headers['set-cookie'] || [];
            // 2. Fetch captcha
            const captchaRes = await httpRequest('https://services.gst.gov.in/services/captcha', {
                headers: {
                    ...commonHeaders,
                    'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                    'Cookie': initialCookies.map((c) => c.split(';')[0]).join('; '),
                    'Referer': 'https://services.gst.gov.in/services/searchtp'
                }
            });
            if (captchaRes.status !== 200)
                throw new Error('Failed to fetch captcha');
            const buffer = captchaRes.body;
            const base64 = buffer.toString('base64');
            const allCookies = [...initialCookies, ...(captchaRes.headers['set-cookie'] || [])];
            const sessionId = node_crypto_1.default.randomUUID();
            this.sessions.set(sessionId, {
                cookies: allCookies.map((c) => c.split(';')[0]),
                createdAt: Date.now()
            });
            return {
                captcha: `data:image/png;base64,${base64}`,
                sessionId
            };
        }
        catch (error) {
            logger_service_1.LogService.error('GST Captcha Error:', error.message);
            throw error;
        }
    }
    async fetchGstinDetails(gstin, captcha, sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session)
            throw new Error('Session expired. Please refresh captcha.');
        const userAgent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
        const url = 'https://services.gst.gov.in/services/api/search/taxpayerDetails';
        const responseData = await httpRequest(url, {
            method: 'POST',
            headers: {
                'User-Agent': userAgent,
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json',
                'Cookie': session.cookies.join('; '),
                'Referer': 'https://services.gst.gov.in/services/searchtp',
                'Origin': 'https://services.gst.gov.in'
            },
            body: { gstin: gstin.toUpperCase(), captcha: captcha },
            json: true
        });
        const data = responseData.body;
        if (!data || data.status_cd === '0')
            throw new Error(data?.message || 'Invalid captcha or search failed');
        logger_service_1.LogService.info('GSTIN data', data);
        const addr = data.pradr?.addr || {};
        return {
            gstin: data.gstin || gstin,
            name: data.lgnm || data.tradeNam || 'Unknown',
            addressLine1: [addr.bnm, addr.bno, addr.st, addr.loc].filter(Boolean).join(', '),
            addressLine2: addr.flno || '',
            city: addr.dst || addr.city || '',
            state: addr.stcd || '',
            postalCode: addr.pncd || '',
            phone: data.mobNum || '',
            mobile: data.mobNum || ''
        };
    }
}
exports.GstService = GstService;
exports.gstService = new GstService();

"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateDatabase = exports.initializeDatabase = exports.db = void 0;
const libsql_1 = require("drizzle-orm/libsql");
const migrator_1 = require("drizzle-orm/libsql/migrator");
const client_1 = require("@libsql/client");
const config_1 = require("../config");
const logger_service_1 = require("../core/logger/logger.service");
__exportStar(require("./schema"), exports);
const client = (0, client_1.createClient)({
    url: config_1.config.tursoDatabaseUrl,
    authToken: config_1.config.tursoAuthToken,
});
exports.db = (0, libsql_1.drizzle)(client, { logger: false /*config.isDevelopment*/, casing: 'snake_case' });
const initializeDatabase = async () => {
    logger_service_1.LogService.info('Initializing database');
    await exports.db.run(`
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=NORMAL;
    PRAGMA foreign_keys=ON;
    PRAGMA busy_timeout=5000;`);
};
exports.initializeDatabase = initializeDatabase;
const migrateDatabase = async () => {
    logger_service_1.LogService.info('Migrating database');
    await (0, migrator_1.migrate)(exports.db, { migrationsFolder: './drizzle' });
};
exports.migrateDatabase = migrateDatabase;

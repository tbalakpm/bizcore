"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAdminUser = void 0;
const db_1 = require("../../db");
const utils_1 = require("../../utils");
const user_schema_1 = require("../schema/user.schema");
const drizzle_orm_1 = require("drizzle-orm");
const createAdminUser = async () => {
    const user = await db_1.db.select(user_schema_1.userPublicSelect)
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.username, "admin")).get();
    if (user)
        return;
    await db_1.db.insert(db_1.users).values({
        username: "admin",
        passwordHash: await (0, utils_1.hashPassword)("Welcome!23"),
        firstName: "BizCore",
        lastName: "Admin",
        role: "admin",
    });
};
exports.createAdminUser = createAdminUser;

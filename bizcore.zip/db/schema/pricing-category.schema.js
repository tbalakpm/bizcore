"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pricingCategories = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
exports.pricingCategories = (0, sqlite_core_1.sqliteTable)('pricing_categories', {
    ...base_1.keyFields,
    description: (0, sqlite_core_1.text)('description', { length: 255 }),
    ...base_1.auditFields,
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('pricing_categories_code_unique').on(t.code),
    (0, sqlite_core_1.uniqueIndex)('pricing_categories_name_unique').on(t.name),
]);

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userPublicSelect = exports.users = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
exports.users = (0, sqlite_core_1.sqliteTable)("users", {
    id: (0, sqlite_core_1.integer)("id")
        .primaryKey({ autoIncrement: true })
        .notNull(),
    username: (0, sqlite_core_1.text)("username", { length: 20 })
        .notNull(),
    passwordHash: (0, sqlite_core_1.text)("password_hash", { length: 255 })
        .notNull(),
    firstName: (0, sqlite_core_1.text)("first_name", { length: 50 }),
    lastName: (0, sqlite_core_1.text)("last_name", { length: 50 }),
    role: (0, sqlite_core_1.text)("role", { length: 20 })
        .notNull()
        .default("user"),
    permissions: (0, sqlite_core_1.text)("permissions").default("{}"),
    mustChangePassword: (0, sqlite_core_1.integer)("must_change_password", { mode: "boolean" })
        .notNull()
        .default(true),
    ...base_1.auditFields,
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)("users_username_unique").on(t.username),
    (0, sqlite_core_1.check)("role_must_be_in_list", (0, drizzle_orm_1.sql) `${t.role} IN ('user', 'salesperson', 'manager', 'admin')`),
]);
// Runtime column selection object for use with db.select()
exports.userPublicSelect = {
    id: exports.users.id,
    username: exports.users.username,
    firstName: exports.users.firstName,
    lastName: exports.users.lastName,
    role: exports.users.role,
    permissions: exports.users.permissions,
};

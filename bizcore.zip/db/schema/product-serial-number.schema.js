"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productSerialNumbers = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const product_schema_1 = require("./product.schema");
exports.productSerialNumbers = (0, sqlite_core_1.sqliteTable)('product_serial_numbers', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    productId: (0, sqlite_core_1.integer)('product_id')
        .notNull()
        .references(() => product_schema_1.products.id),
    prefix: (0, sqlite_core_1.text)('prefix', { length: 50 })
        .notNull()
        .default(''),
    current: (0, sqlite_core_1.integer)('current')
        .notNull()
        .default(1),
    length: (0, sqlite_core_1.integer)('length')
        .notNull()
        .default(10)
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('product_serial_numbers_product_id_unique').on(t.productId)
]);
/*
 a. prefix: Combination of Alphabets and Special characters like hyphen(-), dot(.), colon(:), slash(/), underscore(_), backward slash(\), hash(#), pipe(|) are allowed
    e.g. AA-BB-CC-0000000001
    and more imporatantly alphabets should be incremented once numbers are reached maximum
    e.g. AA-BB-CC-9999999999 ==> AA-BB-CD-0000000001
    e.g. AA-BB-ZZ-9999999999 ==> AA-BC-AA-0000000001
    e.g. AA-ZZ-ZZ-9999999999 ==> AB-AA-AA-0000000001
 b. current: Numbers
 c. length: Numbers
*/

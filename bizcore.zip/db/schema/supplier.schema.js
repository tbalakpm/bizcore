"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.suppliers = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
const address_schema_1 = require("./address.schema");
exports.suppliers = (0, sqlite_core_1.sqliteTable)('suppliers', {
    ...base_1.keyFields,
    type: (0, sqlite_core_1.text)('type', { enum: ['weaver', 'supplier'] })
        .notNull()
        .default('supplier'),
    gstin: (0, sqlite_core_1.text)('gstin', { length: 25 }),
    billingAddressId: (0, sqlite_core_1.integer)('billing_address_id')
        .references(() => address_schema_1.addresses.id),
    shippingAddressId: (0, sqlite_core_1.integer)('shipping_address_id')
        .references(() => address_schema_1.addresses.id),
    notes: (0, sqlite_core_1.text)('notes', { length: 255 }),
    ...base_1.auditFields
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('suppliers_code_unique').on(t.code),
    (0, sqlite_core_1.uniqueIndex)('suppliers_name_unique').on(t.name),
    (0, sqlite_core_1.index)('suppliers_billing_address_id_idx').on(t.billingAddressId),
    (0, sqlite_core_1.index)('suppliers_shipping_address_id_idx').on(t.shippingAddressId),
    (0, sqlite_core_1.index)('suppliers_gstin_idx').on(t.gstin)
]);

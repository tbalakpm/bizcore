"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.products = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const category_schema_1 = require("./category.schema");
const brand_schema_1 = require("./brand.schema");
const base_1 = require("./base");
const product_template_schema_1 = require("./product-template.schema");
exports.products = (0, sqlite_core_1.sqliteTable)('products', {
    ...base_1.keyFields,
    description: (0, sqlite_core_1.text)('description', { length: 255 }),
    categoryId: (0, sqlite_core_1.integer)('category_id')
        .notNull()
        .references(() => category_schema_1.categories.id),
    brandId: (0, sqlite_core_1.integer)('brand_id')
        .references(() => brand_schema_1.brands.id),
    productType: (0, sqlite_core_1.text)("product_type", { length: 25, enum: ["simple", "bundle", "variant"] })
        .notNull()
        .default('simple'),
    parentId: (0, sqlite_core_1.integer)('parent_id')
        .references(() => exports.products.id),
    templateId: (0, sqlite_core_1.integer)('template_id')
        .references(() => product_template_schema_1.productTemplates.id),
    qtyPerUnit: (0, sqlite_core_1.text)('qty_per_unit', { length: 25 })
        .notNull()
        .default('1'),
    unitPrice: (0, sqlite_core_1.real)('unit_price')
        .notNull()
        .default(0.00),
    hsnSac: (0, sqlite_core_1.text)('hsn_sac', { length: 25 })
        .notNull()
        .default(''),
    taxRate: (0, sqlite_core_1.real)('tax_rate')
        .notNull()
        .default(0.00),
    useGlobal: (0, sqlite_core_1.integer)('use_global', { mode: 'boolean' })
        .notNull()
        .default(true), // true - use global settings from gtn key of serial_numbers table, false - use product specific settings
    trackBundleGtn: (0, sqlite_core_1.integer)('track_bundle_gtn', { mode: 'boolean' })
        .default(true), // true - generate GTN for bundle, false - track bundle components
    gtnMode: (0, sqlite_core_1.text)('gtn_mode', { length: 25, enum: ['global', 'auto', 'manual'] })
        .notNull()
        .default('global'), // global (default), auto, manual
    gtnGeneration: (0, sqlite_core_1.text)('gtn_generation', { length: 25, enum: ['global', 'code', 'batch', 'tag', 'manual'] })
        .notNull()
        .default('global'), // global (default), code, batch, tag, manual
    isTaxInclusive: (0, sqlite_core_1.integer)('is_tax_inclusive', { mode: 'boolean' })
        .notNull()
        .default(false),
    ...base_1.auditFields
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('products_code_unique').on(t.code),
    (0, sqlite_core_1.uniqueIndex)('products_name_unique').on(t.name),
    (0, sqlite_core_1.index)('products_category_id_idx').on(t.categoryId),
    // check('gtn_mode_must_be_in_list', sql`${t.gtnMode} IN ('auto','manual')`),
    // check('gtn_generation_must_be_in_list', sql`${t.gtnGeneration} IN ('code','batch','tag','manual')`)
]);
/*
gtnMode:
  if gtnMode == 'manual' then gtnGeneration can be 'manual'
  if gtnMode == 'auto' then gtnGeneration can be 'code','batch','tag'
gtnGeneration:
  if gtnGeneration == 'code' then use product code as gtn
  if gtnGeneration == 'batch' then generate gtn for each product as per configured in product_serial_numbers i.e. same gtn per LOT
  if gtnGeneration == 'tag' then generate gtn for each qty as per configured in product_serial_numbers i.e., unique gtn per item
  if gtnGeneration == 'manual' then get the input manually
*/

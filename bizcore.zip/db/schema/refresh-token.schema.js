"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshTokens = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const user_schema_1 = require("./user.schema");
exports.refreshTokens = (0, sqlite_core_1.sqliteTable)('refresh_tokens', {
    id: (0, sqlite_core_1.integer)('id').primaryKey({ autoIncrement: true }).notNull(),
    userId: (0, sqlite_core_1.integer)('user_id')
        .notNull()
        .references(() => user_schema_1.users.id, { onDelete: 'cascade' }),
    /** SHA-256 hash of the raw token — never store raw tokens */
    tokenHash: (0, sqlite_core_1.text)('token_hash', { length: 64 }).notNull().unique(),
    expiresAt: (0, sqlite_core_1.integer)('expires_at', { mode: 'timestamp' }).notNull(),
    revokedAt: (0, sqlite_core_1.integer)('revoked_at', { mode: 'timestamp' }),
    createdAt: (0, sqlite_core_1.integer)('created_at', { mode: 'timestamp' })
        .notNull()
        .$defaultFn(() => new Date()),
});

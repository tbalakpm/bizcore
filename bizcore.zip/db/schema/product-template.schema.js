"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productTemplates = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
exports.productTemplates = (0, sqlite_core_1.sqliteTable)('product_templates', {
    ...base_1.keyFieldsNoCode,
    description: (0, sqlite_core_1.text)('description'),
    ...base_1.auditFields,
});

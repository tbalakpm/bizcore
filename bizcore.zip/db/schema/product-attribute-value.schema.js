"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productAttributeValues = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
const product_schema_1 = require("./product.schema");
const attribute_schema_1 = require("./attribute.schema");
exports.productAttributeValues = (0, sqlite_core_1.sqliteTable)('product_attribute_values', {
    id: (0, sqlite_core_1.integer)('id').primaryKey({ autoIncrement: true }),
    productId: (0, sqlite_core_1.integer)('product_id').notNull().references(() => product_schema_1.products.id),
    attributeId: (0, sqlite_core_1.integer)('attribute_id').notNull().references(() => attribute_schema_1.attributes.id),
    value: (0, sqlite_core_1.text)('value').notNull(), // JSON string for values
    ...base_1.auditFields,
});

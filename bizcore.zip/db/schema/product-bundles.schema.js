"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productBundles = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const product_schema_1 = require("./product.schema");
exports.productBundles = (0, sqlite_core_1.sqliteTable)("product_bundles", {
    id: (0, sqlite_core_1.integer)("id").primaryKey({ autoIncrement: true }),
    bundleProductId: (0, sqlite_core_1.integer)("bundle_product_id")
        .notNull()
        .references(() => product_schema_1.products.id),
    productId: (0, sqlite_core_1.integer)("product_id")
        .notNull()
        .references(() => product_schema_1.products.id),
    quantity: (0, sqlite_core_1.integer)("quantity").notNull().default(1),
}, (t) => [
    (0, sqlite_core_1.index)('product_bundles_bundle_product_id_idx').on(t.bundleProductId),
    (0, sqlite_core_1.index)('product_bundles_product_id_idx').on(t.productId),
]);

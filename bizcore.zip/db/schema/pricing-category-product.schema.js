"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pricingCategoryProducts = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const pricing_category_schema_1 = require("./pricing-category.schema");
const product_schema_1 = require("./product.schema");
exports.pricingCategoryProducts = (0, sqlite_core_1.sqliteTable)('pricing_category_products', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    pricingCategoryId: (0, sqlite_core_1.integer)('pricing_category_id')
        .notNull()
        .references(() => pricing_category_schema_1.pricingCategories.id, { onDelete: 'cascade' }),
    productId: (0, sqlite_core_1.integer)('product_id')
        .notNull()
        .references(() => product_schema_1.products.id, { onDelete: 'cascade' }),
    marginType: (0, sqlite_core_1.text)('margin_type', { length: 25, enum: ['none', 'percent', 'amount', 'selling_price'] })
        .notNull()
        .default('none'), // none, percent, amount, selling_price
    marginPct: (0, sqlite_core_1.real)('margin_pct')
        .notNull()
        .default(0),
    marginAmount: (0, sqlite_core_1.real)('margin_amount')
        .notNull()
        .default(0.00),
}, (t) => [
    (0, sqlite_core_1.index)('pcp_pricing_category_id_idx').on(t.pricingCategoryId),
    (0, sqlite_core_1.index)('pcp_product_id_idx').on(t.productId),
]);

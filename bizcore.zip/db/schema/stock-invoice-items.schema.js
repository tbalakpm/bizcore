"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stockInvoiceItems = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const stock_invoice_schema_1 = require("./stock-invoice.schema");
const inventory_schema_1 = require("./inventory.schema");
const drizzle_orm_1 = require("drizzle-orm");
exports.stockInvoiceItems = (0, sqlite_core_1.sqliteTable)('stock_invoice_items', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    stockInvoiceId: (0, sqlite_core_1.integer)('stock_invoice_id')
        .references(() => stock_invoice_schema_1.stockInvoices.id)
        .notNull(),
    inventoryId: (0, sqlite_core_1.integer)('inventory_id')
        .references(() => inventory_schema_1.inventories.id)
        .notNull(),
    qty: (0, sqlite_core_1.real)('qty')
        .notNull()
        .default(1),
    unitPrice: (0, sqlite_core_1.real)('unit_price')
        .notNull()
        .default(0.00),
    lineTotal: (0, sqlite_core_1.real)('line_total')
        .generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND(qty * unit_price, 2))`),
    marginType: (0, sqlite_core_1.text)('margin_type', { length: 25, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    marginPct: (0, sqlite_core_1.real)('margin_pct')
        .notNull()
        .default(0),
    marginAmount: (0, sqlite_core_1.real)('margin_amount')
        .notNull()
        .default(0.00),
    sellingPrice: (0, sqlite_core_1.real)('selling_price')
        .notNull()
        .default(0.00)
}, (t) => [
    (0, sqlite_core_1.index)('stock_invoice_items_stock_invoice_id_idx').on(t.stockInvoiceId),
    (0, sqlite_core_1.index)('stock_invoice_items_inventory_id_idx').on(t.inventoryId)
]);
/*
  Allow user to create product on the fly with GTN, HSN/SAC, Tax, etc.
  If product is created on the fly, then it should be added to the 'products' table
  If product is selected from the dropdown, then it should be created/updated in the 'inventories' table
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.purchaseInvoices = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const supplier_schema_1 = require("./supplier.schema");
exports.purchaseInvoices = (0, sqlite_core_1.sqliteTable)('purchase_invoices', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    invoiceNumber: (0, sqlite_core_1.text)('invoice_number', { length: 25 })
        .notNull(),
    invoiceDate: (0, sqlite_core_1.text)('invoice_date', { length: 25 })
        .notNull(),
    supplierId: (0, sqlite_core_1.integer)('supplier_id')
        .notNull()
        .references(() => supplier_schema_1.suppliers.id),
    refNumber: (0, sqlite_core_1.text)('ref_number', { length: 25 }),
    refDate: (0, sqlite_core_1.text)('ref_date', { length: 25 }),
    totalQty: (0, sqlite_core_1.real)('total_qty')
        .notNull()
        .default(0.000),
    subtotal: (0, sqlite_core_1.real)('subtotal')
        .notNull()
        .default(0.00),
    discountType: (0, sqlite_core_1.text)('discount_type', { length: 20, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    discountPct: (0, sqlite_core_1.real)('discount_pct')
        .notNull()
        .default(0.00),
    discountAmount: (0, sqlite_core_1.real)('discount_amount')
        .notNull()
        .default(0.00),
    totalTaxAmount: (0, sqlite_core_1.real)('total_tax_amount')
        .notNull()
        .default(0.00), // total tax amount from the line-items - calculated field
    roundOff: (0, sqlite_core_1.real)('round_off')
        .notNull()
        .default(0.00),
    netAmount: (0, sqlite_core_1.real)('net_amount').generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND(subtotal - discount_amount + total_tax_amount + round_off, 2))`)
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('purchase_invoices_invoice_number_unique').on(t.invoiceNumber),
    (0, sqlite_core_1.index)('purchase_invoices_supplier_id_idx').on(t.supplierId),
    (0, sqlite_core_1.index)('purchase_invoices_invoice_date_idx').on(t.invoiceDate),
    (0, sqlite_core_1.index)('purchase_invoices_ref_number_idx').on(t.refNumber)
]);

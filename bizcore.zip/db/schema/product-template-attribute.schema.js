"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productTemplateAttributes = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const product_template_schema_1 = require("./product-template.schema");
const attribute_schema_1 = require("./attribute.schema");
exports.productTemplateAttributes = (0, sqlite_core_1.sqliteTable)('product_template_attributes', {
    id: (0, sqlite_core_1.integer)('id').primaryKey({ autoIncrement: true }),
    templateId: (0, sqlite_core_1.integer)('template_id').notNull().references(() => product_template_schema_1.productTemplates.id),
    attributeId: (0, sqlite_core_1.integer)('attribute_id').notNull().references(() => attribute_schema_1.attributes.id),
    isVariantDefining: (0, sqlite_core_1.integer)('is_variant_defining', { mode: 'boolean' }).notNull().default(false),
});

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierBanks = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const supplier_schema_1 = require("./supplier.schema");
exports.supplierBanks = (0, sqlite_core_1.sqliteTable)("supplier_banks", {
    id: (0, sqlite_core_1.integer)("id")
        .primaryKey({ autoIncrement: true })
        .notNull(),
    supplierId: (0, sqlite_core_1.integer)("supplier_id")
        .notNull()
        .references(() => supplier_schema_1.suppliers.id),
    bankName: (0, sqlite_core_1.text)("bank_name").notNull(),
    accountNumber: (0, sqlite_core_1.text)("account_number").notNull(),
    ifscCode: (0, sqlite_core_1.text)("ifsc_code").notNull(),
    branchName: (0, sqlite_core_1.text)("branch_name").notNull(),
    isPrimary: (0, sqlite_core_1.integer)("is_primary", { mode: 'boolean' })
        .notNull()
        .default(false),
}, (t) => [
    (0, sqlite_core_1.index)('supplier_bank_supplier_id_idx').on(t.supplierId),
]);

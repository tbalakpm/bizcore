"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.brandCategories = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const brand_schema_1 = require("./brand.schema");
const category_schema_1 = require("./category.schema");
exports.brandCategories = (0, sqlite_core_1.sqliteTable)('brand_categories', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    brandId: (0, sqlite_core_1.integer)('brand_id')
        .notNull()
        .references(() => brand_schema_1.brands.id, { onDelete: 'cascade' }),
    categoryId: (0, sqlite_core_1.integer)('category_id')
        .notNull()
        .references(() => category_schema_1.categories.id, { onDelete: 'cascade' }),
}, (t) => [
    (0, sqlite_core_1.index)('brand_categories_brand_id_idx').on(t.brandId),
    (0, sqlite_core_1.index)('brand_categories_category_id_idx').on(t.categoryId),
]);

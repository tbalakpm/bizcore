"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditLogs = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.auditLogs = (0, sqlite_core_1.sqliteTable)('audit_logs', {
    id: (0, sqlite_core_1.integer)('id').primaryKey({ autoIncrement: true }).notNull(),
    userId: (0, sqlite_core_1.integer)('user_id'),
    requestId: (0, sqlite_core_1.text)('request_id', { length: 36 }),
    action: (0, sqlite_core_1.text)('action', { length: 100 }).notNull(),
    entity: (0, sqlite_core_1.text)('entity', { length: 100 }).notNull(),
    entityId: (0, sqlite_core_1.text)('entity_id', { length: 100 }).notNull(),
    /** JSON string of the previous state */
    oldValue: (0, sqlite_core_1.text)('old_value'),
    /** JSON string of the new state */
    newValue: (0, sqlite_core_1.text)('new_value'),
    createdAt: (0, sqlite_core_1.text)('created_at')
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`),
});

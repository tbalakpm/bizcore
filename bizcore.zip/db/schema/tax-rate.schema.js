"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.taxRates = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.taxRates = (0, sqlite_core_1.sqliteTable)('tax_rates', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    rate: (0, sqlite_core_1.integer)('rate')
        .notNull(),
    cgst_rate: (0, sqlite_core_1.integer)('cgst_rate')
        .notNull(),
    sgst_rate: (0, sqlite_core_1.integer)('sgst_rate')
        .notNull(),
    igst_rate: (0, sqlite_core_1.integer)('igst_rate')
        .notNull(),
    cess_rate: (0, sqlite_core_1.integer)('cess_rate')
        .notNull(),
    cess_amount: (0, sqlite_core_1.integer)('cess_amount')
        .notNull(),
    effective_from: (0, sqlite_core_1.text)('effective_from')
        .notNull(),
});

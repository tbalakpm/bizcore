"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryLogs = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const product_schema_1 = require("./product.schema");
const drizzle_orm_1 = require("drizzle-orm");
exports.inventoryLogs = (0, sqlite_core_1.sqliteTable)("inventory_logs", {
    id: (0, sqlite_core_1.integer)("id")
        .primaryKey({ autoIncrement: true }),
    productId: (0, sqlite_core_1.integer)("product_id")
        .notNull()
        .references(() => product_schema_1.products.id),
    gtn: (0, sqlite_core_1.text)('gtn', { length: 25 })
        .notNull()
        .default(''),
    changeQty: (0, sqlite_core_1.real)("change_qty")
        .notNull()
        .default(0.00),
    direction: (0, sqlite_core_1.text)("direction", { length: 10, enum: ["in", "out"] })
        .notNull(),
    type: (0, sqlite_core_1.text)("type", { length: 25, enum: ["stock", "purchase", "sale", "debit_note", "credit_note", "adjustment"] })
        .notNull(),
    refId: (0, sqlite_core_1.integer)("ref_id")
        .notNull(), // sale_id
    createdAt: (0, sqlite_core_1.text)("created_at")
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`)
}, (t) => [
    (0, sqlite_core_1.index)('inventory_logs_product_id_idx').on(t.productId),
    (0, sqlite_core_1.uniqueIndex)('inventory_logs_gtn_idx').on(t.gtn),
]);

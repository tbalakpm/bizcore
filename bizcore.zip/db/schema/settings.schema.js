"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settings = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
// This table can be used to store application-wide settings or configurations. Each setting has a unique key and a corresponding value.
exports.settings = (0, sqlite_core_1.sqliteTable)('settings', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    key: (0, sqlite_core_1.text)('key', { length: 50 })
        .notNull(),
    value: (0, sqlite_core_1.text)('value', { length: 255 })
        .notNull()
        .default('')
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('settings_key_unique').on(t.key)
]);
/*
  tz = 'Asia/Kolkata'
  tz_time_diff = +5.5 or +5:30 or -5.5 or -5:30
  sgst_sharing_rate =  50
  cgst_sharing_rate =  50
  igst_sharing_rate = 100
*/

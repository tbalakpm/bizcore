"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditFields = exports.keyFieldsNoCode = exports.keyFields = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.keyFields = {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    code: (0, sqlite_core_1.text)('code', { length: 20 })
        .notNull(),
    name: (0, sqlite_core_1.text)('name', { length: 50 })
        .notNull(),
};
exports.keyFieldsNoCode = {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    name: (0, sqlite_core_1.text)('name', { length: 50 })
        .notNull(),
};
exports.auditFields = {
    isActive: (0, sqlite_core_1.integer)('is_active', { mode: 'boolean' })
        .notNull()
        .default(true),
    createdAt: (0, sqlite_core_1.text)('created_at')
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`),
    updatedAt: (0, sqlite_core_1.text)('updated_at')
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`),
};

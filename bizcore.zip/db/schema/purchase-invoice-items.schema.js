"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.purchaseInvoiceItems = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const purchase_invoice_schema_1 = require("./purchase-invoice.schema");
const inventory_schema_1 = require("./inventory.schema");
exports.purchaseInvoiceItems = (0, sqlite_core_1.sqliteTable)('purchase_invoice_items', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    purchaseInvoiceId: (0, sqlite_core_1.integer)('purchase_invoice_id')
        .references(() => purchase_invoice_schema_1.purchaseInvoices.id)
        .notNull(),
    inventoryId: (0, sqlite_core_1.integer)('inventory_id')
        .references(() => inventory_schema_1.inventories.id)
        .notNull(),
    qty: (0, sqlite_core_1.real)('qty')
        .notNull()
        .default(0.000),
    unitPrice: (0, sqlite_core_1.real)('unit_price')
        .notNull()
        .default(0.00),
    discountType: (0, sqlite_core_1.text)('discount_type', { length: 10, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    discountPct: (0, sqlite_core_1.real)('discount_pct')
        .notNull()
        .default(0.00),
    discountAmount: (0, sqlite_core_1.real)('discount_amount')
        .notNull()
        .default(0.00),
    taxPct: (0, sqlite_core_1.real)('tax_pct')
        .notNull()
        .default(0.00),
    taxAmount: (0, sqlite_core_1.real)('tax_amount').generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND((qty * unit_price - discount_amount) * tax_pct / 100, 2))`),
    sgstAmount: (0, sqlite_core_1.real)('sgst_amount').notNull().default(0.00),
    cgstAmount: (0, sqlite_core_1.real)('cgst_amount').notNull().default(0.00),
    igstAmount: (0, sqlite_core_1.real)('igst_amount').notNull().default(0.00),
    lineTotal: (0, sqlite_core_1.real)('line_total').generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND((qty * unit_price - discount_amount) + tax_amount, 2))`),
    marginType: (0, sqlite_core_1.text)('margin_type', { length: 25, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    marginPct: (0, sqlite_core_1.real)('margin_pct')
        .notNull()
        .default(0),
    marginAmount: (0, sqlite_core_1.real)('margin_amount')
        .notNull()
        .default(0.00),
    sellingPrice: (0, sqlite_core_1.real)('selling_price')
        .notNull()
        .default(0.00)
}, (t) => [
    (0, sqlite_core_1.index)('purchase_invoice_items_purchase_invoice_id_idx').on(t.purchaseInvoiceId),
    (0, sqlite_core_1.index)('purchase_invoice_items_inventory_id_idx').on(t.inventoryId)
]);

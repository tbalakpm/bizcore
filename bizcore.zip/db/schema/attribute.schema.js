"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.attributes = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
exports.attributes = (0, sqlite_core_1.sqliteTable)('attributes', {
    ...base_1.keyFieldsNoCode,
    description: (0, sqlite_core_1.text)('description'),
    type: (0, sqlite_core_1.text)('type', { enum: ['single_select', 'multi_select', 'text', 'number', 'boolean'] }).notNull(),
    options: (0, sqlite_core_1.text)('options'), // JSON string [ "S", "M", "L" ]
    defaultValue: (0, sqlite_core_1.text)('default_value'), // JSON string [ "S" ]
    ...base_1.auditFields,
});

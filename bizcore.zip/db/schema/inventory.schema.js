"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventories = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const product_schema_1 = require("./product.schema");
const drizzle_orm_1 = require("drizzle-orm");
exports.inventories = (0, sqlite_core_1.sqliteTable)('inventories', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    productId: (0, sqlite_core_1.integer)('product_id')
        .references(() => product_schema_1.products.id)
        .notNull(),
    gtn: (0, sqlite_core_1.text)('gtn', { length: 25 })
        .notNull()
        .default(''),
    qtyPerUnit: (0, sqlite_core_1.text)('qty_per_unit', { length: 25 })
        .notNull()
        .default('1'),
    hsnSac: (0, sqlite_core_1.text)('hsn_sac', { length: 25 })
        .notNull()
        .default(''),
    taxRate: (0, sqlite_core_1.real)('tax_rate')
        .notNull()
        .default(0),
    buyingPrice: (0, sqlite_core_1.real)('buying_price')
        .notNull()
        .default(0.00),
    sellingPrice: (0, sqlite_core_1.real)('selling_price')
        .notNull()
        .default(0.00),
    unitsInStock: (0, sqlite_core_1.integer)('units_in_stock')
        .notNull()
        .default(0),
    location: (0, sqlite_core_1.text)('location', { length: 255 })
        .notNull()
        .default(''),
    createdAt: (0, sqlite_core_1.text)('created_at')
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`),
    updatedAt: (0, sqlite_core_1.text)('updated_at')
        .notNull()
        .default((0, drizzle_orm_1.sql) `(CURRENT_TIMESTAMP)`)
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('inventories_gtn_unique').on(t.gtn),
    (0, sqlite_core_1.index)('inventories_product_id_idx').on(t.productId),
]);

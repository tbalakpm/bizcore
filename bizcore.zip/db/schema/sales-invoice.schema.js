"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesInvoices = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const customer_schema_1 = require("./customer.schema");
exports.salesInvoices = (0, sqlite_core_1.sqliteTable)('sales_invoices', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    invoiceNumber: (0, sqlite_core_1.text)('invoice_number', { length: 25 })
        .notNull(),
    invoiceDate: (0, sqlite_core_1.text)('invoice_date', { length: 25 })
        .notNull(),
    type: (0, sqlite_core_1.text)('type', { length: 20, enum: ['invoice', 'estimate'] })
        .notNull()
        .default('invoice'), // invoice, estimate
    customerId: (0, sqlite_core_1.integer)('customer_id')
        .notNull()
        .references(() => customer_schema_1.customers.id),
    refNumber: (0, sqlite_core_1.text)('ref_number', { length: 25 }),
    refDate: (0, sqlite_core_1.text)('ref_date', { length: 25 }),
    isTaxInclusive: (0, sqlite_core_1.integer)('is_tax_inclusive', { mode: 'boolean' }),
    totalQty: (0, sqlite_core_1.real)('total_qty')
        .notNull()
        .default(0.000),
    subtotal: (0, sqlite_core_1.real)('subtotal')
        .notNull()
        .default(0.00),
    discountType: (0, sqlite_core_1.text)('discount_type', { length: 20, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    discountPct: (0, sqlite_core_1.real)('discount_pct')
        .notNull()
        .default(0.00),
    discountAmount: (0, sqlite_core_1.real)('discount_amount')
        .notNull()
        .default(0.00),
    // taxPct: real('tax_pct').notNull().default('0.00'),
    totalTaxAmount: (0, sqlite_core_1.real)('total_tax_amount')
        .notNull()
        .default(0.00),
    roundOff: (0, sqlite_core_1.real)('round_off')
        .notNull()
        .default(0.00),
    netAmount: (0, sqlite_core_1.real)('net_amount')
        .generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND(subtotal - discount_amount + total_tax_amount + round_off, 2))`),
    // E-Invoice Metadata
    irn: (0, sqlite_core_1.text)('irn', { length: 64 }), // 64-character hash
    ackNo: (0, sqlite_core_1.text)('ack_no', { length: 20 }), // 15-digit Ack No
    ackDate: (0, sqlite_core_1.text)('ack_date', { length: 50 }), // ISO Date String
    signedQrCode: (0, sqlite_core_1.text)('signed_qr_code') // Large payload string
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('sales_invoices_invoice_number_unique').on(t.invoiceNumber),
    (0, sqlite_core_1.index)('sales_invoices_invoice_date_idx').on(t.invoiceDate),
    (0, sqlite_core_1.index)('sales_invoices_customer_id_idx').on(t.customerId),
    (0, sqlite_core_1.index)('sales_invoices_ref_number_idx').on(t.refNumber),
    (0, sqlite_core_1.index)('sales_invoices_irn_idx').on(t.irn),
    (0, sqlite_core_1.index)('sales_invoices_ack_no_idx').on(t.ackNo)
]);

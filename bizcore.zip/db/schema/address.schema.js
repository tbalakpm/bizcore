"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addresses = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.addresses = (0, sqlite_core_1.sqliteTable)('addresses', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    addressLine1: (0, sqlite_core_1.text)('address_line_1', { length: 255 }),
    addressLine2: (0, sqlite_core_1.text)('address_line_2', { length: 255 }),
    area: (0, sqlite_core_1.text)('area', { length: 25 }),
    city: (0, sqlite_core_1.text)('city', { length: 25 }),
    taluk: (0, sqlite_core_1.text)('taluk', { length: 25 }),
    district: (0, sqlite_core_1.text)('district', { length: 25 }),
    state: (0, sqlite_core_1.text)('state', { length: 25 }),
    country: (0, sqlite_core_1.text)('country', { length: 25 }),
    postalCode: (0, sqlite_core_1.text)('postal_code', { length: 25 }),
    phone: (0, sqlite_core_1.text)('phone', { length: 25 }),
    mobile: (0, sqlite_core_1.text)('mobile', { length: 25 }),
    email: (0, sqlite_core_1.text)('email', { length: 100 }),
    website: (0, sqlite_core_1.text)('website', { length: 100 }),
    latitude: (0, sqlite_core_1.text)('latitude', { length: 25 }),
    longitude: (0, sqlite_core_1.text)('longitude', { length: 25 })
}, (t) => [
    (0, sqlite_core_1.index)('address_city_idx').on(t.city),
    (0, sqlite_core_1.index)('address_phone_idx').on(t.phone),
    (0, sqlite_core_1.index)('address_mobile_idx').on(t.mobile),
    (0, sqlite_core_1.index)('address_email_idx').on(t.email)
]);

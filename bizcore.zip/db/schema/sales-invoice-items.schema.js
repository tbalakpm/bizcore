"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesInvoiceItems = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const sales_invoice_schema_1 = require("./sales-invoice.schema");
const inventory_schema_1 = require("./inventory.schema");
exports.salesInvoiceItems = (0, sqlite_core_1.sqliteTable)('sales_invoice_items', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    salesInvoiceId: (0, sqlite_core_1.integer)('sales_invoice_id')
        .references(() => sales_invoice_schema_1.salesInvoices.id)
        .notNull(),
    inventoryId: (0, sqlite_core_1.integer)('inventory_id')
        .references(() => inventory_schema_1.inventories.id)
        .notNull(),
    qty: (0, sqlite_core_1.real)('qty')
        .notNull()
        .default(0.000),
    unitPrice: (0, sqlite_core_1.real)('unit_price')
        .notNull()
        .default(0.00),
    discountType: (0, sqlite_core_1.text)('discount_type', { length: 10, enum: ['none', 'percent', 'amount'] })
        .notNull()
        .default('none'), // none, percent, amount
    discountPct: (0, sqlite_core_1.real)('discount_pct')
        .notNull()
        .default(0.00),
    discountAmount: (0, sqlite_core_1.real)('discount_amount')
        .notNull()
        .default(0.00),
    taxPct: (0, sqlite_core_1.real)('tax_pct')
        .notNull()
        .default(0.00),
    taxAmount: (0, sqlite_core_1.real)('tax_amount').generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND((qty * unit_price - discount_amount) * tax_pct / 100, 2))`),
    sgstAmount: (0, sqlite_core_1.real)('sgst_amount').notNull().default(0.00),
    cgstAmount: (0, sqlite_core_1.real)('cgst_amount').notNull().default(0.00),
    igstAmount: (0, sqlite_core_1.real)('igst_amount').notNull().default(0.00),
    lineTotal: (0, sqlite_core_1.real)('line_total').generatedAlwaysAs(() => (0, drizzle_orm_1.sql) `(ROUND((qty * unit_price - discount_amount) + tax_amount, 2))`)
}, (t) => [
    (0, sqlite_core_1.index)('sales_invoice_items_sales_invoice_id_idx').on(t.salesInvoiceId),
    (0, sqlite_core_1.index)('sales_invoice_items_inventory_id_idx').on(t.inventoryId)
]);
/*
  Allow user to scan the barcode (gtn column) and fetch the inventories and show it as product, hsn/sac, tax, etc.
  After selection of the product from the dropdown, 'inventories' table should be updated as below:
    create: it should be deduct the qty in the 'inventories' table
    update: reverse the qty to its original state and deduct the qty
    delete: reverse the qty to its original state
*/

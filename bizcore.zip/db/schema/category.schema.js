"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.categories = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
exports.categories = (0, sqlite_core_1.sqliteTable)('categories', {
    ...base_1.keyFields,
    description: (0, sqlite_core_1.text)('description', { length: 255 }),
    parentCategoryId: (0, sqlite_core_1.integer)('parent_category_id').references(() => exports.categories.id),
    ...base_1.auditFields
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('categories_code_unique').on(t.code),
    (0, sqlite_core_1.uniqueIndex)('categories_name_unique').on(t.name)
]);

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.states = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.states = (0, sqlite_core_1.sqliteTable)('states', {
    id: (0, sqlite_core_1.integer)('id').primaryKey({ autoIncrement: true }).notNull(),
    stateName: (0, sqlite_core_1.text)('state_name', { length: 100 }).notNull(),
    stateCode: (0, sqlite_core_1.text)('state_code', { length: 2 }).notNull(), // GST code (e.g., 33 for TN)
    stateShortCode: (0, sqlite_core_1.text)('state_short_code', { length: 5 }).notNull(), // short code (e.g., TN)
    countryCode: (0, sqlite_core_1.text)('country_code', { length: 2 }).notNull().default('IN'),
    isUnionTerritory: (0, sqlite_core_1.integer)('is_union_territory', { mode: 'boolean' }).default(false),
    isActive: (0, sqlite_core_1.integer)('is_active', { mode: 'boolean' }).default(true),
});

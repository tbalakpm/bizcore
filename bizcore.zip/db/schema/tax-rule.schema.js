"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.taxRules = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.taxRules = (0, sqlite_core_1.sqliteTable)('tax_rules', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    hsnCodeStartsWith: (0, sqlite_core_1.text)('hsn_code_starts_with', { length: 20 })
        .notNull(),
    minPrice: (0, sqlite_core_1.integer)('min_price')
        .notNull(),
    maxPrice: (0, sqlite_core_1.integer)('max_price')
        .notNull(),
    tax_rate: (0, sqlite_core_1.integer)('tax_rate')
        .notNull(),
    effective_from: (0, sqlite_core_1.text)('effective_from')
        .notNull(),
});

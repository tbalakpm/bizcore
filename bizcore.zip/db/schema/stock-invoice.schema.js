"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stockInvoices = void 0;
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
exports.stockInvoices = (0, sqlite_core_1.sqliteTable)('stock_invoices', {
    id: (0, sqlite_core_1.integer)('id')
        .primaryKey({ autoIncrement: true })
        .notNull(),
    invoiceNumber: (0, sqlite_core_1.text)('invoice_number', { length: 20 })
        .notNull(),
    invoiceDate: (0, sqlite_core_1.text)('invoice_date', { length: 20 })
        .notNull(),
    totalQty: (0, sqlite_core_1.real)('total_qty')
        .notNull()
        .default(0.000),
    totalAmount: (0, sqlite_core_1.real)('total_amount')
        .notNull()
        .default(0.00)
}, (t) => [
    (0, sqlite_core_1.uniqueIndex)('stock_invoices_invoice_number_unique').on(t.invoiceNumber),
    (0, sqlite_core_1.index)('stock_invoices_invoice_date_idx').on(t.invoiceDate)
]);

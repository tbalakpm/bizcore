"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customers = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const base_1 = require("./base");
const address_schema_1 = require("./address.schema");
const pricing_category_schema_1 = require("./pricing-category.schema");
exports.customers = (0, sqlite_core_1.sqliteTable)('customers', {
    ...base_1.keyFields,
    type: (0, sqlite_core_1.text)('type', { length: 25, enum: ['retail', 'wholesale'] })
        .notNull()
        .default('retail'),
    gstin: (0, sqlite_core_1.text)('gstin', { length: 25 }),
    pricingCategoryId: (0, sqlite_core_1.integer)('pricing_category_id')
        .references(() => pricing_category_schema_1.pricingCategories.id),
    billingAddressId: (0, sqlite_core_1.integer)('billing_address_id')
        .references(() => address_schema_1.addresses.id),
    shippingAddressId: (0, sqlite_core_1.integer)('shipping_address_id')
        .references(() => address_schema_1.addresses.id),
    notes: (0, sqlite_core_1.text)('notes', { length: 255 }),
    ...base_1.auditFields
}, (t) => [
    (0, sqlite_core_1.check)('type_must_be_in_list', (0, drizzle_orm_1.sql) `${t.type} IN ('retail','wholesale')`),
    (0, sqlite_core_1.uniqueIndex)('customers_code_unique').on(t.code),
    (0, sqlite_core_1.uniqueIndex)('customers_name_unique').on(t.name),
    (0, sqlite_core_1.index)('customers_billing_address_id_idx').on(t.billingAddressId),
    (0, sqlite_core_1.index)('customers_shipping_address_id_idx').on(t.shippingAddressId),
    (0, sqlite_core_1.index)('cusotomers_gstin_idx').on(t.gstin),
    (0, sqlite_core_1.index)('customers_pricing_category_id_idx').on(t.pricingCategoryId)
]);

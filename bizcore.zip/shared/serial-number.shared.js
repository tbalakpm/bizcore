"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatSerialNumber = exports.incrementPrefixTemplate = exports.resolvePrefixTemplate = void 0;
const pad = (value, length) => value.toString().padStart(length, '0');
const julianDay = (date) => {
    const startOfYear = new Date(date.getFullYear(), 0, 1);
    const day = Math.floor((date.getTime() - startOfYear.getTime()) / (24 * 60 * 60 * 1000)) + 1;
    return pad(day, 3);
};
const resolvePrefixTemplate = (template, date) => {
    const replacements = {
        YYYYMMDD: `${date.getFullYear()}${pad(date.getMonth() + 1, 2)}${pad(date.getDate(), 2)}`,
        YYMMDD: `${date.getFullYear().toString().slice(-2)}${pad(date.getMonth() + 1, 2)}${pad(date.getDate(), 2)}`,
        YYYY: `${date.getFullYear()}`,
        YY: date.getFullYear().toString().slice(-2),
        MM: pad(date.getMonth() + 1, 2),
        DD: pad(date.getDate(), 2),
        JJJ: julianDay(date),
    };
    return template.replace(/YYYYMMDD|YYMMDD|YYYY|YY|MM|DD|JJJ/g, (token) => replacements[token]);
};
exports.resolvePrefixTemplate = resolvePrefixTemplate;
const incrementPrefixTemplate = (prefix) => {
    const chars = prefix.split('');
    let carry = true;
    for (let i = chars.length - 1; i >= 0; i--) {
        const code = chars[i].charCodeAt(0);
        if (code >= 65 && code <= 90) { // A-Z
            if (carry) {
                if (code === 90) {
                    chars[i] = 'A';
                }
                else {
                    chars[i] = String.fromCharCode(code + 1);
                    carry = false;
                    break;
                }
            }
        }
        else if (code >= 97 && code <= 122) { // a-z
            if (carry) {
                if (code === 122) {
                    chars[i] = 'a';
                }
                else {
                    chars[i] = String.fromCharCode(code + 1);
                    carry = false;
                    break;
                }
            }
        }
    }
    return chars.join('');
};
exports.incrementPrefixTemplate = incrementPrefixTemplate;
const formatSerialNumber = (prefix, value, length) => {
    // Don't format numbers longer than their allowed length, unless they naturally exceed it (which we handle upstream)
    const valueStr = value.toString();
    const allowedLength = Math.max(length, valueStr.length);
    return `${prefix}${valueStr.padStart(allowedLength, '0')}`;
};
exports.formatSerialNumber = formatSerialNumber;

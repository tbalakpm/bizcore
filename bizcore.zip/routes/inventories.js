"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoriesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
exports.inventoriesRouter = express_1.default.Router();
exports.inventoriesRouter.get('/', async (req, res) => {
    try {
        const q = req.query.q;
        const limit = Number(req.query.limit) || 50;
        const offset = Number(req.query.offset) || 0;
        let totalCountQuery = db_1.db
            .select({ count: (0, drizzle_orm_1.sql) `count(*)` })
            .from(db_1.inventories)
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .$dynamic();
        let dataQuery = db_1.db
            .select({
            id: db_1.inventories.id,
            productId: db_1.inventories.productId,
            gtn: db_1.inventories.gtn,
            unitsInStock: db_1.inventories.unitsInStock,
            location: db_1.inventories.location,
            buyingPrice: db_1.inventories.buyingPrice,
            sellingPrice: db_1.inventories.sellingPrice,
            code: db_1.products.code,
            name: db_1.products.name,
        })
            .from(db_1.inventories)
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .$dynamic();
        const filters = [];
        if (req.query.inStock === 'true') {
            filters.push((0, drizzle_orm_1.gt)(db_1.inventories.unitsInStock, 0));
        }
        if (q) {
            const searchPattern = `%${q}%`;
            filters.push((0, drizzle_orm_1.sql) `(${db_1.inventories.gtn} LIKE ${searchPattern} OR ${db_1.products.name} LIKE ${searchPattern})`);
        }
        if (filters.length > 0) {
            totalCountQuery = totalCountQuery.where((0, drizzle_orm_1.and)(...filters));
            dataQuery = dataQuery.where((0, drizzle_orm_1.and)(...filters));
        }
        const [totalRes] = await totalCountQuery.execute();
        const data = await dataQuery
            .limit(limit)
            .offset(offset)
            .execute();
        const total = Number(totalRes?.count || 0);
        res.json({
            data,
            pagination: {
                total,
                limit,
                offset,
                page: Math.floor(offset / limit) + 1,
                totalPages: Math.ceil(total / limit),
            },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch inventories', error);
        res.status(500).json({ error: 'Failed to fetch available stock' });
    }
});

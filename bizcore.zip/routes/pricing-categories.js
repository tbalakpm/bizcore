"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pricingCategoriesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const schema_1 = require("../db/schema");
const list_query_util_1 = require("../utils/list-query.util");
const number_util_1 = require("../utils/number.util");
const logger_service_1 = require("../core/logger/logger.service");
exports.pricingCategoriesRouter = express_1.default.Router();
// GET /pricing-categories - list all with pagination
exports.pricingCategoriesRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        const filters = [];
        const filterableFields = ['code', 'name', 'description'];
        const sortableFields = ['id', ...filterableFields, 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = schema_1.pricingCategories[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(schema_1.pricingCategories.isActive, isActive));
        }
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field))
                    continue;
                const column = schema_1.pricingCategories[field];
                if (column)
                    orderBy.push(dir(column));
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('asc')(schema_1.pricingCategories.name));
        }
        const baseQuery = db_1.db.select().from(schema_1.pricingCategories);
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        const countResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(schema_1.pricingCategories);
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(schema_1.pricingCategories)
                .where(whereCondition))[0].count
            : countResult[0].count;
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : { limit: result.length, offset: 0, total: filteredCount, page: 1, totalPages: 1 },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch pricing categories', error);
        res.status(500).json({ error: 'Failed to fetch pricing categories' });
    }
});
// GET /pricing-categories/:id
exports.pricingCategoriesRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id))
        return res.status(400).json({ error: 'Invalid pricing category ID' });
    const category = await db_1.db.select().from(schema_1.pricingCategories).where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, id)).get();
    if (!category)
        return res.status(404).json({ error: 'Pricing category not found' });
    res.json(category);
});
// POST /pricing-categories
exports.pricingCategoriesRouter.post('/', async (req, res) => {
    const { code, name, description, isActive } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    try {
        const category = await db_1.db
            .insert(schema_1.pricingCategories)
            .values({ code, name, description, isActive: isActive !== false })
            .returning()
            .get();
        res.status(201).json(category);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create pricing category', err);
        res.status(400).json({ error: 'Pricing category already exists or invalid data' });
    }
});
// PUT /pricing-categories/:id
exports.pricingCategoriesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const category = await db_1.db.select().from(schema_1.pricingCategories).where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, id)).get();
    if (!category)
        return res.status(404).json({ error: 'Pricing category not found' });
    const { code, name, description, isActive } = req.body;
    if (code !== undefined)
        category.code = code;
    if (name !== undefined)
        category.name = name;
    if (description !== undefined)
        category.description = description;
    if (typeof isActive === 'boolean')
        category.isActive = isActive;
    await db_1.db
        .update(schema_1.pricingCategories)
        .set({ code: category.code, name: category.name, description: category.description, isActive: category.isActive })
        .where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, id))
        .run();
    res.json(category);
});
// DELETE /pricing-categories/:id
exports.pricingCategoriesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const category = await db_1.db.select({ id: schema_1.pricingCategories.id }).from(schema_1.pricingCategories).where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, id)).get();
    if (!category)
        return res.status(404).json({ error: 'Pricing category not found' });
    await db_1.db.delete(schema_1.pricingCategories).where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, id)).run();
    res.status(204).send();
});
// ── Product Margins Sub-resource ────────────────────────────────────────────
// GET /pricing-categories/:id/products - list all product margins for a category
exports.pricingCategoriesRouter.get('/:id/products', async (req, res) => {
    const pricingCategoryId = parseInt(req.params['id'], 10);
    if (Number.isNaN(pricingCategoryId))
        return res.status(400).json({ error: 'Invalid pricing category ID' });
    const rows = await db_1.db
        .select({
        id: schema_1.pricingCategoryProducts.id,
        pricingCategoryId: schema_1.pricingCategoryProducts.pricingCategoryId,
        productId: schema_1.pricingCategoryProducts.productId,
        productCode: schema_1.products.code,
        productName: schema_1.products.name,
        marginType: schema_1.pricingCategoryProducts.marginType,
        marginPct: schema_1.pricingCategoryProducts.marginPct,
        marginAmount: schema_1.pricingCategoryProducts.marginAmount,
    })
        .from(schema_1.pricingCategoryProducts)
        .leftJoin(schema_1.products, (0, drizzle_orm_1.eq)(schema_1.pricingCategoryProducts.productId, schema_1.products.id))
        .where((0, drizzle_orm_1.eq)(schema_1.pricingCategoryProducts.pricingCategoryId, pricingCategoryId))
        .all();
    res.json(rows);
});
// PUT /pricing-categories/:id/products - bulk upsert product margins
exports.pricingCategoriesRouter.put('/:id/products', async (req, res) => {
    const pricingCategoryId = parseInt(req.params['id'], 10);
    if (Number.isNaN(pricingCategoryId))
        return res.status(400).json({ error: 'Invalid pricing category ID' });
    const category = await db_1.db.select({ id: schema_1.pricingCategories.id }).from(schema_1.pricingCategories).where((0, drizzle_orm_1.eq)(schema_1.pricingCategories.id, pricingCategoryId)).get();
    if (!category)
        return res.status(404).json({ error: 'Pricing category not found' });
    const items = req.body;
    if (!Array.isArray(items))
        return res.status(400).json({ error: 'Body must be an array of product margins' });
    // Delete existing margins for this category then re-insert
    await db_1.db.delete(schema_1.pricingCategoryProducts).where((0, drizzle_orm_1.eq)(schema_1.pricingCategoryProducts.pricingCategoryId, pricingCategoryId)).run();
    if (items.length > 0) {
        await db_1.db.insert(schema_1.pricingCategoryProducts).values(items.map((item) => ({
            pricingCategoryId,
            productId: item.productId,
            marginType: (item.marginType || 'none'),
            marginPct: (0, number_util_1.toNumber)(item.marginPct) || 0,
            marginAmount: (0, number_util_1.toNumber)(item.marginAmount) || 0.00,
        }))).run();
    }
    res.json({ success: true });
});

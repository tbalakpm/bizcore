"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serialNumbersRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const product_serial_number_service_1 = require("../services/product-serial-number.service");
const serial_number_service_1 = require("../services/serial-number.service");
exports.serialNumbersRouter = express_1.default.Router();
exports.serialNumbersRouter.get('/invoice-configs', async (_req, res) => {
    const data = await db_1.db.select().from(db_1.serialNumbers).orderBy(db_1.serialNumbers.id).all();
    res.json({ data });
});
exports.serialNumbersRouter.put('/invoice-configs/:key', async (req, res) => {
    const key = req.params.key;
    const { prefix, current, length } = req.body;
    const existing = await db_1.db.select().from(db_1.serialNumbers).where((0, drizzle_orm_1.eq)(db_1.serialNumbers.key, key)).get();
    if (!existing) {
        const created = await db_1.db.insert(db_1.serialNumbers).values({ key, prefix, current, length }).returning().get();
        return res.status(201).json(created);
    }
    await db_1.db.update(db_1.serialNumbers).set({ prefix, current, length }).where((0, drizzle_orm_1.eq)(db_1.serialNumbers.key, key)).run();
    const updated = await db_1.db.select().from(db_1.serialNumbers).where((0, drizzle_orm_1.eq)(db_1.serialNumbers.key, key)).get();
    return res.json(updated);
});
exports.serialNumbersRouter.get('/product-configs', async (_req, res) => {
    const data = await db_1.db.select().from(db_1.productSerialNumbers).orderBy(db_1.productSerialNumbers.id).all();
    res.json({ data });
});
exports.serialNumbersRouter.post('/invoice/:type', async (req, res) => {
    const type = req.params.type;
    if (!['stockInvoice', 'salesInvoice', 'purchaseInvoice'].includes(type)) {
        return res.status(400).json({ error: 'Invalid invoice serial type' });
    }
    const date = req.body?.date ? new Date(req.body.date) : new Date();
    const value = await serial_number_service_1.serialNumberService.generateInvoiceNumber(type, undefined, date);
    return res.json({ value });
});
exports.serialNumbersRouter.post('/product/:serialType', async (req, res) => {
    const serialType = req.params.serialType;
    const { productId, mode, date } = req.body;
    if (!productId || Number.isNaN(parseInt(productId, 10))) {
        return res.status(400).json({ error: 'productId is required' });
    }
    if (!Object.values(product_serial_number_service_1.productSerialNumberService.modes).includes(mode)) {
        return res.status(400).json({ error: 'Invalid product serial mode' });
    }
    if (!Object.values(product_serial_number_service_1.productSerialNumberService.serialTypes).includes(serialType)) {
        return res.status(400).json({ error: 'Invalid product serial type' });
    }
    const value = await product_serial_number_service_1.productSerialNumberService.generate({
        productId: parseInt(productId, 10),
        mode,
        serialType,
        date: date ? new Date(date) : new Date(),
    });
    return res.json({ value });
});

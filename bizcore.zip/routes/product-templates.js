"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productTemplatesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
exports.productTemplatesRouter = express_1.default.Router();
exports.productTemplatesRouter.get('/', async (req, res) => {
    try {
        const templates = await db_1.db.select().from(db_1.productTemplates).orderBy(db_1.productTemplates.name).all();
        // Fetch attributes for each template
        const templatesWithAttributes = await Promise.all(templates.map(async (tmpl) => {
            const mappedAttrs = await db_1.db.select({
                id: db_1.productTemplateAttributes.id,
                attributeId: db_1.productTemplateAttributes.attributeId,
                name: db_1.attributes.name,
                type: db_1.attributes.type,
                isVariantDefining: db_1.productTemplateAttributes.isVariantDefining,
            })
                .from(db_1.productTemplateAttributes)
                .innerJoin(db_1.attributes, (0, drizzle_orm_1.eq)(db_1.attributes.id, db_1.productTemplateAttributes.attributeId))
                .where((0, drizzle_orm_1.eq)(db_1.productTemplateAttributes.templateId, tmpl.id))
                .all();
            return {
                ...tmpl,
                mappedAttributes: mappedAttrs,
            };
        }));
        res.json(templatesWithAttributes);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch product templates', error);
        res.status(500).json({ error: 'Failed to fetch product templates' });
    }
});
exports.productTemplatesRouter.post('/', async (req, res) => {
    const { name, description, mappedAttributes } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    try {
        const template = await db_1.db.insert(db_1.productTemplates).values({
            name,
            description,
        }).returning().get();
        if (Array.isArray(mappedAttributes)) {
            for (const attr of mappedAttributes) {
                await db_1.db.insert(db_1.productTemplateAttributes).values({
                    templateId: template.id,
                    attributeId: attr.attributeId,
                    isVariantDefining: attr.isVariantDefining === true,
                }).run();
            }
        }
        res.status(201).json(template);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to create product template', error);
        res.status(400).json({ error: 'Failed to create product template' });
    }
});
exports.productTemplatesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { name, description, isActive, mappedAttributes } = req.body;
    const existing = await db_1.db.select().from(db_1.productTemplates).where((0, drizzle_orm_1.eq)(db_1.productTemplates.id, id)).get();
    if (!existing)
        return res.status(404).json({ error: 'Template not found' });
    try {
        const updateData = {};
        if (name)
            updateData.name = name;
        if (description !== undefined)
            updateData.description = description;
        if (typeof isActive === 'boolean')
            updateData.isActive = isActive;
        await db_1.db.update(db_1.productTemplates).set(updateData).where((0, drizzle_orm_1.eq)(db_1.productTemplates.id, id)).run();
        if (Array.isArray(mappedAttributes)) {
            await db_1.db.delete(db_1.productTemplateAttributes).where((0, drizzle_orm_1.eq)(db_1.productTemplateAttributes.templateId, id)).run();
            for (const attr of mappedAttributes) {
                await db_1.db.insert(db_1.productTemplateAttributes).values({
                    templateId: id,
                    attributeId: attr.attributeId,
                    isVariantDefining: attr.isVariantDefining === true,
                }).run();
            }
        }
        const updated = await db_1.db.select().from(db_1.productTemplates).where((0, drizzle_orm_1.eq)(db_1.productTemplates.id, id)).get();
        res.json(updated);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to update product template', error);
        res.status(400).json({ error: 'Failed to update product template' });
    }
});
exports.productTemplatesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        await db_1.db.delete(db_1.productTemplateAttributes).where((0, drizzle_orm_1.eq)(db_1.productTemplateAttributes.templateId, id)).run();
        await db_1.db.delete(db_1.productTemplates).where((0, drizzle_orm_1.eq)(db_1.productTemplates.id, id)).run();
        res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete product template', error);
        res.status(400).json({ error: 'Failed to delete product template' });
    }
});

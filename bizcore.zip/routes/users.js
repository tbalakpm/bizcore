"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersRouter = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const password_util_1 = require("../utils/password.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.usersRouter = express_1.default.Router();
const userPublicSelect = {
    id: db_1.users.id,
    username: db_1.users.username,
    firstName: db_1.users.firstName,
    lastName: db_1.users.lastName,
    role: db_1.users.role,
    permissions: db_1.users.permissions,
    isActive: db_1.users.isActive,
    createdAt: db_1.users.createdAt,
    updatedAt: db_1.users.updatedAt,
};
exports.usersRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['username', 'firstName', 'lastName', 'role'];
        const sortableFields = ['id', ...filterableFields, 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.users[field];
                if (column && 'name' in column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Always filter only Active records along with any filter params
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.users.isActive, isActive));
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.users[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.users.id));
        }
        // Build the query
        const baseQuery = db_1.db.select(userPublicSelect).from(db_1.users);
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const countResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.users);
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(db_1.users)
                .where(whereCondition))[0].count
            : countResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched users list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch users', error);
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});
exports.usersRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid product ID' });
    }
    const user = await db_1.db.select(userPublicSelect).from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).get();
    if (!user) {
        logger_service_1.LogService.warn('User not found', { userId: id });
        return res.status(404).json({ error: req.i18n?.t('user.notFound') });
    }
    logger_service_1.LogService.info('Fetched user details', { userId: id, username: user.username });
    res.json(user);
});
exports.usersRouter.post('/', async (req, res) => {
    const { username, password, firstName, lastName, role, isActive, permissions } = req.body;
    const pwd = password;
    if (!username)
        return res.status(400).json({ error: 'Name is required' });
    if (!pwd)
        return res.status(400).json({ error: 'Password is required' });
    if (!(0, password_util_1.isStrongPassword)(pwd)) {
        return res.status(400).json({ error: 'Password must be at least 8 chars with upper, lower and number' });
    }
    try {
        const user = await db_1.db
            .insert(db_1.users)
            .values({
            username,
            passwordHash: await bcryptjs_1.default.hash(pwd, 10),
            firstName,
            lastName,
            role: role || 'user',
            isActive: isActive !== false,
            permissions: permissions ? JSON.stringify(permissions) : '{}',
        })
            .returning(userPublicSelect)
            .get();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_USER',
            entity: 'USER',
            entityId: user.id,
            newValue: user,
        });
        logger_service_1.LogService.info('User created successfully', { userId: user.id, username: user.username });
        res.status(201).json(user);
    }
    catch (err) {
        logger_service_1.LogService.warn('Failed to create user - likely already exists', { username });
        res.status(400).json({ error: req.i18n?.t('user.exists') });
    }
});
exports.usersRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { username, firstName, lastName, role, isActive, permissions } = req.body;
    const oldUser = await db_1.db.select(userPublicSelect).from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).get();
    if (!oldUser) {
        logger_service_1.LogService.warn('User not found for update', { userId: id });
        return res.status(404).json({ error: req.i18n?.t('user.notFound') });
    }
    const updateData = {};
    if (username)
        updateData.username = username;
    if (firstName)
        updateData.firstName = firstName;
    if (lastName)
        updateData.lastName = lastName;
    if (role)
        updateData.role = role;
    if (typeof isActive === 'boolean')
        updateData.isActive = isActive;
    if (permissions)
        updateData.permissions = JSON.stringify(permissions);
    await db_1.db
        .update(db_1.users)
        .set(updateData)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, id))
        .run();
    const updatedUser = await db_1.db.select(userPublicSelect).from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).get();
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_USER',
        entity: 'USER',
        entityId: id,
        oldValue: oldUser,
        newValue: updatedUser,
    });
    logger_service_1.LogService.info('User updated successfully', { userId: id, username: updatedUser?.username });
    res.json(updatedUser);
});
exports.usersRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const user = await db_1.db.select(userPublicSelect).from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).get();
    if (!user) {
        logger_service_1.LogService.warn('User not found for deletion', { userId: id });
        return res.status(404).json({ error: req.i18n?.t('user.notFound') });
    }
    await db_1.db.delete(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_USER',
        entity: 'USER',
        entityId: id,
        oldValue: user,
    });
    logger_service_1.LogService.info('User deleted successfully', { userId: id, username: user.username });
    res.status(204).send();
});
exports.usersRouter.post('/:id/reset-password', async (req, res) => {
    const idStr = req.params.id;
    const id = parseInt(idStr, 10);
    const { newPassword } = req.body;
    if (!newPassword || !(0, password_util_1.isStrongPassword)(newPassword)) {
        return res.status(400).json({ error: 'New password is too weak' });
    }
    const user = await db_1.db.select().from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.id, id)).get();
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }
    const passwordHash = await bcryptjs_1.default.hash(newPassword, 10);
    await db_1.db
        .update(db_1.users)
        .set({ passwordHash, mustChangePassword: true })
        .where((0, drizzle_orm_1.eq)(db_1.users.id, id))
        .run();
    await (0, audit_service_1.auditLog)({
        action: 'RESET_PASSWORD',
        entity: 'USER',
        entityId: id,
    });
    logger_service_1.LogService.info('User password reset by admin', { userId: id });
    res.json({ message: 'Password reset successful. User must change it on next login.' });
});

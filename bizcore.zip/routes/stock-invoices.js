"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stockInvoicesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const serial_number_service_1 = require("../services/serial-number.service");
const product_serial_number_service_1 = require("../services/product-serial-number.service");
const list_query_util_1 = require("../utils/list-query.util");
const date_util_1 = require("../utils/date.util");
const number_util_1 = require("../utils/number.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
// barcode printing support
const PdfPrinter = require('pdfmake/js/printer').default;
const bwip_js_1 = __importDefault(require("bwip-js"));
exports.stockInvoicesRouter = express_1.default.Router();
const processInvoiceItems = async (tx, stockInvoiceId, items) => {
    let totalQty = 0;
    let totalAmount = 0;
    for (const item of items) {
        const qty = (0, number_util_1.toPositiveNumber)(item.qty, 0);
        if (qty <= 0) {
            throw new Error('Item qty must be greater than zero');
        }
        const unitPriceRaw = item.unitPrice ?? 0;
        const unitPrice = (0, number_util_1.toPositiveNumber)(unitPriceRaw, 0);
        const lineTotal = (0, number_util_1.toPositiveNumber)(item.lineTotal, Number((qty * unitPrice).toFixed(2)));
        let inventoryId = item.inventoryId;
        if (!inventoryId) {
            if (!item.productId) {
                throw new Error('Each item requires either inventoryId or productId');
            }
            const product = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, item.productId)).get();
            if (!product) {
                throw new Error(`Product not found for productId=${item.productId}`);
            }
            // Check if product is bundle and trackBundleGtn is disabled
            if (product.productType === 'bundle' && product.trackBundleGtn === false) {
                const { productBundles } = await Promise.resolve().then(() => __importStar(require('../db')));
                const bundles = await tx.select().from(productBundles).where((0, drizzle_orm_1.eq)(productBundles.bundleProductId, product.id)).all();
                let baseTotal = 0;
                const comps = [];
                for (const b of bundles) {
                    const cProduct = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, b.productId)).get();
                    if (cProduct) {
                        const bVal = b.quantity * (0, number_util_1.toPositiveNumber)(cProduct.unitPrice, 1);
                        baseTotal += bVal;
                        comps.push({ b, cProduct, bVal });
                    }
                }
                for (const c of comps) {
                    const compQty = qty * c.b.quantity;
                    const compUnitPrice = baseTotal > 0 ? (unitPrice * c.bVal / baseTotal) / c.b.quantity : 0;
                    items.push({
                        ...item,
                        productId: c.cProduct.id,
                        qty: compQty,
                        unitPrice: compUnitPrice,
                        lineTotal: Number((compQty * compUnitPrice).toFixed(2)),
                        gtn: undefined, // ensure gtn is re-generated or blank for component
                    });
                }
                // Skip adding the bundle itself since we've queued its components
                continue;
            }
            if (item.gtn) {
                // Manual GTN provided
                const createdInventory = await tx
                    .insert(db_1.inventories)
                    .values({
                    productId: product.id,
                    gtn: item.gtn,
                    qtyPerUnit: product.qtyPerUnit,
                    hsnSac: item.hsnSac ?? product.hsnSac,
                    taxRate: (0, number_util_1.toNumber)(item.taxRate) ?? product.taxRate,
                    buyingPrice: (0, number_util_1.toNumber)(unitPrice) ?? product.unitPrice,
                    sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : product.unitPrice,
                    unitsInStock: (0, number_util_1.toNumber)(qty),
                    location: item.location,
                })
                    .returning({ id: db_1.inventories.id })
                    .get();
                await tx
                    .insert(db_1.stockInvoiceItems)
                    .values({
                    stockInvoiceId: stockInvoiceId,
                    inventoryId: createdInventory.id,
                    qty: (0, number_util_1.toNumber)(qty),
                    unitPrice: (0, number_util_1.toNumber)(unitPrice),
                    marginType: (item.marginType ?? 'none'),
                    marginPct: (0, number_util_1.toNumber)(item.marginPct) ?? 0,
                    marginAmount: (0, number_util_1.toNumber)(item.marginAmount) ?? 0,
                    sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) ?? 0,
                })
                    .run();
            }
            else {
                // Auto GTN Generation logic
                const gtnConfig = await product_serial_number_service_1.productSerialNumberService.resolveGtnConfiguration(product.id, tx);
                const genType = gtnConfig.generation.toUpperCase();
                if (genType === 'TAG') {
                    // TAG: Each quantity gets a distinct inventory row with qty 1
                    for (let i = 0; i < qty; i++) {
                        const generatedGtn = await product_serial_number_service_1.productSerialNumberService.generateGtn(product.id, tx);
                        const createdInventory = await tx
                            .insert(db_1.inventories)
                            .values({
                            productId: product.id,
                            gtn: generatedGtn,
                            qtyPerUnit: product.qtyPerUnit,
                            hsnSac: item.hsnSac ?? product.hsnSac,
                            taxRate: (0, number_util_1.toNumber)(item.taxRate) ?? product.taxRate,
                            buyingPrice: (0, number_util_1.toNumber)(unitPrice) ?? product.unitPrice,
                            sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : product.unitPrice,
                            unitsInStock: 1,
                            location: item.location,
                        })
                            .returning({ id: db_1.inventories.id })
                            .get();
                        await tx
                            .insert(db_1.stockInvoiceItems)
                            .values({
                            stockInvoiceId: stockInvoiceId,
                            inventoryId: createdInventory.id,
                            qty: 1,
                            unitPrice: (0, number_util_1.toNumber)(unitPrice),
                            marginType: (item.marginType ?? 'none'),
                            marginPct: (0, number_util_1.toNumber)(item.marginPct) ?? 0,
                            marginAmount: (0, number_util_1.toNumber)(item.marginAmount) ?? 0,
                            sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) ?? 0,
                        })
                            .run();
                    }
                }
                else {
                    // CODE or BATCH or others: 1 row for the full quantity
                    const generatedGtn = await product_serial_number_service_1.productSerialNumberService.generateGtn(product.id, tx);
                    const createdInventory = await tx
                        .insert(db_1.inventories)
                        .values({
                        productId: product.id,
                        gtn: generatedGtn,
                        qtyPerUnit: product.qtyPerUnit,
                        hsnSac: item.hsnSac ?? product.hsnSac,
                        taxRate: (0, number_util_1.toNumber)(item.taxRate) ?? product.taxRate,
                        buyingPrice: (0, number_util_1.toNumber)(unitPrice) ?? product.unitPrice,
                        sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : product.unitPrice,
                        unitsInStock: (0, number_util_1.toNumber)(qty),
                        location: item.location,
                    })
                        .returning({ id: db_1.inventories.id })
                        .get();
                    await tx
                        .insert(db_1.stockInvoiceItems)
                        .values({
                        stockInvoiceId: stockInvoiceId,
                        inventoryId: createdInventory.id,
                        qty: (0, number_util_1.toNumber)(qty),
                        unitPrice: (0, number_util_1.toNumber)(unitPrice),
                        marginType: (item.marginType ?? 'none'),
                        marginPct: (0, number_util_1.toNumber)(item.marginPct) ?? 0,
                        marginAmount: (0, number_util_1.toNumber)(item.marginAmount) ?? 0,
                        sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) ?? 0,
                    })
                        .run();
                }
            }
        }
        else {
            // Appending to an existing inventoryId
            const inventory = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventoryId)).get();
            if (!inventory) {
                throw new Error(`Inventory not found for inventoryId=${inventoryId}`);
            }
            const updatedUnitsInStock = (inventory.unitsInStock ?? 0) + qty;
            const updatingPayload = { unitsInStock: updatedUnitsInStock };
            if (item.sellingPrice !== undefined) {
                updatingPayload.sellingPrice = (0, number_util_1.toNumber)(item.sellingPrice);
            }
            await tx
                .update(db_1.inventories)
                .set(updatingPayload)
                .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
                .run();
            await tx
                .insert(db_1.stockInvoiceItems)
                .values({
                stockInvoiceId: stockInvoiceId,
                inventoryId: inventory.id,
                qty: (0, number_util_1.toNumber)(qty),
                unitPrice: (0, number_util_1.toNumber)(unitPrice),
                marginType: (item.marginType ?? 'none'),
                marginPct: (0, number_util_1.toNumber)(item.marginPct) ?? 0,
                marginAmount: (0, number_util_1.toNumber)(item.marginAmount) ?? 0,
                sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) ?? 0,
            })
                .run();
        }
        totalQty += qty;
        totalAmount += lineTotal;
    }
    return {
        totalQty,
        totalAmount,
    };
};
exports.stockInvoicesRouter.get('/', async (req, res) => {
    try {
        const { limit, offset, pageNum } = (0, list_query_util_1.parsePagination)({
            limit: req.query.limit,
            offset: req.query.offset,
            page: req.query.page,
            pageNum: req.query.pageNum,
        });
        const filters = [];
        if (req.query.invoiceNumber) {
            filters.push((0, drizzle_orm_1.like)(db_1.stockInvoices.invoiceNumber, `%${req.query.invoiceNumber}%`));
        }
        if (req.query.invoiceDate) {
            filters.push((0, drizzle_orm_1.eq)(db_1.stockInvoices.invoiceDate, req.query.invoiceDate));
        }
        if (req.query.minAmount) {
            const minAmount = Number(req.query.minAmount);
            if (!Number.isNaN(minAmount)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.stockInvoices.totalAmount} AS REAL) >= ${minAmount}`);
            }
        }
        if (req.query.maxAmount) {
            const maxAmount = Number(req.query.maxAmount);
            if (!Number.isNaN(maxAmount)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.stockInvoices.totalAmount} AS REAL) <= ${maxAmount}`);
            }
        }
        const sortableFields = ['id', 'invoiceNumber', 'invoiceDate', 'totalQty', 'totalAmount'];
        const isSortableField = (value) => sortableFields.includes(value);
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.stockInvoices[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        if (orderBy.length === 0) {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.stockInvoices.id));
        }
        const baseQuery = db_1.db.select().from(db_1.stockInvoices);
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const query = whereCondition ? baseQuery.where(whereCondition) : baseQuery;
        const totalResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.stockInvoices);
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(db_1.stockInvoices)
                .where(whereCondition))[0].count
            : totalResult[0].count;
        const data = await query
            .orderBy(...orderBy)
            .limit(limit)
            .offset(offset)
            .all();
        logger_service_1.LogService.info('Fetched stock invoices list', { count: data.length, total: filteredCount });
        res.json({
            data,
            pagination: (0, list_query_util_1.toPagination)(limit, offset, filteredCount, pageNum),
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch stock invoices', error);
        res.status(500).json({ error: 'Failed to fetch stock invoices' });
    }
});
// helper for barcode labels used by both json and pdf endpoints
const buildBarcodeLabels = (invoice) => {
    const labels = [];
    for (const item of invoice.items ?? []) {
        const barcodeValue = String(item.gtn ?? item.productCode ?? '').trim();
        if (!barcodeValue) {
            continue;
        }
        const qty = Math.max(1, Math.round(Number(item.qty ?? 1)));
        const title = String(item.productName ?? item.productCode ?? 'Product');
        const subtitle = `Rs. ${Number(item.unitPrice ?? 0).toFixed(2)}`;
        for (let i = 0; i < qty; i += 1) {
            labels.push({ title, code: barcodeValue, subtitle });
        }
    }
    return labels;
};
exports.stockInvoicesRouter.get('/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid stock invoice ID' });
        }
        const invoice = await db_1.db.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
        if (!invoice) {
            return res.status(404).json({ error: 'Stock invoice not found' });
        }
        const items = await db_1.db
            .select({
            id: db_1.stockInvoiceItems.id,
            stockInvoiceId: db_1.stockInvoiceItems.stockInvoiceId,
            inventoryId: db_1.stockInvoiceItems.inventoryId,
            qty: db_1.stockInvoiceItems.qty,
            unitPrice: db_1.stockInvoiceItems.unitPrice,
            marginType: db_1.stockInvoiceItems.marginType,
            marginPct: db_1.stockInvoiceItems.marginPct,
            marginAmount: db_1.stockInvoiceItems.marginAmount,
            sellingPrice: db_1.stockInvoiceItems.sellingPrice,
            lineTotal: db_1.stockInvoiceItems.lineTotal,
            productId: db_1.inventories.productId,
            gtn: db_1.inventories.gtn,
            hsnSac: db_1.inventories.hsnSac,
            taxRate: db_1.inventories.taxRate,
            productCode: db_1.products.code,
            productName: db_1.products.name,
        })
            .from(db_1.stockInvoiceItems)
            .innerJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.inventories.id, db_1.stockInvoiceItems.inventoryId))
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id))
            .all();
        return res.json({ ...invoice, items });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch stock invoice', error);
        return res.status(500).json({ error: 'Failed to fetch stock invoice' });
    }
});
// return barcode labels (title, code, subtitle) for a stock invoice
exports.stockInvoicesRouter.get('/:id/barcodes', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid stock invoice ID' });
        }
        const invoice = await db_1.db.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
        if (!invoice) {
            return res.status(404).json({ error: 'Stock invoice not found' });
        }
        const items = await db_1.db
            .select({
            id: db_1.stockInvoiceItems.id,
            stockInvoiceId: db_1.stockInvoiceItems.stockInvoiceId,
            inventoryId: db_1.stockInvoiceItems.inventoryId,
            qty: db_1.stockInvoiceItems.qty,
            unitPrice: db_1.stockInvoiceItems.unitPrice,
            marginType: db_1.stockInvoiceItems.marginType,
            marginPct: db_1.stockInvoiceItems.marginPct,
            marginAmount: db_1.stockInvoiceItems.marginAmount,
            sellingPrice: db_1.stockInvoiceItems.sellingPrice,
            lineTotal: db_1.stockInvoiceItems.lineTotal,
            productId: db_1.inventories.productId,
            gtn: db_1.inventories.gtn,
            hsnSac: db_1.inventories.hsnSac,
            taxRate: db_1.inventories.taxRate,
            productCode: db_1.products.code,
            productName: db_1.products.name,
        })
            .from(db_1.stockInvoiceItems)
            .innerJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.inventories.id, db_1.stockInvoiceItems.inventoryId))
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id))
            .all();
        const labels = buildBarcodeLabels({ items: items });
        logger_service_1.LogService.info('Generated barcode labels (JSON)', { stockInvoiceId: id, labelCount: labels.length });
        return res.json({ labels });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch barcode labels', error, { stockInvoiceId: id });
        return res.status(500).json({ error: 'Failed to fetch barcode labels' });
    }
});
// generate a PDF of barcode labels
exports.stockInvoicesRouter.get('/:id/barcodes/pdf', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid stock invoice ID' });
        }
        const invoice = await db_1.db.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
        if (!invoice) {
            return res.status(404).json({ error: 'Stock invoice not found' });
        }
        const items = await db_1.db
            .select({
            id: db_1.stockInvoiceItems.id,
            stockInvoiceId: db_1.stockInvoiceItems.stockInvoiceId,
            inventoryId: db_1.stockInvoiceItems.inventoryId,
            qty: db_1.stockInvoiceItems.qty,
            unitPrice: db_1.stockInvoiceItems.unitPrice,
            marginType: db_1.stockInvoiceItems.marginType,
            marginPct: db_1.stockInvoiceItems.marginPct,
            marginAmount: db_1.stockInvoiceItems.marginAmount,
            sellingPrice: db_1.stockInvoiceItems.sellingPrice,
            lineTotal: db_1.stockInvoiceItems.lineTotal,
            productId: db_1.inventories.productId,
            gtn: db_1.inventories.gtn,
            hsnSac: db_1.inventories.hsnSac,
            taxRate: db_1.inventories.taxRate,
            productCode: db_1.products.code,
            productName: db_1.products.name,
        })
            .from(db_1.stockInvoiceItems)
            .innerJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.inventories.id, db_1.stockInvoiceItems.inventoryId))
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id))
            .all();
        const labels = buildBarcodeLabels({ items: items });
        if (labels.length === 0) {
            return res.status(404).json({ error: 'No barcode data available for this invoice' });
        }
        const fonts = {
            Helvetica: {
                normal: 'Helvetica',
                bold: 'Helvetica-Bold',
                italics: 'Helvetica-Oblique',
                bolditalics: 'Helvetica-BoldOblique'
            }
        };
        const URLResolver = require('pdfmake/js/URLResolver').default;
        const virtualfs = require('pdfmake/js/virtual-fs').default;
        const printer = new PdfPrinter(fonts, virtualfs, new URLResolver(virtualfs));
        const content = [];
        for (let i = 0; i < labels.length; i++) {
            const label = labels[i];
            const pageBreak = i < labels.length - 1 ? 'after' : undefined;
            content.push({
                text: label.title,
                fontSize: 12,
                bold: true,
                alignment: 'center',
                margin: [0, 0, 0, 10]
            });
            try {
                const png = await bwip_js_1.default.toBuffer({
                    bcid: 'code128',
                    text: label.code,
                    scale: 3,
                    includetext: false,
                });
                const b64 = png.toString('base64');
                content.push({
                    image: `data:image/png;base64,${b64}`,
                    width: 200,
                    alignment: 'center',
                    margin: [0, 0, 0, 10]
                });
            }
            catch (err) {
                logger_service_1.LogService.error('barcode generation failed', err);
                // fall back to text
                content.push({
                    text: label.code,
                    fontSize: 10,
                    alignment: 'center',
                    margin: [0, 0, 0, 10]
                });
            }
            content.push({
                text: label.code,
                fontSize: 10,
                alignment: 'center',
                margin: [0, 0, 0, 5]
            });
            content.push({
                text: label.subtitle,
                fontSize: 9,
                alignment: 'center',
                pageBreak: pageBreak
            });
        }
        const docDefinition = {
            content,
            pageSize: 'A4',
            pageMargins: [40, 40, 40, 40],
            defaultStyle: {
                font: 'Helvetica'
            }
        };
        res.setHeader('Content-Type', 'application/pdf');
        const pdfDoc = await printer.createPdfKitDocument(docDefinition);
        logger_service_1.LogService.info('Generated barcode PDF', { stockInvoiceId: id, labelCount: labels.length });
        pdfDoc.pipe(res);
        pdfDoc.end();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to generate barcode PDF', error, { stockInvoiceId: id });
        return res.status(500).json({ error: 'Failed to generate barcode PDF' });
    }
});
exports.stockInvoicesRouter.post('/', async (req, res) => {
    try {
        const body = req.body;
        const items = body.items ?? [];
        if (items.length === 0) {
            return res.status(400).json({ error: 'At least one item is required' });
        }
        const created = await db_1.db.transaction(async (tx) => {
            const invoiceNumber = body.invoiceNumber || (await serial_number_service_1.serialNumberService.generateInvoiceNumber('stockInvoice', tx));
            const insertedInvoice = await tx
                .insert(db_1.stockInvoices)
                .values({
                invoiceNumber,
                invoiceDate: (0, date_util_1.normalizeDate)(body.invoiceDate),
                totalQty: (0, number_util_1.toNumber)(body.totalQty),
                totalAmount: (0, number_util_1.toNumber)(body.totalAmount),
            })
                .returning()
                .get();
            const totals = await processInvoiceItems(tx, insertedInvoice.id, items);
            await tx
                .update(db_1.stockInvoices)
                .set({
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? totals.totalQty,
                totalAmount: (0, number_util_1.toNumber)(body.totalAmount) ?? totals.totalAmount,
            })
                .where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, insertedInvoice.id))
                .run();
            return tx.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, insertedInvoice.id)).get();
        });
        if (!created) {
            throw new Error('Failed to retrieve created invoice');
        }
        const itemsWithDetails = await db_1.db
            .select()
            .from(db_1.stockInvoiceItems)
            .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, created.id))
            .all();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_STOCK_INVOICE',
            entity: 'STOCK_INVOICE',
            entityId: created.id,
            newValue: { ...created, items: itemsWithDetails },
        });
        logger_service_1.LogService.info('Stock invoice created successfully', { stockInvoiceId: created.id, invoiceNumber: created.invoiceNumber });
        return res.status(201).json(created);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to create stock invoice', error, { body: req.body });
        return res.status(400).json({ error: error.message || 'Failed to create stock invoice' });
    }
});
exports.stockInvoicesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid stock invoice ID' });
        }
        const body = req.body;
        const items = body.items ?? [];
        if (items.length === 0) {
            return res.status(400).json({ error: 'At least one item is required' });
        }
        const updated = await db_1.db.transaction(async (tx) => {
            const existing = await tx.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
            if (!existing) {
                throw new Error('Stock invoice not found');
            }
            const existingItems = await tx
                .select()
                .from(db_1.stockInvoiceItems)
                .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id))
                .all();
            if (existingItems.length > 0) {
                const inventoryIds = [...new Set(existingItems.map((item) => item.inventoryId))];
                const inventoryRows = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.inArray)(db_1.inventories.id, inventoryIds)).all();
                const inventoryMap = new Map(inventoryRows.map((row) => [row.id, row]));
                for (const item of existingItems) {
                    const inventory = inventoryMap.get(item.inventoryId);
                    if (!inventory) {
                        continue;
                    }
                    const qty = Number(item.qty ?? 0);
                    // Add inventory units back to stock
                    const nextUnitsInStock = (inventory.unitsInStock ?? 0) - qty;
                    await tx
                        .update(db_1.inventories)
                        .set({ unitsInStock: nextUnitsInStock })
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
                        .run();
                    inventoryMap.set(inventory.id, { ...inventory, unitsInStock: nextUnitsInStock });
                }
                await tx.delete(db_1.stockInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id)).run();
            }
            const totals = await processInvoiceItems(tx, id, items);
            await tx
                .update(db_1.stockInvoices)
                .set({
                invoiceNumber: body.invoiceNumber ?? existing.invoiceNumber,
                invoiceDate: body.invoiceDate ?? existing.invoiceDate,
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? totals.totalQty,
                totalAmount: (0, number_util_1.toNumber)(body.totalAmount) ?? totals.totalAmount,
            })
                .where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id))
                .run();
            return tx.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
        });
        if (!updated) {
            throw new Error('Failed to retrieve updated invoice');
        }
        // Capture states after transaction for audit log
        const oldInvoiceState = await db_1.db.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
        const oldItemsState = await db_1.db.select().from(db_1.stockInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id)).all();
        const itemsWithDetails = await db_1.db
            .select()
            .from(db_1.stockInvoiceItems)
            .where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, updated.id))
            .all();
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_STOCK_INVOICE',
            entity: 'STOCK_INVOICE',
            entityId: id,
            oldValue: { ...oldInvoiceState, items: oldItemsState },
            newValue: { ...updated, items: itemsWithDetails },
        });
        logger_service_1.LogService.info('Stock invoice updated successfully', { stockInvoiceId: id, invoiceNumber: updated.invoiceNumber });
        return res.json(updated);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to update stock invoice', error, { stockInvoiceId: id });
        return res.status(400).json({ error: error.message || 'Failed to update stock invoice' });
    }
});
exports.stockInvoicesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid stock invoice ID' });
        }
        await db_1.db.transaction(async (tx) => {
            const existing = await tx
                .select({ id: db_1.stockInvoices.id })
                .from(db_1.stockInvoices)
                .where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id))
                .get();
            if (!existing) {
                throw new Error('Stock invoice not found');
            }
            const items = await tx.select().from(db_1.stockInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id)).all();
            if (items.length > 0) {
                const inventoryIds = [...new Set(items.map((item) => item.inventoryId))];
                const inventoryRows = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.inArray)(db_1.inventories.id, inventoryIds)).all();
                const inventoryMap = new Map(inventoryRows.map((row) => [row.id, row]));
                for (const item of items) {
                    const inventory = inventoryMap.get(item.inventoryId);
                    if (!inventory) {
                        continue;
                    }
                    const qty = Number(item.qty ?? 0);
                    // Revert stock qty update
                    const nextUnitsInStock = (inventory.unitsInStock ?? 0) - qty;
                    await tx
                        .update(db_1.inventories)
                        .set({ unitsInStock: nextUnitsInStock })
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
                        .run();
                    inventoryMap.set(inventory.id, { ...inventory, unitsInStock: nextUnitsInStock });
                }
            }
            await tx.delete(db_1.stockInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.stockInvoiceItems.stockInvoiceId, id)).run();
            await tx.delete(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).run();
        });
        logger_service_1.LogService.info('Stock invoice deleted successfully', { stockInvoiceId: id });
        return res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete stock invoice', error, { stockInvoiceId: id });
        return res.status(404).json({ error: error.message || 'Failed to delete stock invoice' });
    }
});

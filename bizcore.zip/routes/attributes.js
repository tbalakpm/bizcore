"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.attributesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.attributesRouter = express_1.default.Router();
exports.attributesRouter.get('/', async (req, res) => {
    try {
        const data = await db_1.db.select().from(db_1.attributes).all();
        // Parse JSON fields
        const parsedData = data.map(item => ({
            ...item,
            options: item.options ? JSON.parse(item.options) : null,
            defaultValue: item.defaultValue ? JSON.parse(item.defaultValue) : null,
        }));
        res.json(parsedData);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch attributes', error);
        res.status(500).json({ error: 'Failed to fetch attributes' });
    }
});
exports.attributesRouter.post('/', async (req, res) => {
    const { name, description, type, options, defaultValue, isActive } = req.body;
    try {
        const result = await db_1.db.insert(db_1.attributes).values({
            name,
            description,
            type,
            options: options ? JSON.stringify(options) : null,
            defaultValue: defaultValue ? JSON.stringify(defaultValue) : null,
            isActive: isActive !== false
        }).returning().get();
        const finalResult = {
            ...result,
            options: result.options ? JSON.parse(result.options) : null,
            defaultValue: result.defaultValue ? JSON.parse(result.defaultValue) : null,
        };
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_ATTRIBUTE',
            entity: 'ATTRIBUTE',
            entityId: result.id,
            newValue: finalResult,
        });
        res.status(201).json(finalResult);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to create attribute', error);
        res.status(400).json({ error: 'Failed to create attribute' });
    }
});
exports.attributesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { name, description, type, options, defaultValue, isActive } = req.body;
    try {
        const old = await db_1.db.select().from(db_1.attributes).where((0, drizzle_orm_1.eq)(db_1.attributes.id, id)).get();
        if (!old)
            return res.status(404).json({ error: 'Attribute not found' });
        const result = await db_1.db.update(db_1.attributes).set({
            name,
            description,
            type,
            options: options ? JSON.stringify(options) : null,
            defaultValue: defaultValue ? JSON.stringify(defaultValue) : null,
            isActive: typeof isActive === 'boolean' ? isActive : old.isActive,
            updatedAt: (0, drizzle_orm_1.sql) `CURRENT_TIMESTAMP`
        }).where((0, drizzle_orm_1.eq)(db_1.attributes.id, id)).returning().get();
        const finalResult = {
            ...result,
            options: result.options ? JSON.parse(result.options) : null,
            defaultValue: result.defaultValue ? JSON.parse(result.defaultValue) : null,
        };
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_ATTRIBUTE',
            entity: 'ATTRIBUTE',
            entityId: id,
            oldValue: old,
            newValue: finalResult,
        });
        res.json(finalResult);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to update attribute', error);
        res.status(400).json({ error: 'Failed to update attribute' });
    }
});
exports.attributesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        const old = await db_1.db.select().from(db_1.attributes).where((0, drizzle_orm_1.eq)(db_1.attributes.id, id)).get();
        if (!old)
            return res.status(404).json({ error: 'Attribute not found' });
        await db_1.db.delete(db_1.attributes).where((0, drizzle_orm_1.eq)(db_1.attributes.id, id)).run();
        await (0, audit_service_1.auditLog)({
            action: 'DELETE_ATTRIBUTE',
            entity: 'ATTRIBUTE',
            entityId: id,
            oldValue: old,
        });
        res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete attribute', error);
        res.status(400).json({ error: 'Failed to delete attribute' });
    }
});

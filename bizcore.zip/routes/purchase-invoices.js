"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.purchaseInvoicesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const number_util_1 = require("../utils/number.util");
const product_serial_number_service_1 = require("../services/product-serial-number.service");
const serial_number_service_1 = require("../services/serial-number.service");
const purchase_invoice_report_1 = require("../services/pdf/reports/purchase-invoice.report");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.purchaseInvoicesRouter = express_1.default.Router();
exports.purchaseInvoicesRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['invoiceNumber', 'refNumber'];
        const sortableFields = ['id', 'invoiceNumber', 'invoiceDate', 'refNumber', 'subtotal', 'totalQty', 'netAmount', 'supplierName'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.purchaseInvoices[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        if (req.query.supplierId) {
            filters.push((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.supplierId, parseInt(req.query.supplierId, 10)));
        }
        if (req.query.minAmount) {
            filters.push((0, drizzle_orm_1.sql) `${db_1.purchaseInvoices.netAmount} >= ${(0, number_util_1.toNumber)(req.query.minAmount)}`);
        }
        if (req.query.maxAmount) {
            filters.push((0, drizzle_orm_1.sql) `${db_1.purchaseInvoices.netAmount} <= ${(0, number_util_1.toNumber)(req.query.maxAmount)}`);
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                if (field === 'supplierName') {
                    orderBy.push(dir(db_1.suppliers.name));
                }
                else {
                    const column = db_1.purchaseInvoices[field];
                    if (column) {
                        orderBy.push(dir(column));
                    }
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.purchaseInvoices.id));
        }
        // Build the query
        const baseQuery = db_1.db
            .select({
            ...(0, drizzle_orm_1.getTableColumns)(db_1.purchaseInvoices),
            supplierName: db_1.suppliers.name,
        })
            .from(db_1.purchaseInvoices)
            .leftJoin(db_1.suppliers, (0, drizzle_orm_1.eq)(db_1.purchaseInvoices.supplierId, db_1.suppliers.id));
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCountResult = await db_1.db
            .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
            .from(db_1.purchaseInvoices)
            .where(whereCondition || (0, drizzle_orm_1.sql) `1=1`);
        const filteredCount = filteredCountResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched purchase invoices list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch purchase invoices', error);
        res.status(500).json({ error: 'Failed to fetch purchase invoices' });
    }
});
exports.purchaseInvoicesRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid invoice ID' });
    }
    const invoice = await db_1.db
        .select({
        ...(0, drizzle_orm_1.getTableColumns)(db_1.purchaseInvoices),
        supplierName: db_1.suppliers.name,
    })
        .from(db_1.purchaseInvoices)
        .leftJoin(db_1.suppliers, (0, drizzle_orm_1.eq)(db_1.purchaseInvoices.supplierId, db_1.suppliers.id))
        .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id))
        .get();
    if (!invoice) {
        logger_service_1.LogService.warn('Purchase invoice not found', { purchaseInvoiceId: id });
        return res.status(404).json({ error: 'Purchase invoice not found' });
    }
    logger_service_1.LogService.info('Fetched purchase invoice details', { purchaseInvoiceId: id, invoiceNumber: invoice.invoiceNumber });
    const items = await db_1.db
        .select({
        ...(0, drizzle_orm_1.getTableColumns)(db_1.purchaseInvoiceItems),
        productName: db_1.products.name,
        productCode: db_1.products.code,
        productId: db_1.products.id,
        gtn: db_1.inventories.gtn,
    })
        .from(db_1.purchaseInvoiceItems)
        .leftJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.inventoryId, db_1.inventories.id))
        .leftJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.inventories.productId, db_1.products.id))
        .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id))
        .all();
    res.json({ ...invoice, items });
});
const processPurchaseInvoiceItems = async (tx, purchaseInvoiceId, items) => {
    let totalQty = 0;
    let subtotal = 0;
    for (const item of items) {
        const qty = (0, number_util_1.toPositiveNumber)(item.qty, 0);
        if (qty <= 0)
            continue;
        const unitPrice = (0, number_util_1.toPositiveNumber)(item.unitPrice, 0);
        let inventoryId = item.inventoryId;
        if (!inventoryId && item.productId) {
            const product = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, item.productId)).get();
            if (!product)
                continue;
            // Check if product is bundle and trackBundleGtn is disabled
            if (product.productType === 'bundle' && product.trackBundleGtn === false) {
                const { productBundles } = await Promise.resolve().then(() => __importStar(require('../db')));
                const bundles = await tx.select().from(productBundles).where((0, drizzle_orm_1.eq)(productBundles.bundleProductId, product.id)).all();
                let baseTotal = 0;
                const comps = [];
                for (const b of bundles) {
                    const cProduct = await tx.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, b.productId)).get();
                    if (cProduct) {
                        const bVal = b.quantity * (0, number_util_1.toPositiveNumber)(cProduct.unitPrice, 1);
                        baseTotal += bVal;
                        comps.push({ b, cProduct, bVal });
                    }
                }
                for (const c of comps) {
                    const compQty = qty * c.b.quantity;
                    const compUnitPrice = baseTotal > 0 ? (unitPrice * c.bVal / baseTotal) / c.b.quantity : 0;
                    items.push({
                        ...item,
                        productId: c.cProduct.id,
                        qty: compQty,
                        unitPrice: compUnitPrice,
                        lineTotal: Number((compQty * compUnitPrice).toFixed(2)),
                        gtn: undefined, // ensure gtn is re-generated or blank for component
                        inventoryId: undefined,
                    });
                }
                continue;
            }
            if (item.gtn) {
                // Manual GTN
                let inv = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(db_1.inventories.productId, product.id), (0, drizzle_orm_1.eq)(db_1.inventories.gtn, item.gtn))).get();
                if (inv) {
                    const updateData = { unitsInStock: (inv.unitsInStock || 0) + qty };
                    if (item.sellingPrice !== undefined && item.sellingPrice !== null) {
                        updateData.sellingPrice = (0, number_util_1.toNumber)(item.sellingPrice);
                    }
                    await tx.update(db_1.inventories).set(updateData).where((0, drizzle_orm_1.eq)(db_1.inventories.id, inv.id)).run();
                    inventoryId = inv.id;
                }
                else {
                    const newInv = await tx
                        .insert(db_1.inventories)
                        .values({
                        productId: product.id,
                        gtn: item.gtn,
                        qtyPerUnit: product.qtyPerUnit,
                        hsnSac: item.hsnSac || product.hsnSac,
                        taxRate: (0, number_util_1.toNumber)(item.taxPct) || product.taxRate,
                        buyingPrice: (0, number_util_1.toNumber)(unitPrice) || product.unitPrice,
                        sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : undefined,
                        unitsInStock: (0, number_util_1.toNumber)(qty),
                    })
                        .returning({ id: db_1.inventories.id })
                        .get();
                    inventoryId = newInv.id;
                }
            }
            else {
                // Auto GTN
                const gtnConfig = await product_serial_number_service_1.productSerialNumberService.resolveGtnConfiguration(product.id, tx);
                const genType = gtnConfig.generation.toUpperCase();
                if (genType === 'TAG') {
                    for (let i = 0; i < qty; i++) {
                        const generatedGtn = await product_serial_number_service_1.productSerialNumberService.generateGtn(product.id, tx);
                        const inv = await tx
                            .insert(db_1.inventories)
                            .values({
                            productId: product.id,
                            gtn: generatedGtn,
                            qtyPerUnit: product.qtyPerUnit,
                            hsnSac: item.hsnSac || product.hsnSac,
                            taxRate: (0, number_util_1.toNumber)(item.taxPct) || product.taxRate,
                            buyingPrice: (0, number_util_1.toNumber)(unitPrice) || product.unitPrice,
                            sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : undefined,
                            unitsInStock: 1,
                        })
                            .returning({ id: db_1.inventories.id })
                            .get();
                        await tx.insert(db_1.purchaseInvoiceItems).values({
                            purchaseInvoiceId,
                            inventoryId: inv.id,
                            qty: 1,
                            unitPrice: (0, number_util_1.toNumber)(unitPrice),
                            discountType: item.discountType,
                            discountPct: (0, number_util_1.toNumber)(item.discountPct),
                            discountAmount: (0, number_util_1.toNumber)(item.discountAmount),
                            taxPct: (0, number_util_1.toNumber)(item.taxPct),
                            marginType: item.marginType || 'none',
                            marginPct: (0, number_util_1.toNumber)(item.marginPct) || 0,
                            marginAmount: (0, number_util_1.toNumber)(item.marginAmount) || 0,
                            sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) || 0,
                        }).run();
                    }
                    inventoryId = -1; // Marker that we handled insertion
                }
                else {
                    const generatedGtn = await product_serial_number_service_1.productSerialNumberService.generateGtn(product.id, tx);
                    let inv;
                    if (generatedGtn) {
                        inv = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(db_1.inventories.productId, product.id), (0, drizzle_orm_1.eq)(db_1.inventories.gtn, generatedGtn))).get();
                    }
                    if (inv) {
                        const updateData = { unitsInStock: (inv.unitsInStock || 0) + qty };
                        if (item.sellingPrice !== undefined && item.sellingPrice !== null) {
                            updateData.sellingPrice = (0, number_util_1.toNumber)(item.sellingPrice);
                        }
                        await tx.update(db_1.inventories).set(updateData).where((0, drizzle_orm_1.eq)(db_1.inventories.id, inv.id)).run();
                        inventoryId = inv.id;
                    }
                    else {
                        const newInv = await tx
                            .insert(db_1.inventories)
                            .values({
                            productId: product.id,
                            gtn: generatedGtn,
                            qtyPerUnit: product.qtyPerUnit,
                            hsnSac: item.hsnSac || product.hsnSac,
                            taxRate: (0, number_util_1.toNumber)(item.taxPct) || product.taxRate,
                            buyingPrice: (0, number_util_1.toNumber)(unitPrice) || product.unitPrice,
                            sellingPrice: item.sellingPrice ? (0, number_util_1.toNumber)(item.sellingPrice) : undefined,
                            unitsInStock: (0, number_util_1.toNumber)(qty),
                        })
                            .returning({ id: db_1.inventories.id })
                            .get();
                        inventoryId = newInv.id;
                    }
                }
            }
        }
        else if (inventoryId) {
            const existing = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventoryId)).get();
            if (existing) {
                const updateData = { unitsInStock: (existing.unitsInStock || 0) + qty };
                if (item.sellingPrice !== undefined && item.sellingPrice !== null) {
                    updateData.sellingPrice = (0, number_util_1.toNumericString)(item.sellingPrice);
                }
                await tx.update(db_1.inventories)
                    .set(updateData)
                    .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventoryId))
                    .run();
            }
        }
        if (inventoryId && inventoryId !== -1) {
            await tx.insert(db_1.purchaseInvoiceItems).values({
                purchaseInvoiceId,
                inventoryId,
                qty: (0, number_util_1.toNumber)(qty),
                unitPrice: (0, number_util_1.toNumber)(unitPrice),
                discountType: item.discountType,
                discountPct: (0, number_util_1.toNumber)(item.discountPct),
                discountAmount: (0, number_util_1.toNumber)(item.discountAmount),
                taxPct: (0, number_util_1.toNumber)(item.taxPct),
                marginType: item.marginType || 'none',
                marginPct: (0, number_util_1.toNumber)(item.marginPct) || 0,
                marginAmount: (0, number_util_1.toNumber)(item.marginAmount) || 0,
                sellingPrice: (0, number_util_1.toNumber)(item.sellingPrice) || 0,
            }).run();
        }
        totalQty += qty;
        subtotal += (qty * unitPrice);
    }
    return { totalQty, subtotal };
};
exports.purchaseInvoicesRouter.post('/', async (req, res) => {
    const body = req.body;
    const items = body.items ?? [];
    if (!body.invoiceDate || !body.supplierId || !items.length) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    try {
        const result = await db_1.db.transaction(async (tx) => {
            // 1. Insert invoice header
            const invoiceNumber = body.invoiceNumber || (await serial_number_service_1.serialNumberService.generateInvoiceNumber('purchaseInvoice', tx));
            const invoice = await tx
                .insert(db_1.purchaseInvoices)
                .values({
                invoiceNumber,
                invoiceDate: body.invoiceDate,
                supplierId: body.supplierId,
                refNumber: body.refNumber,
                refDate: body.refDate,
                subtotal: (0, number_util_1.toNumber)(body.subtotal),
                totalQty: (0, number_util_1.toNumber)(body.totalQty),
                discountType: body.discountType,
                discountPct: (0, number_util_1.toNumber)(body.discountPct),
                discountAmount: (0, number_util_1.toNumber)(body.discountAmount),
                totalTaxAmount: (0, number_util_1.toNumber)(body.taxAmount),
                roundOff: (0, number_util_1.toNumber)(body.roundOff),
            })
                .returning()
                .get();
            // 2. Process items
            const totals = await processPurchaseInvoiceItems(tx, invoice.id, items);
            // 3. Update header if totals were not provided or need sync
            await tx
                .update(db_1.purchaseInvoices)
                .set({
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? (0, number_util_1.toNumber)(totals.totalQty),
                subtotal: (0, number_util_1.toNumber)(body.subtotal) ?? (0, number_util_1.toNumber)(totals.subtotal),
            })
                .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, invoice.id))
                .run();
            return tx.select().from(db_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, invoice.id)).get();
        });
        if (!result) {
            throw new Error('Failed to retrieve created purchase invoice');
        }
        const itemsWithDetails = await db_1.db
            .select()
            .from(db_1.purchaseInvoiceItems)
            .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, result.id))
            .all();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_PURCHASE_INVOICE',
            entity: 'PURCHASE_INVOICE',
            entityId: result.id,
            newValue: { ...result, items: itemsWithDetails },
        });
        logger_service_1.LogService.info('Purchase invoice created successfully', { purchaseInvoiceId: result.id, invoiceNumber: result.invoiceNumber });
        res.status(201).json(result);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create purchase invoice', err, { body: req.body });
        res.status(400).json({ error: err.message || 'Failed to create purchase invoice' });
    }
});
exports.purchaseInvoicesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const body = req.body;
    const items = body.items ?? [];
    try {
        const oldInvoice = await db_1.db.select().from(db_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id)).get();
        if (!oldInvoice) {
            logger_service_1.LogService.warn('Purchase invoice not found for update', { purchaseInvoiceId: id });
            return res.status(404).json({ error: 'Invoice not found' });
        }
        const oldItems = await db_1.db.select().from(db_1.purchaseInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id)).all();
        await db_1.db.transaction(async (tx) => {
            // 1. Reverse stock
            for (const oldItem of oldItems) {
                const inv = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.eq)(db_1.inventories.id, oldItem.inventoryId)).get();
                if (inv) {
                    await tx.update(db_1.inventories)
                        .set({ unitsInStock: (inv.unitsInStock || 0) - Number(oldItem.qty || 0) })
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inv.id))
                        .run();
                }
            }
            await tx.delete(db_1.purchaseInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id)).run();
            // 2. Update header
            await tx
                .update(db_1.purchaseInvoices)
                .set({
                invoiceNumber: body.invoiceNumber ?? oldInvoice.invoiceNumber,
                invoiceDate: body.invoiceDate ?? oldInvoice.invoiceDate,
                supplierId: body.supplierId ?? oldInvoice.supplierId,
                refNumber: body.refNumber ?? oldInvoice.refNumber,
                refDate: body.refDate ?? oldInvoice.refDate,
                subtotal: (0, number_util_1.toNumber)(body.subtotal) ?? oldInvoice.subtotal,
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? oldInvoice.totalQty,
                discountType: body.discountType ?? oldInvoice.discountType,
                discountPct: (0, number_util_1.toNumber)(body.discountPct) ?? oldInvoice.discountPct,
                discountAmount: (0, number_util_1.toNumber)(body.discountAmount) ?? oldInvoice.discountAmount,
                totalTaxAmount: (0, number_util_1.toNumber)(body.taxAmount) ?? oldInvoice.totalTaxAmount,
                roundOff: (0, number_util_1.toNumber)(body.roundOff) ?? oldInvoice.roundOff,
            })
                .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id))
                .run();
            // 3. Process new items
            const totals = await processPurchaseInvoiceItems(tx, id, items);
            // 4. Update header with recalculated totals if needed
            await tx
                .update(db_1.purchaseInvoices)
                .set({
                totalQty: (0, number_util_1.toNumber)(body.totalQty) || totals.totalQty,
                subtotal: (0, number_util_1.toNumber)(body.subtotal) || totals.subtotal,
            })
                .where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id))
                .run();
        });
        const updatedInvoice = await db_1.db.select().from(db_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id)).get();
        const updatedItems = await db_1.db.select().from(db_1.purchaseInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id)).all();
        if (updatedInvoice) {
            await (0, audit_service_1.auditLog)({
                action: 'UPDATE_PURCHASE_INVOICE',
                entity: 'PURCHASE_INVOICE',
                entityId: id,
                oldValue: { ...oldInvoice, items: oldItems },
                newValue: { ...updatedInvoice, items: updatedItems },
            });
            logger_service_1.LogService.info('Purchase invoice updated successfully', { purchaseInvoiceId: id, invoiceNumber: updatedInvoice.invoiceNumber });
        }
        res.json(updatedInvoice);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to update purchase invoice', err, { purchaseInvoiceId: id });
        res.status(400).json({ error: err.message || 'Failed to update' });
    }
});
exports.purchaseInvoicesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        const oldInvoice = await db_1.db.select().from(db_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id)).get();
        if (!oldInvoice) {
            logger_service_1.LogService.warn('Purchase invoice not found for deletion', { purchaseInvoiceId: id });
            return res.status(404).json({ error: 'Invoice not found' });
        }
        const oldItems = await db_1.db.select().from(db_1.purchaseInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id)).all();
        await db_1.db.transaction(async (tx) => {
            // Reverse stock
            for (const item of oldItems) {
                const inv = await tx.select().from(db_1.inventories).where((0, drizzle_orm_1.eq)(db_1.inventories.id, item.inventoryId)).get();
                if (inv) {
                    await tx.update(db_1.inventories)
                        .set({ unitsInStock: (inv.unitsInStock || 0) - Number(item.qty || 0) })
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inv.id))
                        .run();
                }
            }
            await tx.delete(db_1.purchaseInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoiceItems.purchaseInvoiceId, id)).run();
            await tx.delete(db_1.purchaseInvoices).where((0, drizzle_orm_1.eq)(db_1.purchaseInvoices.id, id)).run();
        });
        await (0, audit_service_1.auditLog)({
            action: 'DELETE_PURCHASE_INVOICE',
            entity: 'PURCHASE_INVOICE',
            entityId: id,
            oldValue: { ...oldInvoice, items: oldItems },
        });
        logger_service_1.LogService.info('Purchase invoice deleted successfully', { purchaseInvoiceId: id, invoiceNumber: oldInvoice.invoiceNumber });
        res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete purchase invoice', error, { purchaseInvoiceId: id });
        res.status(400).json({ error: 'Failed to delete purchase invoice' });
    }
});
// PDF Generation Route 
exports.purchaseInvoicesRouter.get('/:id/pdf', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid purchase invoice ID' });
        }
        await (0, purchase_invoice_report_1.renderPurchaseInvoice)(id, db_1.db, res);
        logger_service_1.LogService.info('Generated purchase invoice PDF', { purchaseInvoiceId: id });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to generate purchase invoice PDF', error, { purchaseInvoiceId: id });
        res.status(500).json({ error: 'Failed to generate PDF' });
    }
});

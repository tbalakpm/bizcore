"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRouter = void 0;
const node_crypto_1 = __importDefault(require("node:crypto"));
const express_1 = __importDefault(require("express"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const drizzle_orm_1 = require("drizzle-orm");
const config_1 = require("../config");
const db_1 = require("../db");
const rate_limit_1 = require("../middleware/rate-limit");
const password_util_1 = require("../utils/password.util");
exports.authRouter = express_1.default.Router();
// ─── Helpers ─────────────────────────────────────────────────────────────────
const COOKIE_NAME = 'bc_rt';
/** SHA-256 hash of a raw token (hex string) */
function hashToken(raw) {
    return node_crypto_1.default.createHash('sha256').update(raw).digest('hex');
}
/** Sign a short-lived access JWT */
function signAccessToken(user) {
    return jsonwebtoken_1.default.sign({
        sub: user.id,
        username: user.username,
        role: user.role,
        permissions: JSON.parse(user.permissions || '{}'),
        mustChangePassword: user.mustChangePassword,
    }, config_1.config.jwtSecret, { expiresIn: config_1.config.accessTokenExpirySeconds });
}
/** Create a new DB refresh token record and return the raw value to set as cookie */
async function createRefreshToken(userId) {
    // Clean up old tokens for this user before creating a new one
    const now = new Date();
    const raw = node_crypto_1.default.randomBytes(40).toString('hex');
    const tokenHash = hashToken(raw);
    const expiresAt = new Date(now.getTime() + config_1.config.refreshTokenExpiryDays * 24 * 60 * 60 * 1000);
    await db_1.db.insert(db_1.refreshTokens).values({ userId, tokenHash, expiresAt });
    return raw;
}
/** Send the refresh token as an httpOnly cookie */
function setRefreshCookie(res, raw) {
    res.cookie(COOKIE_NAME, raw, {
        httpOnly: true,
        secure: !config_1.config.isDevelopment,
        sameSite: 'lax',
        maxAge: config_1.config.refreshTokenExpiryDays * 24 * 60 * 60 * 1000,
        path: '/api/auth',
    });
}
/** Clear the refresh token cookie */
function clearRefreshCookie(res) {
    res.clearCookie(COOKIE_NAME, { path: '/api/auth' });
}
// ─── Routes ──────────────────────────────────────────────────────────────────
exports.authRouter.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: req.i18n?.t('auth.invalid') });
    }
    if (!(0, password_util_1.isStrongPassword)(password)) {
        return res.status(400).json({ error: 'Password must be at least 8 chars with upper, lower and number' });
    }
    const existing = await db_1.db.select({ id: db_1.users.id }).from(db_1.users).where((0, drizzle_orm_1.eq)(db_1.users.username, username)).get();
    if (existing) {
        return res.status(400).json({ error: req.i18n?.t('user.exists') });
    }
    const passwordHash = await bcryptjs_1.default.hash(password, 10);
    await db_1.db.insert(db_1.users).values({ username, passwordHash }).returning({ id: db_1.users.id }).get();
    return res.status(201).json({ message: req.i18n?.t('user.created') });
});
exports.authRouter.post('/login', (0, rate_limit_1.rateLimit)({ windowMs: 60 * 1000, max: 10 }), async (req, res) => {
    const { username, password } = req.body;
    const user = await db_1.db
        .select({
        id: db_1.users.id,
        username: db_1.users.username,
        passwordHash: db_1.users.passwordHash,
        role: db_1.users.role,
        permissions: db_1.users.permissions,
        isActive: db_1.users.isActive,
        mustChangePassword: db_1.users.mustChangePassword,
    })
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.username, username))
        .get();
    if (!user)
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    if (!user.isActive)
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    const valid = await bcryptjs_1.default.compare(password, user.passwordHash);
    if (!valid)
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    const accessToken = signAccessToken(user);
    const rawRefreshToken = await createRefreshToken(user.id);
    setRefreshCookie(res, rawRefreshToken);
    return res.json({ token: accessToken });
});
/** Rotate refresh token: validate cookie → revoke old → issue new pair */
exports.authRouter.post('/refresh', async (req, res) => {
    const raw = req.cookies?.[COOKIE_NAME];
    if (!raw) {
        return res.status(401).json({ error: 'No refresh token' });
    }
    const tokenHash = hashToken(raw);
    const now = new Date();
    const record = await db_1.db
        .select()
        .from(db_1.refreshTokens)
        .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(db_1.refreshTokens.tokenHash, tokenHash), (0, drizzle_orm_1.isNull)(db_1.refreshTokens.revokedAt), (0, drizzle_orm_1.gt)(db_1.refreshTokens.expiresAt, now)))
        .get();
    if (!record) {
        clearRefreshCookie(res);
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    }
    // Revoke the used token (rotation — one-time use)
    await db_1.db
        .update(db_1.refreshTokens)
        .set({ revokedAt: now })
        .where((0, drizzle_orm_1.eq)(db_1.refreshTokens.id, record.id));
    // Load user
    const user = await db_1.db
        .select({
        id: db_1.users.id,
        username: db_1.users.username,
        role: db_1.users.role,
        permissions: db_1.users.permissions,
        isActive: db_1.users.isActive,
        mustChangePassword: db_1.users.mustChangePassword,
    })
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, record.userId))
        .get();
    if (!user || !user.isActive) {
        clearRefreshCookie(res);
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    }
    const accessToken = signAccessToken(user);
    const newRawRefreshToken = await createRefreshToken(user.id);
    setRefreshCookie(res, newRawRefreshToken);
    return res.json({ token: accessToken });
});
/** Revoke refresh token and clear cookie */
exports.authRouter.post('/logout', async (req, res) => {
    const raw = req.cookies?.[COOKIE_NAME];
    if (raw) {
        const tokenHash = hashToken(raw);
        await db_1.db
            .update(db_1.refreshTokens)
            .set({ revokedAt: new Date() })
            .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(db_1.refreshTokens.tokenHash, tokenHash), (0, drizzle_orm_1.isNull)(db_1.refreshTokens.revokedAt)));
    }
    clearRefreshCookie(res);
    return res.json({ message: 'Logged out' });
});
/** Change password: required if mustChangePassword is true */
exports.authRouter.post('/change-password', async (req, res) => {
    const { newPassword } = req.body;
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    const token = authHeader.slice(7);
    try {
        const payload = jsonwebtoken_1.default.verify(token, config_1.config.jwtSecret);
        const userId = parseInt(payload.sub, 10);
        if (!newPassword || !(0, password_util_1.isStrongPassword)(newPassword)) {
            return res.status(400).json({ error: 'Password must be at least 8 chars with upper, lower and number' });
        }
        const passwordHash = await bcryptjs_1.default.hash(newPassword, 10);
        await db_1.db
            .update(db_1.users)
            .set({ passwordHash, mustChangePassword: false })
            .where((0, drizzle_orm_1.eq)(db_1.users.id, userId));
        return res.json({ message: 'Password changed successfully' });
    }
    catch (err) {
        return res.status(401).json({ error: 'Invalid token' });
    }
});

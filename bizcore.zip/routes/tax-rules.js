"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.taxRulesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
const number_util_1 = require("../utils/number.util");
exports.taxRulesRouter = express_1.default.Router();
exports.taxRulesRouter.get('/', async (req, res) => {
    try {
        const data = await db_1.db.select().from(db_1.taxRules).all();
        logger_service_1.LogService.info('Fetched tax rules list', { count: data.length });
        res.json({ data });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch tax rules', error);
        res.status(500).json({ error: 'Failed to fetch tax rules' });
    }
});
exports.taxRulesRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid tax rule ID' });
    }
    const taxRule = await db_1.db.select().from(db_1.taxRules).where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id)).get();
    if (!taxRule) {
        logger_service_1.LogService.warn('Tax rule not found', { taxRuleId: id });
        return res.status(404).json({ error: 'Tax rule not found' });
    }
    res.json(taxRule);
});
exports.taxRulesRouter.post('/', async (req, res) => {
    const { hsnCodeStartsWith, minPrice, maxPrice, tax_rate, effective_from } = req.body;
    try {
        const inserted = await db_1.db
            .insert(db_1.taxRules)
            .values({
            hsnCodeStartsWith: hsnCodeStartsWith || '',
            minPrice: (0, number_util_1.toNumber)(minPrice),
            maxPrice: (0, number_util_1.toNumber)(maxPrice),
            tax_rate: (0, number_util_1.toNumber)(tax_rate),
            effective_from: effective_from || new Date().toISOString().split('T')[0],
        })
            .returning()
            .get();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_TAX_RULE',
            entity: 'TAX_RULE',
            entityId: inserted.id,
            newValue: inserted,
        });
        logger_service_1.LogService.info('Tax rule created successfully', { taxRuleId: inserted.id });
        res.status(201).json(inserted);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create tax rule', err);
        res.status(400).json({ error: 'Failed to create tax rule' });
    }
});
exports.taxRulesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const oldTaxRule = await db_1.db.select().from(db_1.taxRules).where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id)).get();
    if (!oldTaxRule) {
        return res.status(404).json({ error: 'Tax rule not found' });
    }
    const { hsnCodeStartsWith, minPrice, maxPrice, tax_rate, effective_from } = req.body;
    const updateData = {};
    if (hsnCodeStartsWith !== undefined)
        updateData.hsnCodeStartsWith = hsnCodeStartsWith;
    if (minPrice !== undefined)
        updateData.minPrice = (0, number_util_1.toNumber)(minPrice);
    if (maxPrice !== undefined)
        updateData.maxPrice = (0, number_util_1.toNumber)(maxPrice);
    if (tax_rate !== undefined)
        updateData.tax_rate = (0, number_util_1.toNumber)(tax_rate);
    if (effective_from !== undefined)
        updateData.effective_from = effective_from;
    await db_1.db
        .update(db_1.taxRules)
        .set(updateData)
        .where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id))
        .run();
    const updatedTaxRule = await db_1.db.select().from(db_1.taxRules).where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id)).get();
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_TAX_RULE',
        entity: 'TAX_RULE',
        entityId: id,
        oldValue: oldTaxRule,
        newValue: updatedTaxRule,
    });
    logger_service_1.LogService.info('Tax rule updated successfully', { taxRuleId: id });
    res.json(updatedTaxRule);
});
exports.taxRulesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const taxRule = await db_1.db.select().from(db_1.taxRules).where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id)).get();
    if (!taxRule) {
        return res.status(404).json({ error: 'Tax rule not found' });
    }
    await db_1.db.delete(db_1.taxRules).where((0, drizzle_orm_1.eq)(db_1.taxRules.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_TAX_RULE',
        entity: 'TAX_RULE',
        entityId: id,
        oldValue: taxRule,
    });
    logger_service_1.LogService.info('Tax rule deleted successfully', { taxRuleId: id });
    res.status(204).send();
});

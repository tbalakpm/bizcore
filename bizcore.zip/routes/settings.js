"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
exports.settingsRouter = express_1.default.Router();
exports.settingsRouter.get('/', async (_req, res) => {
    const data = await db_1.db.select().from(db_1.settings).orderBy(db_1.settings.id).all();
    res.json({ data });
});
exports.settingsRouter.get('/:key', async (req, res) => {
    const setting = await db_1.db.select().from(db_1.settings).where((0, drizzle_orm_1.eq)(db_1.settings.key, req.params.key)).get();
    if (!setting) {
        return res.status(404).json({ error: 'Setting not found' });
    }
    return res.json(setting);
});
exports.settingsRouter.put('/:key', async (req, res) => {
    const key = req.params.key;
    const { value } = req.body;
    const existing = await db_1.db.select().from(db_1.settings).where((0, drizzle_orm_1.eq)(db_1.settings.key, key)).get();
    if (!existing) {
        const created = await db_1.db.insert(db_1.settings).values({ key, value }).returning().get();
        return res.status(201).json(created);
    }
    await db_1.db.update(db_1.settings).set({ value }).where((0, drizzle_orm_1.eq)(db_1.settings.key, key)).run();
    const updated = await db_1.db.select().from(db_1.settings).where((0, drizzle_orm_1.eq)(db_1.settings.key, key)).get();
    return res.json(updated);
});

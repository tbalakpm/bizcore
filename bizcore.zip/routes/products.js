"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.productsRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.productsRouter = express_1.default.Router();
exports.productsRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['code', 'name', 'description', 'qtyPerUnit', 'hsnSac'];
        const sortableFields = [
            'id',
            ...filterableFields,
            'categoryName',
            'unitPrice',
            // 'unitsInStock',
            'isActive',
            // 'createdAt',
            // 'updatedAt',
        ];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.products[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Filter by categoryId (exact match)
        if (req.query.categoryId) {
            const categoryId = parseInt(req.query.categoryId, 10);
            if (!Number.isNaN(categoryId)) {
                filters.push((0, drizzle_orm_1.eq)(db_1.products.categoryId, categoryId));
            }
        }
        // Filter by categoryName (partial match) - remove this from here
        // Will be added after the join is established
        // Filter by active status
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.products.isActive, isActive));
        }
        // Filter by price range
        if (req.query.minPrice) {
            const minPrice = parseFloat(req.query.minPrice);
            if (!Number.isNaN(minPrice)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.products.unitPrice} AS REAL) >= ${minPrice}`);
            }
        }
        if (req.query.maxPrice) {
            const maxPrice = parseFloat(req.query.maxPrice);
            if (!Number.isNaN(maxPrice)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.products.unitPrice} AS REAL) <= ${maxPrice}`);
            }
        }
        // Filter by stock range
        // if (req.query.minStock) {
        //   const minStock = parseInt(req.query.minStock as string, 10);
        //   if (!Number.isNaN(minStock)) {
        //     filters.push(sql`${products.unitsInStock} >= ${minStock}`);
        //   }
        // }
        // if (req.query.maxStock) {
        //   const maxStock = parseInt(req.query.maxStock as string, 10);
        //   if (!Number.isNaN(maxStock)) {
        //     filters.push(sql`${products.unitsInStock} <= ${maxStock}`);
        //   }
        // }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                // Handle categoryName sorting (from joined categories table)
                if (field === 'categoryName') {
                    orderBy.push(dir(db_1.categories.name));
                }
                else {
                    const column = db_1.products[field];
                    if (column) {
                        orderBy.push(dir(column));
                    }
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.products.id));
        }
        // Build the query with join
        const baseQuery = db_1.db
            .select({
            id: db_1.products.id,
            code: db_1.products.code,
            name: db_1.products.name,
            description: db_1.products.description,
            categoryId: db_1.products.categoryId,
            categoryName: db_1.categories.name,
            brandId: db_1.products.brandId,
            qtyPerUnit: db_1.products.qtyPerUnit,
            unitPrice: db_1.products.unitPrice,
            hsnSac: db_1.products.hsnSac,
            taxRate: db_1.products.taxRate,
            gtnMode: db_1.products.gtnMode,
            gtnGeneration: db_1.products.gtnGeneration,
            useGlobal: db_1.products.useGlobal,
            trackBundleGtn: db_1.products.trackBundleGtn,
            //unitsInStock: products.unitsInStock,
            isActive: db_1.products.isActive,
            productType: db_1.products.productType,
            parentId: db_1.products.parentId,
            templateId: db_1.products.templateId,
            isTaxInclusive: db_1.products.isTaxInclusive,
            createdAt: db_1.products.createdAt,
            updatedAt: db_1.products.updatedAt,
        })
            .from(db_1.products)
            .leftJoin(db_1.categories, (0, drizzle_orm_1.eq)(db_1.categories.id, db_1.products.categoryId));
        // Add categoryName filter after join is established
        const allFilters = [...filters];
        if (req.query.categoryName) {
            allFilters.push((0, drizzle_orm_1.like)(db_1.categories.name, `%${req.query.categoryName}%`));
        }
        const query = allFilters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...allFilters)) : baseQuery;
        // Get total count
        const countResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.products);
        // Build count query with same filters including categoryName
        const countQuery = db_1.db
            .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
            .from(db_1.products)
            .leftJoin(db_1.categories, (0, drizzle_orm_1.eq)(db_1.categories.id, db_1.products.categoryId));
        const whereCondition = allFilters.length > 0 ? (0, drizzle_orm_1.and)(...allFilters) : undefined;
        const filteredCount = whereCondition ? (await countQuery.where(whereCondition))[0].count : countResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched products list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch products', error);
        res.status(500).json({ error: 'Failed to fetch products' });
    }
});
exports.productsRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid product ID' });
    }
    const product = await db_1.db.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, id)).get();
    if (!product) {
        logger_service_1.LogService.warn('Product not found', { productId: id });
        return res.status(404).json({ error: req.i18n?.t('product.notFound') || 'Product not found' });
    }
    logger_service_1.LogService.info('Fetched product details', { productId: id, productName: product.name });
    // Also fetch serial number config so the frontend can pre-populate gtnPrefix/gtnStartPos/gtnLength
    const serial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).get();
    // Fetch bundle items if productType is 'bundle'
    let bundleItems = [];
    if (product.productType === 'bundle') {
        bundleItems = await db_1.db.select({
            id: db_1.productBundles.id,
            productId: db_1.productBundles.productId,
            quantity: db_1.productBundles.quantity,
        })
            .from(db_1.productBundles)
            .where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id))
            .all();
    }
    // Fetch mapped attributes if templateId exists
    let mappedAttributes = [];
    if (product.templateId) {
        mappedAttributes = await db_1.db.select({
            id: db_1.productTemplateAttributes.id,
            attributeId: db_1.productTemplateAttributes.attributeId,
            name: db_1.attributes.name,
            type: db_1.attributes.type,
            isVariantDefining: db_1.productTemplateAttributes.isVariantDefining,
        })
            .from(db_1.productTemplateAttributes)
            .innerJoin(db_1.attributes, (0, drizzle_orm_1.eq)(db_1.attributes.id, db_1.productTemplateAttributes.attributeId))
            .where((0, drizzle_orm_1.eq)(db_1.productTemplateAttributes.templateId, product.templateId))
            .all();
    }
    // Fetch attribute values
    const attributeValues = await db_1.db.select({
        id: db_1.productAttributeValues.id,
        attributeId: db_1.productAttributeValues.attributeId,
        value: db_1.productAttributeValues.value,
    })
        .from(db_1.productAttributeValues)
        .where((0, drizzle_orm_1.eq)(db_1.productAttributeValues.productId, id))
        .all();
    // Fetch variants if this is a parent product
    let variants = [];
    variants = await db_1.db.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.parentId, id)).all();
    res.json({
        ...product,
        gtnPrefix: serial?.prefix ?? '',
        gtnStartPos: serial?.current ?? 1,
        gtnLength: serial?.length ?? 10,
        bundleItems,
        mappedAttributes,
        attributeValues: attributeValues.map(v => ({ ...v, value: JSON.parse(v.value) })),
        variants,
    });
});
exports.productsRouter.post('/', async (req, res) => {
    const { code, name, description, categoryId, brandId, qtyPerUnit, unitPrice, hsnSac, taxRate, gtnMode, gtnGeneration, gtnPrefix, gtnStartPos, gtnLength, useGlobal, trackBundleGtn, parentId, templateId, isActive, productType, isTaxInclusive, bundleItems, attributeValues, // [{ attributeId, value }]
     } = req.body;
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!categoryId)
        return res.status(400).json({ error: 'Category ID is required' });
    try {
        const product = await db_1.db
            .insert(db_1.products)
            .values({
            code,
            name,
            description,
            categoryId,
            brandId: brandId || null,
            qtyPerUnit,
            unitPrice: unitPrice?.toString(),
            hsnSac,
            taxRate: taxRate?.toString(),
            gtnMode: gtnMode,
            gtnGeneration: gtnGeneration,
            productType: (productType || 'simple'),
            parentId: parentId || null,
            templateId: templateId || null,
            useGlobal: useGlobal !== false,
            trackBundleGtn: trackBundleGtn !== false,
            isActive: isActive !== false,
            isTaxInclusive: isTaxInclusive === true,
        })
            .returning()
            .get();
        if (product.productType === 'bundle' && Array.isArray(bundleItems)) {
            for (const item of bundleItems) {
                await db_1.db.insert(db_1.productBundles).values({
                    bundleProductId: product.id,
                    productId: item.productId,
                    quantity: item.quantity,
                }).run();
            }
        }
        if (gtnMode !== 'manual' && (gtnGeneration === 'batch' || gtnGeneration === 'tag')) {
            // Ensure starting pos is valid
            const nextPos = parseInt(gtnStartPos, 10);
            const startPos = Number.isNaN(nextPos) ? 1 : nextPos;
            await db_1.db.insert(db_1.productSerialNumbers).values({
                productId: product.id,
                prefix: gtnPrefix || '',
                current: startPos,
                length: parseInt(gtnLength, 10) || 10,
            }).run();
        }
        // Save attribute values
        if (Array.isArray(attributeValues)) {
            for (const val of attributeValues) {
                await db_1.db.insert(db_1.productAttributeValues).values({
                    productId: product.id,
                    attributeId: val.attributeId,
                    value: JSON.stringify(val.value)
                }).run();
            }
        }
        const finalSerial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, product.id)).get();
        const finalBundle = await db_1.db.select().from(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, product.id)).all();
        const fullProduct = { ...product, serial: finalSerial, bundleItems: finalBundle };
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_PRODUCT',
            entity: 'PRODUCT',
            entityId: product.id,
            newValue: fullProduct,
        });
        logger_service_1.LogService.info('Product created successfully', { productId: product.id, productName: product.name });
        res.status(201).json(product);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create product', err, { code, name });
        res.status(400).json({
            error: req.i18n?.t('product.exists') || 'Product already exists',
        });
    }
});
exports.productsRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const { code, name, description, categoryId, brandId, qtyPerUnit, unitPrice, hsnSac, taxRate, gtnMode, gtnGeneration, gtnPrefix, gtnStartPos, gtnLength, useGlobal, trackBundleGtn, isActive, productType, parentId, templateId, bundleItems, attributeValues, isTaxInclusive, } = req.body;
    const product = await db_1.db.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, id)).get();
    if (!product)
        return res.status(404).json({ error: req.i18n?.t('product.notFound') || 'Product not found' });
    try {
        const oldSerial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).get();
        const oldBundle = await db_1.db.select().from(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id)).all();
        const oldProduct = { ...product, serial: oldSerial, bundleItems: oldBundle };
        // Update product entity
        const updateData = {};
        if (code)
            updateData.code = code;
        if (name !== undefined)
            updateData.name = name;
        if (description !== undefined)
            updateData.description = description;
        if (categoryId !== undefined)
            updateData.categoryId = categoryId;
        if (brandId !== undefined)
            updateData.brandId = brandId || null;
        if (qtyPerUnit !== undefined)
            updateData.qtyPerUnit = qtyPerUnit;
        if (unitPrice !== undefined)
            updateData.unitPrice = unitPrice?.toString();
        if (hsnSac !== undefined)
            updateData.hsnSac = hsnSac;
        if (taxRate !== undefined)
            updateData.taxRate = taxRate?.toString();
        if (gtnMode !== undefined)
            updateData.gtnMode = gtnMode;
        if (gtnGeneration !== undefined)
            updateData.gtnGeneration = gtnGeneration;
        if (useGlobal !== undefined)
            updateData.useGlobal = useGlobal;
        if (trackBundleGtn !== undefined)
            updateData.trackBundleGtn = trackBundleGtn;
        if (typeof isActive === 'boolean')
            updateData.isActive = isActive;
        if (productType)
            updateData.productType = productType;
        if (parentId !== undefined)
            updateData.parentId = parentId;
        if (templateId !== undefined)
            updateData.templateId = templateId;
        if (isTaxInclusive !== undefined)
            updateData.isTaxInclusive = isTaxInclusive;
        await db_1.db
            .update(db_1.products)
            .set(updateData)
            .where((0, drizzle_orm_1.eq)(db_1.products.id, id))
            .run();
        if ((productType || product.productType) === 'bundle' && Array.isArray(bundleItems)) {
            await db_1.db.delete(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id)).run();
            for (const item of bundleItems) {
                await db_1.db.insert(db_1.productBundles).values({
                    bundleProductId: id,
                    productId: item.productId,
                    quantity: item.quantity,
                }).run();
            }
        }
        else if ((productType || product.productType) === 'simple') {
            await db_1.db.delete(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id)).run();
        }
        const currentGtnMode = gtnMode !== undefined ? gtnMode : product.gtnMode;
        const currentGtnGeneration = gtnGeneration !== undefined ? gtnGeneration : product.gtnGeneration;
        if (currentGtnMode !== 'manual' && (currentGtnGeneration === 'batch' || currentGtnGeneration === 'tag')) {
            const nextPos = parseInt(gtnStartPos, 10);
            const startPos = Number.isNaN(nextPos) ? 1 : nextPos;
            const existingSerial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).get();
            if (existingSerial) {
                await db_1.db.update(db_1.productSerialNumbers).set({
                    prefix: gtnPrefix || '',
                    current: startPos,
                    length: parseInt(gtnLength, 10) || 10,
                }).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.id, existingSerial.id)).run();
            }
            else {
                await db_1.db.insert(db_1.productSerialNumbers).values({
                    productId: id,
                    prefix: gtnPrefix || '',
                    current: startPos,
                    length: parseInt(gtnLength, 10) || 10,
                }).run();
            }
        }
        else {
            await db_1.db.delete(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).run();
        }
        // Update attribute values
        if (Array.isArray(attributeValues)) {
            await db_1.db.delete(db_1.productAttributeValues).where((0, drizzle_orm_1.eq)(db_1.productAttributeValues.productId, id)).run();
            for (const val of attributeValues) {
                await db_1.db.insert(db_1.productAttributeValues).values({
                    productId: id,
                    attributeId: val.attributeId,
                    value: JSON.stringify(val.value)
                }).run();
            }
        }
        const updatedProductEntity = await db_1.db.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, id)).get();
        const updatedSerial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).get();
        const updatedBundle = await db_1.db.select().from(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id)).all();
        const updatedProduct = { ...updatedProductEntity, serial: updatedSerial, bundleItems: updatedBundle };
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_PRODUCT',
            entity: 'PRODUCT',
            entityId: id,
            oldValue: oldProduct,
            newValue: updatedProduct,
        });
        logger_service_1.LogService.info('Product updated successfully', { productId: id, productName: updatedProductEntity?.name });
        res.json(updatedProductEntity);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to update product', err, { productId: id });
        res.status(400).json({ error: 'Failed to update product' });
    }
});
exports.productsRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const product = await db_1.db.select().from(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, id)).get();
    if (!product) {
        logger_service_1.LogService.warn('Product not found for deletion', { productId: id });
        return res.status(404).json({ error: req.i18n?.t('product.notFound') || 'Product not found' });
    }
    const serial = await db_1.db.select().from(db_1.productSerialNumbers).where((0, drizzle_orm_1.eq)(db_1.productSerialNumbers.productId, id)).get();
    const bundleItems = await db_1.db.select().from(db_1.productBundles).where((0, drizzle_orm_1.eq)(db_1.productBundles.bundleProductId, id)).all();
    await db_1.db.delete(db_1.products).where((0, drizzle_orm_1.eq)(db_1.products.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_PRODUCT',
        entity: 'PRODUCT',
        entityId: id,
        oldValue: { ...product, serial, bundleItems },
    });
    logger_service_1.LogService.info('Product deleted successfully', { productId: id, productName: product.name });
    res.status(204).send();
});

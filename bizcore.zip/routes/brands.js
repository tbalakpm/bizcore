"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.brandsRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.brandsRouter = express_1.default.Router();
exports.brandsRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['code', 'name', 'description'];
        const sortableFields = ['id', ...filterableFields, 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.brands[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Filter by active status
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.brands.isActive, isActive));
        }
        // Filter by category
        if (req.query.categoryId) {
            const catId = parseInt(req.query.categoryId, 10);
            if (!Number.isNaN(catId)) {
                const brandIdsInCat = await db_1.db
                    .select({ id: db_1.brandCategories.brandId })
                    .from(db_1.brandCategories)
                    .where((0, drizzle_orm_1.eq)(db_1.brandCategories.categoryId, catId))
                    .all();
                const ids = brandIdsInCat.map((b) => b.id);
                if (ids.length > 0) {
                    filters.push((0, drizzle_orm_1.inArray)(db_1.brands.id, ids));
                }
                else {
                    // If no brands match the category, push a filter that returns nothing
                    filters.push((0, drizzle_orm_1.eq)(db_1.brands.id, -1));
                }
            }
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.brands[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.brands.id));
        }
        // Build the query
        const baseQuery = db_1.db.select({
            id: db_1.brands.id,
            code: db_1.brands.code,
            name: db_1.brands.name,
            description: db_1.brands.description,
            isActive: db_1.brands.isActive,
            createdAt: db_1.brands.createdAt,
            updatedAt: db_1.brands.updatedAt
        }).from(db_1.brands);
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const countResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.brands);
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(db_1.brands)
                .where(whereCondition))[0].count
            : countResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        // Fetch mappings for the fetched brands
        const brandIds = result.map((b) => b.id);
        let brandsWithCats = result.map(b => ({ ...b, categoryIds: [] }));
        if (brandIds.length > 0) {
            const mappings = await db_1.db
                .select()
                .from(db_1.brandCategories)
                .where((0, drizzle_orm_1.inArray)(db_1.brandCategories.brandId, brandIds))
                .all();
            brandsWithCats = result.map((b) => ({
                ...b,
                categoryIds: mappings
                    .filter((m) => m.brandId === b.id)
                    .map((m) => m.categoryId),
            }));
        }
        logger_service_1.LogService.info('Fetched brands list', { count: brandsWithCats.length, total: filteredCount });
        res.json({
            data: brandsWithCats,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch brands', error);
        res.status(500).json({ error: 'Failed to fetch brands' });
    }
});
exports.brandsRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid brand ID' });
    }
    const brand = await db_1.db.select().from(db_1.brands).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).get();
    if (!brand) {
        logger_service_1.LogService.warn('Brand not found', { brandId: id });
        return res.status(404).json({
            error: req.i18n?.t('brand.notFound') || 'Brand not found',
        });
    }
    const brandCategoriesList = await db_1.db
        .select({ categoryId: db_1.brandCategories.categoryId })
        .from(db_1.brandCategories)
        .where((0, drizzle_orm_1.eq)(db_1.brandCategories.brandId, id))
        .all();
    const categoryIds = brandCategoriesList.map((cb) => cb.categoryId);
    logger_service_1.LogService.info('Fetched brand details', { brandId: id, brandName: brand.name, categoryIds });
    res.json({ ...brand, categoryIds });
});
exports.brandsRouter.post('/', async (req, res) => {
    logger_service_1.LogService.info('Creating brand', { body: req.body });
    const { code, name, description, isActive, categoryIds } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    try {
        const result = await db_1.db.transaction(async (tx) => {
            const brand = await tx
                .insert(db_1.brands)
                .values({
                code,
                name,
                description,
                isActive: isActive !== false,
            })
                .returning()
                .get();
            if (categoryIds && Array.isArray(categoryIds)) {
                for (const catId of categoryIds) {
                    await tx.insert(db_1.brandCategories).values({
                        brandId: brand.id,
                        categoryId: catId,
                    }).run();
                }
            }
            return brand;
        });
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_BRAND',
            entity: 'BRAND',
            entityId: result.id,
            newValue: { ...result, categoryIds },
        });
        logger_service_1.LogService.info('Brand created successfully', { brandId: result.id, brandName: result.name });
        res.status(201).json({ ...result, categoryIds });
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create brand', err, { code, name });
        res.status(400).json({
            error: req.i18n?.t('brand.exists') || 'Brand already exists',
        });
    }
});
exports.brandsRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    logger_service_1.LogService.info('Updating brand', { brandId: id, body: req.body });
    const oldBrand = await db_1.db.select().from(db_1.brands).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).get();
    if (!oldBrand) {
        logger_service_1.LogService.warn('Brand not found for update', { brandId: id });
        return res.status(404).json({
            error: req.i18n?.t('brand.notFound') || 'Brand not found',
        });
    }
    const oldCategories = await db_1.db
        .select({ categoryId: db_1.brandCategories.categoryId })
        .from(db_1.brandCategories)
        .where((0, drizzle_orm_1.eq)(db_1.brandCategories.brandId, id))
        .all();
    const oldCategoryIds = oldCategories.map((c) => c.categoryId);
    const { code, name, description, isActive, categoryIds } = req.body;
    const updateData = {};
    if (code !== undefined)
        updateData.code = code;
    if (name !== undefined)
        updateData.name = name;
    if (description !== undefined)
        updateData.description = description;
    if (typeof isActive === 'boolean')
        updateData.isActive = isActive;
    const result = await db_1.db.transaction(async (tx) => {
        if (Object.keys(updateData).length > 0) {
            await tx.update(db_1.brands).set(updateData).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).run();
        }
        if (categoryIds !== undefined && Array.isArray(categoryIds)) {
            // Refresh categories
            await tx.delete(db_1.brandCategories).where((0, drizzle_orm_1.eq)(db_1.brandCategories.brandId, id)).run();
            for (const catId of categoryIds) {
                await tx.insert(db_1.brandCategories).values({
                    brandId: id,
                    categoryId: catId,
                }).run();
            }
        }
        const updatedBrand = await tx.select().from(db_1.brands).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).get();
        return updatedBrand;
    });
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_BRAND',
        entity: 'BRAND',
        entityId: id,
        oldValue: { ...oldBrand, categoryIds: oldCategoryIds },
        newValue: { ...result, categoryIds },
    });
    logger_service_1.LogService.info('Brand updated successfully', { brandId: id, brandName: result?.name });
    res.json({ ...result, categoryIds });
});
exports.brandsRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const brand = await db_1.db.select().from(db_1.brands).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).get();
    if (!brand) {
        logger_service_1.LogService.warn('Brand not found for deletion', { brandId: id });
        return res.status(404).json({
            error: req.i18n?.t('brand.notFound') || 'Brand not found',
        });
    }
    await db_1.db.delete(db_1.brands).where((0, drizzle_orm_1.eq)(db_1.brands.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_BRAND',
        entity: 'BRAND',
        entityId: id,
        oldValue: brand,
    });
    logger_service_1.LogService.info('Brand deleted successfully', { brandId: id, brandName: brand.name });
    res.status(204).send();
});

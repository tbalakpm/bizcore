"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.categoriesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.categoriesRouter = express_1.default.Router();
exports.categoriesRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['code', 'name', 'description'];
        const sortableFields = ['id', ...filterableFields, 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.categories[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Filter by active status
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.categories.isActive, isActive));
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.categories[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.categories.id));
        }
        // Build the query
        const baseQuery = db_1.db.select({
            id: db_1.categories.id,
            code: db_1.categories.code,
            name: db_1.categories.name,
            description: db_1.categories.description,
            parentCategoryId: db_1.categories.parentCategoryId,
            isActive: db_1.categories.isActive,
            createdAt: db_1.categories.createdAt,
            updatedAt: db_1.categories.updatedAt
        }).from(db_1.categories);
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const countResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.categories);
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(db_1.categories)
                .where(whereCondition))[0].count
            : countResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched categories list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch categories', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
});
exports.categoriesRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid category ID' });
    }
    const category = await db_1.db.select().from(db_1.categories).where((0, drizzle_orm_1.eq)(db_1.categories.id, id)).get();
    if (!category) {
        logger_service_1.LogService.warn('Category not found', { categoryId: id });
        return res.status(404).json({
            error: req.i18n?.t('category.notFound') || 'Category not found',
        });
    }
    logger_service_1.LogService.info('Fetched category details', { categoryId: id, categoryName: category.name });
    res.json(category);
});
exports.categoriesRouter.post('/', async (req, res) => {
    const { code, name, description, parentCategoryId, isActive } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    try {
        const category = await db_1.db
            .insert(db_1.categories)
            .values({
            code,
            name,
            description,
            parentCategoryId,
            isActive: isActive !== false,
        })
            .returning()
            .get();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_CATEGORY',
            entity: 'CATEGORY',
            entityId: category.id,
            newValue: category,
        });
        logger_service_1.LogService.info('Category created successfully', { categoryId: category.id, categoryName: category.name });
        res.status(201).json(category);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create category', err, { code, name });
        res.status(400).json({
            error: req.i18n?.t('category.exists') || 'Category already exists',
        });
    }
});
exports.categoriesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const oldCategory = await db_1.db.select().from(db_1.categories).where((0, drizzle_orm_1.eq)(db_1.categories.id, id)).get();
    if (!oldCategory) {
        logger_service_1.LogService.warn('Category not found for update', { categoryId: id });
        return res.status(404).json({
            error: req.i18n?.t('category.notFound') || 'Category not found',
        });
    }
    const { code, name, description, parentCategoryId, isActive } = req.body;
    const updateData = {};
    if (code !== undefined)
        updateData.code = code;
    if (name !== undefined)
        updateData.name = name;
    if (description !== undefined)
        updateData.description = description;
    if (parentCategoryId !== undefined)
        updateData.parentCategoryId = parentCategoryId;
    if (typeof isActive === 'boolean')
        updateData.isActive = isActive;
    await db_1.db
        .update(db_1.categories)
        .set(updateData)
        .where((0, drizzle_orm_1.eq)(db_1.categories.id, id))
        .run();
    const updatedCategory = await db_1.db.select().from(db_1.categories).where((0, drizzle_orm_1.eq)(db_1.categories.id, id)).get();
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_CATEGORY',
        entity: 'CATEGORY',
        entityId: id,
        oldValue: oldCategory,
        newValue: updatedCategory,
    });
    logger_service_1.LogService.info('Category updated successfully', { categoryId: id, categoryName: updatedCategory?.name });
    res.json(updatedCategory);
});
exports.categoriesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const category = await db_1.db.select().from(db_1.categories).where((0, drizzle_orm_1.eq)(db_1.categories.id, id)).get();
    if (!category) {
        logger_service_1.LogService.warn('Category not found for deletion', { categoryId: id });
        return res.status(404).json({
            error: req.i18n?.t('category.notFound') || 'Category not found',
        });
    }
    await db_1.db.delete(db_1.categories).where((0, drizzle_orm_1.eq)(db_1.categories.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_CATEGORY',
        entity: 'CATEGORY',
        entityId: id,
        oldValue: category,
    });
    logger_service_1.LogService.info('Category deleted successfully', { categoryId: id, categoryName: category.name });
    res.status(204).send();
});

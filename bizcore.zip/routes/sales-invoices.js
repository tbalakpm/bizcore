"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesInvoicesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const sales_invoice_report_1 = require("../services/pdf/reports/sales-invoice.report");
const serial_number_service_1 = require("../services/serial-number.service");
const date_util_1 = require("../utils/date.util");
const list_query_util_1 = require("../utils/list-query.util");
const number_util_1 = require("../utils/number.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.salesInvoicesRouter = express_1.default.Router();
const processInvoiceItems = async (tx, salesInvoiceId, items) => {
    const invoice = await tx.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, salesInvoiceId)).get();
    const customer = invoice ? await tx.select().from(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, invoice.customerId)).get() : null;
    const settingRows = await tx.select().from(db_1.settings).all();
    const s = Object.fromEntries(settingRows.map(r => [r.key, r.value]));
    const companyGstin = s['company_gstin'] || '';
    const customerGstin = customer?.gstin || '';
    const isInterState = companyGstin && customerGstin && companyGstin.substring(0, 2) !== customerGstin.substring(0, 2);
    let totalQty = 0;
    let subtotal = 0;
    let totalTax = 0;
    let totalDiscount = 0;
    for (const item of items) {
        const qty = (0, number_util_1.toPositiveNumber)(item.qty, 0);
        if (qty <= 0) {
            throw new Error('Item qty must be greater than zero');
        }
        const unitPrice = (0, number_util_1.toPositiveNumber)(item.unitPrice, 0);
        // const lineTotal = toPositiveNumber(item.lineTotal, Number((qty * unitPrice).toFixed(2)));
        const inventoryId = item.inventoryId;
        if (!inventoryId) {
            throw new Error('Each item requires an inventoryId');
        }
        const inventory = await tx
            .select()
            .from(db_1.inventories)
            .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventoryId))
            .get();
        if (!inventory) {
            throw new Error(`Inventory stock not found for inventoryId=${inventoryId}`);
        }
        if ((inventory.unitsInStock ?? 0) < qty) {
            throw new Error(`Insufficient stock for inventoryId=${inventoryId}`);
        }
        const updatedUnitsInStock = (inventory.unitsInStock ?? 0) - qty;
        await tx
            .update(db_1.inventories)
            .set({ unitsInStock: updatedUnitsInStock })
            .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
            .run();
        const taxAmountValue = (0, number_util_1.toPositiveNumber)(item.taxAmount, 0);
        let sgst = 0, cgst = 0, igst = 0;
        if (isInterState) {
            igst = taxAmountValue;
        }
        else {
            sgst = taxAmountValue / 2;
            cgst = taxAmountValue / 2;
        }
        await tx
            .insert(db_1.salesInvoiceItems)
            .values({
            salesInvoiceId,
            inventoryId,
            qty: (0, number_util_1.toNumber)(qty),
            unitPrice: (0, number_util_1.toNumber)(unitPrice),
            discountType: item.discountType,
            discountPct: (0, number_util_1.toNumber)(item.discountPct),
            discountAmount: (0, number_util_1.toNumber)(item.discountAmount),
            taxPct: (0, number_util_1.toNumber)(item.taxPct),
            sgstAmount: (0, number_util_1.toNumber)(sgst),
            cgstAmount: (0, number_util_1.toNumber)(cgst),
            igstAmount: (0, number_util_1.toNumber)(igst),
        })
            .run();
        totalQty += qty;
        subtotal += (qty * unitPrice);
        totalTax += taxAmountValue;
        totalDiscount += (0, number_util_1.toPositiveNumber)(item.discountAmount, 0);
    }
    return {
        totalQty,
        subtotal,
        totalTax,
        totalDiscount,
        netAmount: subtotal - totalDiscount + totalTax,
    };
};
exports.salesInvoicesRouter.get('/', async (req, res) => {
    try {
        const { limit, offset, pageNum } = (0, list_query_util_1.parsePagination)({
            limit: req.query.limit,
            offset: req.query.offset,
            page: req.query.page,
            pageNum: req.query.pageNum,
        });
        const filters = [];
        if (req.query.invoiceNumber) {
            filters.push((0, drizzle_orm_1.like)(db_1.salesInvoices.invoiceNumber, `%${req.query.invoiceNumber}%`));
        }
        if (req.query.invoiceDate) {
            filters.push((0, drizzle_orm_1.eq)(db_1.salesInvoices.invoiceDate, req.query.invoiceDate));
        }
        if (req.query.customerId) {
            const customerId = Number(req.query.customerId);
            if (!Number.isNaN(customerId)) {
                filters.push((0, drizzle_orm_1.eq)(db_1.salesInvoices.customerId, customerId));
            }
        }
        if (req.query.type) {
            filters.push((0, drizzle_orm_1.eq)(db_1.salesInvoices.type, req.query.type));
        }
        if (req.query.minAmount) {
            const minAmount = Number(req.query.minAmount);
            if (!Number.isNaN(minAmount)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.salesInvoices.netAmount} AS REAL) >= ${minAmount}`);
            }
        }
        if (req.query.maxAmount) {
            const maxAmount = Number(req.query.maxAmount);
            if (!Number.isNaN(maxAmount)) {
                filters.push((0, drizzle_orm_1.sql) `CAST(${db_1.salesInvoices.netAmount} AS REAL) <= ${maxAmount}`);
            }
        }
        const sortableFields = ['id', 'invoiceNumber', 'invoiceDate', 'totalQty', 'netAmount', 'type', 'customerName'];
        const isSortableField = (value) => sortableFields.includes(value);
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                if (field === 'customerName') {
                    orderBy.push(dir((0, drizzle_orm_1.sql) `${db_1.customers.name} COLLATE NOCASE`));
                }
                else {
                    const column = db_1.salesInvoices[field];
                    if (column) {
                        orderBy.push(dir(column));
                    }
                }
            }
        }
        if (orderBy.length === 0) {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.salesInvoices.id));
        }
        const baseQuery = db_1.db
            .select({
            id: db_1.salesInvoices.id,
            invoiceNumber: db_1.salesInvoices.invoiceNumber,
            invoiceDate: db_1.salesInvoices.invoiceDate,
            type: db_1.salesInvoices.type,
            customerId: db_1.salesInvoices.customerId,
            customerName: db_1.customers.name,
            totalQty: db_1.salesInvoices.totalQty,
            roundOff: db_1.salesInvoices.roundOff,
            netAmount: db_1.salesInvoices.netAmount,
            irn: db_1.salesInvoices.irn,
            isTaxInclusive: db_1.salesInvoices.isTaxInclusive
        })
            .from(db_1.salesInvoices)
            .leftJoin(db_1.customers, (0, drizzle_orm_1.eq)(db_1.customers.id, db_1.salesInvoices.customerId));
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const query = whereCondition ? baseQuery.where(whereCondition) : baseQuery;
        const totalResult = await db_1.db.select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` }).from(db_1.salesInvoices);
        const filteredCount = whereCondition
            ? (await db_1.db
                .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
                .from(db_1.salesInvoices)
                .where(whereCondition))[0].count
            : totalResult[0].count;
        const data = await query
            .orderBy(...orderBy)
            .limit(limit)
            .offset(offset)
            .all();
        logger_service_1.LogService.info('Fetched sales invoices list', { count: data.length, total: filteredCount });
        res.json({
            data,
            pagination: (0, list_query_util_1.toPagination)(limit, offset, filteredCount, pageNum),
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch sales invoices', error);
        res.status(500).json({ error: 'Failed to fetch sales invoices' });
    }
});
exports.salesInvoicesRouter.get('/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid sales invoice ID' });
        }
        const invoice = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        if (!invoice) {
            logger_service_1.LogService.warn('Sales invoice not found', { salesInvoiceId: id });
            return res.status(404).json({ error: 'Sales invoice not found' });
        }
        logger_service_1.LogService.info('Fetched sales invoice details', { salesInvoiceId: id, invoiceNumber: invoice.invoiceNumber });
        const items = await db_1.db
            .select({
            id: db_1.salesInvoiceItems.id,
            salesInvoiceId: db_1.salesInvoiceItems.salesInvoiceId,
            inventoryId: db_1.salesInvoiceItems.inventoryId,
            qty: db_1.salesInvoiceItems.qty,
            unitPrice: db_1.salesInvoiceItems.unitPrice,
            discountType: db_1.salesInvoiceItems.discountType,
            discountPct: db_1.salesInvoiceItems.discountPct,
            discountAmount: db_1.salesInvoiceItems.discountAmount,
            taxPct: db_1.salesInvoiceItems.taxPct,
            taxAmount: db_1.salesInvoiceItems.taxAmount,
            sgstAmount: db_1.salesInvoiceItems.sgstAmount,
            cgstAmount: db_1.salesInvoiceItems.cgstAmount,
            igstAmount: db_1.salesInvoiceItems.igstAmount,
            lineTotal: db_1.salesInvoiceItems.lineTotal,
            productId: db_1.inventories.productId,
            productCode: db_1.products.code,
            productName: db_1.products.name,
            unitsInStock: db_1.inventories.unitsInStock,
            gtn: db_1.inventories.gtn,
        })
            .from(db_1.salesInvoiceItems)
            .innerJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.inventories.id, db_1.salesInvoiceItems.inventoryId))
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id))
            .all();
        const customer = await db_1.db.select().from(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, invoice.customerId)).get();
        return res.json({ ...invoice, customerName: customer?.name, items });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch sales invoice', error, { salesInvoiceId: req.params.id });
        return res.status(500).json({ error: 'Failed to fetch sales invoice' });
    }
});
exports.salesInvoicesRouter.post('/', async (req, res) => {
    try {
        const body = req.body;
        const items = body.items ?? [];
        if (items.length === 0) {
            return res.status(400).json({ error: 'At least one item is required' });
        }
        if (!body.customerId) {
            return res.status(400).json({ error: 'Customer is required for a sales invoice' });
        }
        const created = await db_1.db.transaction(async (tx) => {
            const invoiceNumber = body.invoiceNumber || (await serial_number_service_1.serialNumberService.generateInvoiceNumber(body.type === 'estimate' ? 'salesEstimate' : 'salesInvoice', tx));
            const insertedInvoice = await tx
                .insert(db_1.salesInvoices)
                .values({
                invoiceNumber,
                invoiceDate: (0, date_util_1.normalizeDate)(body.invoiceDate),
                type: body.type || 'invoice',
                customerId: body.customerId,
                refNumber: body.refNumber,
                refDate: body.refDate ? (0, date_util_1.normalizeDate)(body.refDate) : null,
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? 0,
                subtotal: (0, number_util_1.toNumber)(body.subtotal) ?? 0,
                discountType: body.discountType,
                discountPct: (0, number_util_1.toNumber)(body.discountPct),
                discountAmount: (0, number_util_1.toNumber)(body.discountAmount),
                totalTaxAmount: (0, number_util_1.toNumber)(body.totalTaxAmount),
                roundOff: (0, number_util_1.toNumber)(body.roundOff) ?? 0,
                isTaxInclusive: body.isTaxInclusive,
            })
                .returning()
                .get();
            const totals = await processInvoiceItems(tx, insertedInvoice.id, items);
            // Overwrite with computed values if requested
            await tx
                .update(db_1.salesInvoices)
                .set({
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? (0, number_util_1.toNumber)(totals.totalQty),
                subtotal: (0, number_util_1.toNumber)(body.subtotal) ?? (0, number_util_1.toNumber)(totals.subtotal),
                discountAmount: (0, number_util_1.toNumber)(body.discountAmount) ?? (0, number_util_1.toNumber)(totals.totalDiscount),
            })
                .where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, insertedInvoice.id))
                .run();
            return tx.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, insertedInvoice.id)).get();
        });
        if (!created) {
            throw new Error('Failed to retrieve created sales invoice');
        }
        const itemsWithDetails = await db_1.db
            .select()
            .from(db_1.salesInvoiceItems)
            .where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, created.id))
            .all();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_SALES_INVOICE',
            entity: 'SALES_INVOICE',
            entityId: created.id,
            newValue: { ...created, items: itemsWithDetails },
        });
        logger_service_1.LogService.info('Sales invoice created successfully', { salesInvoiceId: created.id, invoiceNumber: created.invoiceNumber });
        return res.status(201).json(created);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to create sales invoice', error, { body: req.body });
        return res.status(400).json({ error: error.message || 'Failed to create sales invoice' });
    }
});
exports.salesInvoicesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid sales invoice ID' });
        }
        const body = req.body;
        const items = body.items ?? [];
        if (items.length === 0) {
            return res.status(400).json({ error: 'At least one item is required' });
        }
        const oldInvoice = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        const oldItems = await db_1.db.select().from(db_1.salesInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id)).all();
        const updated = await db_1.db.transaction(async (tx) => {
            const existing = await tx.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
            if (!existing) {
                throw new Error('Sales invoice not found');
            }
            const existingItems = await tx
                .select()
                .from(db_1.salesInvoiceItems)
                .where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id))
                .all();
            if (existingItems.length > 0) {
                // Find corresponding inventory to refund the stock to. 
                for (const item of existingItems) {
                    const inventory = await tx
                        .select()
                        .from(db_1.inventories)
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, item.inventoryId))
                        .get();
                    if (inventory) {
                        const qtyToReturn = Number(item.qty ?? 0);
                        const restoredStock = (inventory.unitsInStock ?? 0) + qtyToReturn;
                        await tx
                            .update(db_1.inventories)
                            .set({ unitsInStock: restoredStock })
                            .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
                            .run();
                    }
                }
                await tx.delete(db_1.salesInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id)).run();
            }
            const totals = await processInvoiceItems(tx, id, items);
            await tx
                .update(db_1.salesInvoices)
                .set({
                invoiceNumber: body.invoiceNumber ?? existing.invoiceNumber,
                invoiceDate: body.invoiceDate ?? existing.invoiceDate,
                type: body.type ?? existing.type,
                customerId: body.customerId ?? existing.customerId,
                refNumber: body.refNumber ?? existing.refNumber,
                refDate: body.refDate ? (0, date_util_1.normalizeDate)(body.refDate) : existing.refDate,
                totalQty: (0, number_util_1.toNumber)(body.totalQty) ?? (0, number_util_1.toNumber)(totals.totalQty),
                subtotal: (0, number_util_1.toNumber)(body.subtotal) ?? (0, number_util_1.toNumber)(totals.subtotal),
                discountType: body.discountType ?? existing.discountType,
                discountPct: (0, number_util_1.toNumber)(body.discountPct) ?? existing.discountPct,
                discountAmount: (0, number_util_1.toNumber)(body.discountAmount) ?? (0, number_util_1.toNumber)(totals.totalDiscount),
                totalTaxAmount: (0, number_util_1.toNumber)(body.totalTaxAmount) ?? existing.totalTaxAmount,
                roundOff: (0, number_util_1.toNumber)(body.roundOff) ?? existing.roundOff,
                isTaxInclusive: body.isTaxInclusive !== undefined ? body.isTaxInclusive : existing.isTaxInclusive,
            })
                .where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id))
                .run();
            return tx.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        });
        if (!updated) {
            throw new Error('Failed to retrieve updated sales invoice');
        }
        const itemsWithDetails = await db_1.db
            .select()
            .from(db_1.salesInvoiceItems)
            .where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, updated.id))
            .all();
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_SALES_INVOICE',
            entity: 'SALES_INVOICE',
            entityId: id,
            oldValue: { ...oldInvoice, items: oldItems },
            newValue: { ...updated, items: itemsWithDetails },
        });
        logger_service_1.LogService.info('Sales invoice updated successfully', { salesInvoiceId: id, invoiceNumber: updated.invoiceNumber });
        return res.json(updated);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to update sales invoice', error, { salesInvoiceId: id });
        return res.status(400).json({ error: error.message || 'Failed to update sales invoice' });
    }
});
exports.salesInvoicesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid sales invoice ID' });
        }
        const oldInvoice = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        if (!oldInvoice) {
            logger_service_1.LogService.warn('Sales invoice not found for deletion', { salesInvoiceId: id });
            return res.status(404).json({ error: 'Sales invoice not found' });
        }
        const oldItems = await db_1.db.select().from(db_1.salesInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id)).all();
        await db_1.db.transaction(async (tx) => {
            // Refund the inventory
            if (oldItems.length > 0) {
                for (const item of oldItems) {
                    const inventory = await tx
                        .select()
                        .from(db_1.inventories)
                        .where((0, drizzle_orm_1.eq)(db_1.inventories.id, item.inventoryId))
                        .get();
                    if (inventory) {
                        const qtyToReturn = Number(item.qty ?? 0);
                        const restoredStock = (inventory.unitsInStock ?? 0) + qtyToReturn;
                        await tx
                            .update(db_1.inventories)
                            .set({ unitsInStock: restoredStock })
                            .where((0, drizzle_orm_1.eq)(db_1.inventories.id, inventory.id))
                            .run();
                    }
                }
            }
            await tx.delete(db_1.salesInvoiceItems).where((0, drizzle_orm_1.eq)(db_1.salesInvoiceItems.salesInvoiceId, id)).run();
            await tx.delete(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).run();
        });
        await (0, audit_service_1.auditLog)({
            action: 'DELETE_SALES_INVOICE',
            entity: 'SALES_INVOICE',
            entityId: id,
            oldValue: { ...oldInvoice, items: oldItems },
        });
        logger_service_1.LogService.info('Sales invoice deleted successfully', { salesInvoiceId: id, invoiceNumber: oldInvoice.invoiceNumber });
        return res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete sales invoice', error, { salesInvoiceId: id });
        return res.status(404).json({ error: error.message || 'Failed to delete sales invoice' });
    }
});
const crypto_1 = __importDefault(require("crypto"));
exports.salesInvoicesRouter.post('/:id/generate-irn', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid sales invoice ID' });
        }
        const existing = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        if (!existing) {
            return res.status(404).json({ error: 'Sales invoice not found' });
        }
        // According to Indian Gov E-Invoicing Rules, an invoice cannot generate multiple IRNs.
        if (existing.irn) {
            return res.status(400).json({ error: 'Invoice already possesses an IRN.' });
        }
        // Mock IRN generation (normally involves calling NIC IRP portal with a JSON payload)
        // Here we generate a realistic-looking 64-char hex hash
        const inputString = existing.customerId + '-' + existing.invoiceNumber + '-' + existing.invoiceDate + '-' + Date.now();
        const irn = crypto_1.default.createHash('sha256').update(inputString).digest('hex');
        // Mock 15 digit Ack No
        const ackNo = Math.floor(100000000000000 + Math.random() * 900000000000000).toString();
        const ackDate = new Date().toISOString();
        // Fetch seller GSTIN from settings
        const settingRows = await db_1.db.select().from(db_1.settings).all();
        const s = Object.fromEntries(settingRows.map(r => [r.key, r.value]));
        // Mock Signed QR payload (usually a signed JWT-like string)
        const qrPayload = JSON.stringify({
            SellerGstin: s['company_gstin'] || '07AAGFF2194N1Z1',
            BuyerGstin: '27AADCB2230M1Z2',
            DocNo: existing.invoiceNumber,
            DocTyp: 'INV',
            DocDt: existing.invoiceDate,
            TotInvVal: existing.netAmount,
            ItemCnt: existing.totalQty,
            MainHsnCode: '8517',
            Irn: irn
        });
        // Base64 encode it for the QR code payload
        const signedQrCode = Buffer.from(qrPayload).toString('base64');
        await db_1.db
            .update(db_1.salesInvoices)
            .set({
            irn,
            ackNo,
            ackDate,
            signedQrCode
        })
            .where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id))
            .run();
        const updated = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
        logger_service_1.LogService.info('Generated IRN for sales invoice', { salesInvoiceId: id, irn, invoiceNumber: existing.invoiceNumber });
        return res.json(updated);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to generate IRN', error, { salesInvoiceId: id });
        return res.status(500).json({ error: 'Failed to generate IRN' });
    }
});
// PDF Generation Route 
exports.salesInvoicesRouter.get('/:id/pdf', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    try {
        if (Number.isNaN(id)) {
            return res.status(400).json({ error: 'Invalid sales invoice ID' });
        }
        await (0, sales_invoice_report_1.renderSalesInvoice)(id, db_1.db, res);
        logger_service_1.LogService.info('Generated sales invoice PDF', { salesInvoiceId: id });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to generate sales invoice PDF', error, { salesInvoiceId: id });
        res.status(500).json({ error: 'Failed to generate PDF' });
    }
});

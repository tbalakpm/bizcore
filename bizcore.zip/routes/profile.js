"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.profileRouter = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const password_util_1 = require("../utils/password.util");
const audit_service_1 = require("../core/logger/audit.service");
exports.profileRouter = express_1.default.Router();
const userProfileSelect = {
    id: db_1.users.id,
    username: db_1.users.username,
    firstName: db_1.users.firstName,
    lastName: db_1.users.lastName,
    role: db_1.users.role,
    permissions: db_1.users.permissions,
    isActive: db_1.users.isActive,
    createdAt: db_1.users.createdAt,
    updatedAt: db_1.users.updatedAt,
};
exports.profileRouter.get('/', async (req, res) => {
    const userId = req.user?.id;
    if (!userId)
        return res.status(401).json({ error: 'Unauthorized' });
    const user = await db_1.db
        .select(userProfileSelect)
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .get();
    if (!user)
        return res.status(404).json({ error: 'User not found' });
    res.json(user);
});
exports.profileRouter.put('/', async (req, res) => {
    const userId = req.user?.id;
    if (!userId)
        return res.status(401).json({ error: 'Unauthorized' });
    const { firstName, lastName } = req.body;
    const oldUser = await db_1.db
        .select(userProfileSelect)
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .get();
    await db_1.db
        .update(db_1.users)
        .set({ firstName, lastName })
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .run();
    const updatedUser = await db_1.db
        .select(userProfileSelect)
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .get();
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_PROFILE',
        entity: 'USER',
        entityId: userId,
        oldValue: oldUser,
        newValue: updatedUser,
    });
    res.json(updatedUser);
});
exports.profileRouter.post('/change-password', async (req, res) => {
    const userId = req.user?.id;
    if (!userId)
        return res.status(401).json({ error: 'Unauthorized' });
    const { currentPassword, newPassword } = req.body;
    const user = await db_1.db
        .select({ passwordHash: db_1.users.passwordHash })
        .from(db_1.users)
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .get();
    if (!user)
        return res.status(404).json({ error: 'User not found' });
    const valid = await bcryptjs_1.default.compare(currentPassword, user.passwordHash);
    if (!valid)
        return res.status(400).json({ error: 'Current password incorrect' });
    if (!(0, password_util_1.isStrongPassword)(newPassword)) {
        return res.status(400).json({ error: 'New password is too weak' });
    }
    const passwordHash = await bcryptjs_1.default.hash(newPassword, 10);
    await db_1.db
        .update(db_1.users)
        .set({ passwordHash, mustChangePassword: false })
        .where((0, drizzle_orm_1.eq)(db_1.users.id, userId))
        .run();
    await (0, audit_service_1.auditLog)({
        action: 'CHANGE_PASSWORD',
        entity: 'USER',
        entityId: userId,
    });
    res.json({ message: 'Password changed successfully' });
});

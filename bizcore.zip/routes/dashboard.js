"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
exports.dashboardRouter = express_1.default.Router();
exports.dashboardRouter.get('/summary', async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today.toISOString().split('T')[0];
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay());
        const weekStr = startOfWeek.toISOString().split('T')[0];
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthStr = startOfMonth.toISOString().split('T')[0];
        const startOfYear = new Date(today.getFullYear(), 0, 1);
        const yearStr = startOfYear.toISOString().split('T')[0];
        // 1. Masters Summary
        const [customersCount] = await db_1.db
            .select({
            total: (0, drizzle_orm_1.sql) `cast(count(*) as integer)`,
            active: (0, drizzle_orm_1.sql) `cast(sum(case when ${db_1.customers.isActive} = 1 then 1 else 0 end) as integer)`,
        })
            .from(db_1.customers);
        const [suppliersCount] = await db_1.db
            .select({
            total: (0, drizzle_orm_1.sql) `cast(count(*) as integer)`,
            active: (0, drizzle_orm_1.sql) `cast(sum(case when ${db_1.suppliers.isActive} = 1 then 1 else 0 end) as integer)`,
        })
            .from(db_1.suppliers);
        const [productsCount] = await db_1.db
            .select({
            total: (0, drizzle_orm_1.sql) `cast(count(*) as integer)`,
            active: (0, drizzle_orm_1.sql) `cast(sum(case when ${db_1.products.isActive} = 1 then 1 else 0 end) as integer)`,
        })
            .from(db_1.products);
        // 2. Sales Summary
        const salesSummaryQuery = await db_1.db
            .select({
            period: (0, drizzle_orm_1.sql) `
          case 
            when ${db_1.salesInvoices.invoiceDate} >= ${todayStr} then 'today'
            when ${db_1.salesInvoices.invoiceDate} >= ${weekStr} then 'week'
            when ${db_1.salesInvoices.invoiceDate} >= ${monthStr} then 'month'
            when ${db_1.salesInvoices.invoiceDate} >= ${yearStr} then 'year'
          end
        `,
            count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)`,
            total: (0, drizzle_orm_1.sql) `cast(sum(${db_1.salesInvoices.netAmount}) as real)`,
            profit: (0, drizzle_orm_1.sql) `cast(sum(${db_1.salesInvoices.netAmount} - ${db_1.salesInvoices.subtotal}) as real)`,
        })
            .from(db_1.salesInvoices)
            .where((0, drizzle_orm_1.gte)(db_1.salesInvoices.invoiceDate, yearStr))
            .groupBy((0, drizzle_orm_1.sql) `
        case 
          when ${db_1.salesInvoices.invoiceDate} >= ${todayStr} then 'today'
          when ${db_1.salesInvoices.invoiceDate} >= ${weekStr} then 'week'
          when ${db_1.salesInvoices.invoiceDate} >= ${monthStr} then 'month'
          when ${db_1.salesInvoices.invoiceDate} >= ${yearStr} then 'year'
        end
      `);
        // 3. Purchases Summary
        const purchaseSummaryQuery = await db_1.db
            .select({
            period: (0, drizzle_orm_1.sql) `
          case 
            when ${db_1.purchaseInvoices.invoiceDate} >= ${todayStr} then 'today'
            when ${db_1.purchaseInvoices.invoiceDate} >= ${weekStr} then 'week'
            when ${db_1.purchaseInvoices.invoiceDate} >= ${monthStr} then 'month'
            when ${db_1.purchaseInvoices.invoiceDate} >= ${yearStr} then 'year'
          end
        `,
            count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)`,
            total: (0, drizzle_orm_1.sql) `cast(sum(${db_1.purchaseInvoices.netAmount}) as real)`,
            tax: (0, drizzle_orm_1.sql) `cast(sum(${db_1.purchaseInvoices.totalTaxAmount}) as real)`,
        })
            .from(db_1.purchaseInvoices)
            .where((0, drizzle_orm_1.gte)(db_1.purchaseInvoices.invoiceDate, yearStr))
            .groupBy((0, drizzle_orm_1.sql) `
        case 
          when ${db_1.purchaseInvoices.invoiceDate} >= ${todayStr} then 'today'
          when ${db_1.purchaseInvoices.invoiceDate} >= ${weekStr} then 'week'
          when ${db_1.purchaseInvoices.invoiceDate} >= ${monthStr} then 'month'
          when ${db_1.purchaseInvoices.invoiceDate} >= ${yearStr} then 'year'
        end
      `);
        // 4. Stock Summary
        const [stockSummary] = await db_1.db
            .select({
            qty: (0, drizzle_orm_1.sql) `cast(sum(${db_1.inventories.unitsInStock}) as real)`,
            cost: (0, drizzle_orm_1.sql) `cast(sum(${db_1.inventories.unitsInStock} * ${db_1.inventories.buyingPrice}) as real)`,
        })
            .from(db_1.inventories);
        // 5. Top 10 Lists
        const topProductsAmount = (0, drizzle_orm_1.sql) `cast(sum(${db_1.salesInvoiceItems.lineTotal}) as real)`;
        const topProducts = await db_1.db
            .select({
            name: db_1.products.name,
            amount: topProductsAmount,
        })
            .from(db_1.salesInvoiceItems)
            .innerJoin(db_1.inventories, (0, drizzle_orm_1.eq)(db_1.inventories.id, db_1.salesInvoiceItems.inventoryId))
            .innerJoin(db_1.products, (0, drizzle_orm_1.eq)(db_1.products.id, db_1.inventories.productId))
            .groupBy(db_1.products.id)
            .orderBy((0, drizzle_orm_1.desc)(topProductsAmount))
            .limit(10);
        const topCustomersAmount = (0, drizzle_orm_1.sql) `cast(sum(${db_1.salesInvoices.netAmount}) as real)`;
        const topCustomers = await db_1.db
            .select({
            name: db_1.customers.name,
            amount: topCustomersAmount,
        })
            .from(db_1.salesInvoices)
            .innerJoin(db_1.customers, (0, drizzle_orm_1.eq)(db_1.customers.id, db_1.salesInvoices.customerId))
            .groupBy(db_1.customers.id)
            .orderBy((0, drizzle_orm_1.desc)(topCustomersAmount))
            .limit(10);
        const topSuppliersAmount = (0, drizzle_orm_1.sql) `cast(sum(${db_1.purchaseInvoices.netAmount}) as real)`;
        const topSuppliers = await db_1.db
            .select({
            name: db_1.suppliers.name,
            amount: topSuppliersAmount,
        })
            .from(db_1.purchaseInvoices)
            .innerJoin(db_1.suppliers, (0, drizzle_orm_1.eq)(db_1.suppliers.id, db_1.purchaseInvoices.supplierId))
            .groupBy(db_1.suppliers.id)
            .orderBy((0, drizzle_orm_1.desc)(topSuppliersAmount))
            .limit(10);
        // 6. Daily Trends (This Month)
        const dailyTrendsQuery = await db_1.db
            .select({
            date: db_1.salesInvoices.invoiceDate,
            income: (0, drizzle_orm_1.sql) `cast(sum(case when ${db_1.salesInvoices.netAmount} > 0 then ${db_1.salesInvoices.netAmount} else 0 end) as real)`,
            expenses: (0, drizzle_orm_1.sql) `cast(0 as real)`,
        })
            .from(db_1.salesInvoices)
            .where((0, drizzle_orm_1.gte)(db_1.salesInvoices.invoiceDate, monthStr))
            .groupBy(db_1.salesInvoices.invoiceDate);
        const purchaseTrendsQuery = await db_1.db
            .select({
            date: db_1.purchaseInvoices.invoiceDate,
            income: (0, drizzle_orm_1.sql) `cast(0 as real)`,
            expenses: (0, drizzle_orm_1.sql) `cast(sum(${db_1.purchaseInvoices.netAmount}) as real)`,
        })
            .from(db_1.purchaseInvoices)
            .where((0, drizzle_orm_1.gte)(db_1.purchaseInvoices.invoiceDate, monthStr))
            .groupBy(db_1.purchaseInvoices.invoiceDate);
        // Merge trends
        const trendsMap = new Map();
        for (const d of dailyTrendsQuery) {
            trendsMap.set(d.date, { income: d.income, expenses: 0 });
        }
        for (const p of purchaseTrendsQuery) {
            const existing = trendsMap.get(p.date) || { income: 0, expenses: 0 };
            trendsMap.set(p.date, { income: existing.income, expenses: p.expenses });
        }
        const dailyTrends = Array.from(trendsMap.entries())
            .map(([date, values]) => ({ date, ...values }))
            .sort((a, b) => a.date.localeCompare(b.date));
        // 7. Recent Activities
        const recentSales = await db_1.db
            .select({
            id: db_1.salesInvoices.id,
            date: db_1.salesInvoices.invoiceDate,
            description: (0, drizzle_orm_1.sql) `'Sale to ' || ${db_1.customers.name}`,
            amount: db_1.salesInvoices.netAmount,
            type: (0, drizzle_orm_1.sql) `'I'`,
        })
            .from(db_1.salesInvoices)
            .innerJoin(db_1.customers, (0, drizzle_orm_1.eq)(db_1.customers.id, db_1.salesInvoices.customerId))
            .orderBy((0, drizzle_orm_1.desc)(db_1.salesInvoices.id))
            .limit(5);
        const recentPurchases = await db_1.db
            .select({
            id: db_1.purchaseInvoices.id,
            date: db_1.purchaseInvoices.invoiceDate,
            description: (0, drizzle_orm_1.sql) `'Purchase from ' || ${db_1.suppliers.name}`,
            amount: db_1.purchaseInvoices.netAmount,
            type: (0, drizzle_orm_1.sql) `'E'`,
        })
            .from(db_1.purchaseInvoices)
            .innerJoin(db_1.suppliers, (0, drizzle_orm_1.eq)(db_1.suppliers.id, db_1.purchaseInvoices.supplierId))
            .orderBy((0, drizzle_orm_1.desc)(db_1.purchaseInvoices.id))
            .limit(5);
        const recentActivities = [...recentSales, ...recentPurchases].sort((a, b) => b.date.localeCompare(a.date));
        // Format results
        const sales = {
            today: salesSummaryQuery.find((s) => s.period === 'today') || { count: 0, total: 0, profit: 0 },
            week: salesSummaryQuery.find((s) => s.period === 'week') || { count: 0, total: 0, profit: 0 },
            month: salesSummaryQuery.find((s) => s.period === 'month') || { count: 0, total: 0, profit: 0 },
            year: salesSummaryQuery.find((s) => s.period === 'year') || { count: 0, total: 0, profit: 0 },
        };
        const purchases = {
            today: purchaseSummaryQuery.find((p) => p.period === 'today') || { count: 0, total: 0, tax: 0 },
            week: purchaseSummaryQuery.find((p) => p.period === 'week') || { count: 0, total: 0, tax: 0 },
            month: purchaseSummaryQuery.find((p) => p.period === 'month') || { count: 0, total: 0, tax: 0 },
            year: purchaseSummaryQuery.find((p) => p.period === 'year') || { count: 0, total: 0, tax: 0 },
        };
        res.json({
            masters: {
                customers: customersCount,
                suppliers: suppliersCount,
                products: productsCount,
            },
            sales,
            purchases,
            stock: {
                total: stockSummary || { qty: 0, cost: 0 },
                reorderLevel: 0,
                outOfStock: 0,
            },
            topProducts,
            topCustomers,
            topSuppliers,
            aging: {
                stock: [],
                receivables: [],
                payables: [],
            },
            finance: {
                income: {
                    today: sales.today.total,
                    week: sales.week.total,
                    month: sales.month.total,
                    year: sales.year.total,
                },
                expenses: {
                    today: purchases.today.total,
                    week: purchases.week.total,
                    month: purchases.month.total,
                    year: purchases.year.total,
                },
                profit: {
                    today: sales.today.total - purchases.today.total,
                    week: sales.week.total - purchases.week.total,
                    month: sales.month.total - purchases.month.total,
                    year: sales.year.total - purchases.year.total,
                },
            },
            dailyTrends,
            recentActivities,
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch dashboard summary', error);
        res.status(500).json({ error: 'Failed to fetch dashboard summary' });
    }
});

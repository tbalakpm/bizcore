"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.customersRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.customersRouter = express_1.default.Router();
const billingAddress = (0, sqlite_core_1.alias)(db_1.addresses, 'billing_address');
const shippingAddress = (0, sqlite_core_1.alias)(db_1.addresses, 'shipping_address');
exports.customersRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['code', 'name', 'type', 'notes', 'gstin'];
        const sortableFields = ['id', ...filterableFields, 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.customers[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Filter by active status
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.customers.isActive, isActive));
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.customers[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.customers.id));
        }
        // Build the query with joins
        const baseQuery = db_1.db
            .select({
            ...(0, drizzle_orm_1.getTableColumns)(db_1.customers),
            billingAddress: billingAddress,
            shippingAddress: shippingAddress,
            pricingCategoryName: db_1.pricingCategories.name,
        })
            .from(db_1.customers)
            .leftJoin(billingAddress, (0, drizzle_orm_1.eq)(db_1.customers.billingAddressId, billingAddress.id))
            .leftJoin(shippingAddress, (0, drizzle_orm_1.eq)(db_1.customers.shippingAddressId, shippingAddress.id))
            .leftJoin(db_1.pricingCategories, (0, drizzle_orm_1.eq)(db_1.customers.pricingCategoryId, db_1.pricingCategories.id));
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCountResult = await db_1.db
            .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
            .from(db_1.customers)
            .where(whereCondition || (0, drizzle_orm_1.sql) `1=1`);
        const filteredCount = filteredCountResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched customers list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch customers', error);
        res.status(500).json({ error: 'Failed to fetch customers' });
    }
});
exports.customersRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid customer ID' });
    }
    const customer = await db_1.db
        .select({
        ...(0, drizzle_orm_1.getTableColumns)(db_1.customers),
        billingAddress: billingAddress,
        shippingAddress: shippingAddress,
        pricingCategoryName: db_1.pricingCategories.name,
    })
        .from(db_1.customers)
        .leftJoin(billingAddress, (0, drizzle_orm_1.eq)(db_1.customers.billingAddressId, billingAddress.id))
        .leftJoin(shippingAddress, (0, drizzle_orm_1.eq)(db_1.customers.shippingAddressId, shippingAddress.id))
        .leftJoin(db_1.pricingCategories, (0, drizzle_orm_1.eq)(db_1.customers.pricingCategoryId, db_1.pricingCategories.id))
        .where((0, drizzle_orm_1.eq)(db_1.customers.id, id))
        .get();
    if (!customer) {
        logger_service_1.LogService.warn('Customer not found', { customerId: id });
        return res.status(404).json({
            error: req.i18n?.t('customer.notFound') || 'Customer not found',
        });
    }
    logger_service_1.LogService.info('Fetched customer details', { customerId: id, customerName: customer.name });
    res.json(customer);
});
exports.customersRouter.post('/', async (req, res) => {
    const { code, name, type, notes, isActive, gstin, pricingCategoryId, billingAddress: bAddr, shippingAddress: sAddr } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    try {
        const result = await db_1.db.transaction(async (tx) => {
            let billingAddressId;
            let shippingAddressId;
            if (bAddr && Object.keys(bAddr).length > 0) {
                const addr = await tx.insert(db_1.addresses).values(bAddr).returning({ id: db_1.addresses.id }).get();
                billingAddressId = addr.id;
            }
            if (sAddr && Object.keys(sAddr).length > 0) {
                const addr = await tx.insert(db_1.addresses).values(sAddr).returning({ id: db_1.addresses.id }).get();
                shippingAddressId = addr.id;
            }
            return await tx
                .insert(db_1.customers)
                .values({
                code,
                name,
                type: type || 'retail',
                gstin,
                pricingCategoryId: pricingCategoryId ? Number(pricingCategoryId) : null,
                billingAddressId,
                shippingAddressId,
                notes,
                isActive: isActive !== false,
            })
                .returning()
                .get();
        });
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_CUSTOMER',
            entity: 'CUSTOMER',
            entityId: result.id,
            newValue: result,
        });
        logger_service_1.LogService.info('Customer created successfully', { customerId: result.id, customerName: result.name });
        res.status(201).json(result);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create customer', err, { code, name });
        res.status(400).json({
            error: req.i18n?.t('customer.exists') || 'Customer already exists or invalid data',
        });
    }
});
exports.customersRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const existingCustomer = await db_1.db.select().from(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, id)).get();
    if (!existingCustomer)
        return res.status(404).json({
            error: req.i18n?.t('customer.notFound') || 'Customer not found',
        });
    const { code, name, type, notes, isActive, gstin, pricingCategoryId, billingAddress: bAddr, shippingAddress: sAddr } = req.body;
    try {
        const updatedCustomer = await db_1.db.transaction(async (tx) => {
            let bAddrId = existingCustomer.billingAddressId;
            let sAddrId = existingCustomer.shippingAddressId;
            if (bAddr) {
                if (bAddrId) {
                    await tx.update(db_1.addresses).set(bAddr).where((0, drizzle_orm_1.eq)(db_1.addresses.id, bAddrId)).run();
                }
                else if (Object.keys(bAddr).length > 0) {
                    const addr = await tx.insert(db_1.addresses).values(bAddr).returning({ id: db_1.addresses.id }).get();
                    bAddrId = addr.id;
                }
            }
            if (sAddr) {
                if (sAddrId) {
                    await tx.update(db_1.addresses).set(sAddr).where((0, drizzle_orm_1.eq)(db_1.addresses.id, sAddrId)).run();
                }
                else if (Object.keys(sAddr).length > 0) {
                    const addr = await tx.insert(db_1.addresses).values(sAddr).returning({ id: db_1.addresses.id }).get();
                    sAddrId = addr.id;
                }
            }
            const newPricingCategoryId = pricingCategoryId !== undefined
                ? (pricingCategoryId ? Number(pricingCategoryId) : null)
                : existingCustomer.pricingCategoryId;
            await tx
                .update(db_1.customers)
                .set({
                code: code ?? existingCustomer.code,
                name: name ?? existingCustomer.name,
                type: type ?? existingCustomer.type,
                gstin: gstin ?? existingCustomer.gstin,
                pricingCategoryId: newPricingCategoryId,
                billingAddressId: bAddrId,
                shippingAddressId: sAddrId,
                notes: notes ?? existingCustomer.notes,
                isActive: typeof isActive === 'boolean' ? isActive : existingCustomer.isActive,
            })
                .where((0, drizzle_orm_1.eq)(db_1.customers.id, id))
                .run();
            const finalCustomer = await tx.select().from(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, id)).get();
            return finalCustomer;
        });
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_CUSTOMER',
            entity: 'CUSTOMER',
            entityId: id,
            oldValue: existingCustomer,
            newValue: updatedCustomer,
        });
        logger_service_1.LogService.info('Customer updated successfully', { customerId: id, customerName: updatedCustomer?.name });
        res.json(updatedCustomer);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to update customer', err, { customerId: id });
        res.status(400).json({ error: 'Failed to update customer' });
    }
});
exports.customersRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const customer = await db_1.db.select().from(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, id)).get();
    if (!customer) {
        logger_service_1.LogService.warn('Customer not found for deletion', { customerId: id });
        return res.status(404).json({
            error: req.i18n?.t('customer.notFound') || 'Customer not found',
        });
    }
    await db_1.db.delete(db_1.customers).where((0, drizzle_orm_1.eq)(db_1.customers.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_CUSTOMER',
        entity: 'CUSTOMER',
        entityId: id,
        oldValue: customer,
    });
    logger_service_1.LogService.info('Customer deleted successfully', { customerId: id, customerName: customer.name });
    res.status(204).send();
});

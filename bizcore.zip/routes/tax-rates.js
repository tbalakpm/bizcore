"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.taxRatesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
const number_util_1 = require("../utils/number.util");
exports.taxRatesRouter = express_1.default.Router();
exports.taxRatesRouter.get('/', async (req, res) => {
    try {
        const data = await db_1.db.select().from(db_1.taxRates).all();
        logger_service_1.LogService.info('Fetched tax rates list', { count: data.length });
        res.json({ data });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch tax rates', error);
        res.status(500).json({ error: 'Failed to fetch tax rates' });
    }
});
exports.taxRatesRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid tax rate ID' });
    }
    const taxRate = await db_1.db.select().from(db_1.taxRates).where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id)).get();
    if (!taxRate) {
        logger_service_1.LogService.warn('Tax rate not found', { taxRateId: id });
        return res.status(404).json({ error: 'Tax rate not found' });
    }
    res.json(taxRate);
});
exports.taxRatesRouter.post('/', async (req, res) => {
    const { rate, cgst_rate, sgst_rate, igst_rate, cess_rate, cess_amount, effective_from } = req.body;
    try {
        const inserted = await db_1.db
            .insert(db_1.taxRates)
            .values({
            rate: (0, number_util_1.toNumber)(rate),
            cgst_rate: (0, number_util_1.toNumber)(cgst_rate),
            sgst_rate: (0, number_util_1.toNumber)(sgst_rate),
            igst_rate: (0, number_util_1.toNumber)(igst_rate),
            cess_rate: (0, number_util_1.toNumber)(cess_rate),
            cess_amount: (0, number_util_1.toNumber)(cess_amount),
            effective_from: effective_from || new Date().toISOString().split('T')[0],
        })
            .returning()
            .get();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_TAX_RATE',
            entity: 'TAX_RATE',
            entityId: inserted.id,
            newValue: inserted,
        });
        logger_service_1.LogService.info('Tax rate created successfully', { taxRateId: inserted.id, rate: inserted.rate });
        res.status(201).json(inserted);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create tax rate', err);
        res.status(400).json({ error: 'Failed to create tax rate' });
    }
});
exports.taxRatesRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const oldTaxRate = await db_1.db.select().from(db_1.taxRates).where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id)).get();
    if (!oldTaxRate) {
        return res.status(404).json({ error: 'Tax rate not found' });
    }
    const { rate, cgst_rate, sgst_rate, igst_rate, cess_rate, cess_amount, effective_from } = req.body;
    const updateData = {};
    if (rate !== undefined)
        updateData.rate = (0, number_util_1.toNumber)(rate);
    if (cgst_rate !== undefined)
        updateData.cgst_rate = (0, number_util_1.toNumber)(cgst_rate);
    if (sgst_rate !== undefined)
        updateData.sgst_rate = (0, number_util_1.toNumber)(sgst_rate);
    if (igst_rate !== undefined)
        updateData.igst_rate = (0, number_util_1.toNumber)(igst_rate);
    if (cess_rate !== undefined)
        updateData.cess_rate = (0, number_util_1.toNumber)(cess_rate);
    if (cess_amount !== undefined)
        updateData.cess_amount = (0, number_util_1.toNumber)(cess_amount);
    if (effective_from !== undefined)
        updateData.effective_from = effective_from;
    await db_1.db
        .update(db_1.taxRates)
        .set(updateData)
        .where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id))
        .run();
    const updatedTaxRate = await db_1.db.select().from(db_1.taxRates).where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id)).get();
    await (0, audit_service_1.auditLog)({
        action: 'UPDATE_TAX_RATE',
        entity: 'TAX_RATE',
        entityId: id,
        oldValue: oldTaxRate,
        newValue: updatedTaxRate,
    });
    logger_service_1.LogService.info('Tax rate updated successfully', { taxRateId: id });
    res.json(updatedTaxRate);
});
exports.taxRatesRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const taxRate = await db_1.db.select().from(db_1.taxRates).where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id)).get();
    if (!taxRate) {
        return res.status(404).json({ error: 'Tax rate not found' });
    }
    await db_1.db.delete(db_1.taxRates).where((0, drizzle_orm_1.eq)(db_1.taxRates.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_TAX_RATE',
        entity: 'TAX_RATE',
        entityId: id,
        oldValue: taxRate,
    });
    logger_service_1.LogService.info('Tax rate deleted successfully', { taxRateId: id });
    res.status(204).send();
});

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gstRouter = void 0;
const express_1 = __importDefault(require("express"));
const gst_service_1 = require("../services/gst.service");
const logger_service_1 = require("../core/logger/logger.service");
exports.gstRouter = express_1.default.Router();
// Get a new captcha
exports.gstRouter.get('/captcha', async (req, res) => {
    try {
        const captcha = await gst_service_1.gstService.getCaptcha();
        res.json(captcha);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to get captcha', error);
        res.status(500).json({ error: error.message || 'Failed to get captcha' });
    }
});
// Fetch taxpayer details using GSTIN and solved captcha
exports.gstRouter.post('/details', async (req, res) => {
    const { gstin, captcha, sessionId } = req.body;
    if (!gstin || !captcha || !sessionId) {
        return res.status(400).json({ error: 'GSTIN, Captcha and Session ID are required' });
    }
    try {
        const details = await gst_service_1.gstService.fetchGstinDetails(gstin, captcha, sessionId);
        if (!details) {
            return res.status(404).json({ error: 'Taxpayer details not found' });
        }
        res.json(details);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch taxpayer details', error);
        res.status(400).json({ error: error.message || 'Failed to fetch taxpayer details' });
    }
});
// Keep the old GET for backward compatibility if needed, but mark as deprecated or mock-only
exports.gstRouter.get('/:gstin', async (req, res) => {
    res.status(400).json({ error: 'This endpoint is deprecated. Use POST /details with captcha instead.' });
});

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stateRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.stateRouter = express_1.default.Router();
// Get all states
exports.stateRouter.get('/', async (req, res) => {
    try {
        const data = await db_1.db.select().from(db_1.states).orderBy((0, drizzle_orm_1.asc)(db_1.states.stateName)).all();
        res.json({ data });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch states', error);
        res.status(500).json({ error: error.message });
    }
});
// Create state
exports.stateRouter.post('/', async (req, res) => {
    try {
        const body = req.body;
        const inserted = await db_1.db.insert(db_1.states)
            .values({
            stateName: body.stateName,
            stateCode: body.stateCode,
            stateShortCode: body.stateShortCode,
            countryCode: body.countryCode || 'IN',
            isUnionTerritory: !!body.isUnionTerritory,
            isActive: body.isActive !== undefined ? !!body.isActive : true,
        })
            .returning()
            .get();
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_STATE',
            entity: 'STATE',
            entityId: inserted.id,
            newValue: inserted,
        });
        logger_service_1.LogService.info('State created successfully', { stateId: inserted.id });
        res.status(201).json(inserted);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to create state', error);
        res.status(400).json({ error: error.message });
    }
});
// Update state
exports.stateRouter.put('/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const oldRecord = await db_1.db.select().from(db_1.states).where((0, drizzle_orm_1.eq)(db_1.states.id, id)).get();
        if (!oldRecord) {
            return res.status(404).json({ error: 'State not found' });
        }
        const body = req.body;
        await db_1.db.update(db_1.states)
            .set({
            stateName: body.stateName,
            stateCode: body.stateCode,
            stateShortCode: body.stateShortCode,
            countryCode: body.countryCode,
            isUnionTerritory: body.isUnionTerritory,
            isActive: body.isActive,
        })
            .where((0, drizzle_orm_1.eq)(db_1.states.id, id))
            .run();
        const updated = await db_1.db.select().from(db_1.states).where((0, drizzle_orm_1.eq)(db_1.states.id, id)).get();
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_STATE',
            entity: 'STATE',
            entityId: id,
            oldValue: oldRecord,
            newValue: updated,
        });
        logger_service_1.LogService.info('State updated successfully', { stateId: id });
        res.json(updated);
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to update state', error);
        res.status(400).json({ error: error.message });
    }
});
// Delete state
exports.stateRouter.delete('/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const record = await db_1.db.select().from(db_1.states).where((0, drizzle_orm_1.eq)(db_1.states.id, id)).get();
        if (!record) {
            return res.status(404).json({ error: 'State not found' });
        }
        await db_1.db.delete(db_1.states).where((0, drizzle_orm_1.eq)(db_1.states.id, id)).run();
        await (0, audit_service_1.auditLog)({
            action: 'DELETE_STATE',
            entity: 'STATE',
            entityId: id,
            oldValue: record,
        });
        logger_service_1.LogService.info('State deleted successfully', { stateId: id });
        res.status(204).send();
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to delete state', error);
        res.status(400).json({ error: error.message });
    }
});
exports.default = exports.stateRouter;

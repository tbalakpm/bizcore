"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.suppliersRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const sqlite_core_1 = require("drizzle-orm/sqlite-core");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const list_query_util_1 = require("../utils/list-query.util");
const logger_service_1 = require("../core/logger/logger.service");
const audit_service_1 = require("../core/logger/audit.service");
exports.suppliersRouter = express_1.default.Router();
const billingAddress = (0, sqlite_core_1.alias)(db_1.addresses, 'billing_address');
const shippingAddress = (0, sqlite_core_1.alias)(db_1.addresses, 'shipping_address');
exports.suppliersRouter.get('/', async (req, res) => {
    try {
        const hasPaginationQuery = req.query.limit !== undefined ||
            req.query.offset !== undefined ||
            req.query.page !== undefined ||
            req.query.pageNum !== undefined;
        const pagination = hasPaginationQuery
            ? (0, list_query_util_1.parsePagination)({
                limit: req.query.limit,
                offset: req.query.offset,
                page: req.query.page,
                pageNum: req.query.pageNum,
            })
            : undefined;
        // Build filters dynamically
        const filters = [];
        const filterableFields = ['code', 'name', 'notes', 'gstin'];
        const sortableFields = ['id', ...filterableFields, 'type', 'isActive', 'createdAt', 'updatedAt'];
        const isSortableField = (value) => sortableFields.includes(value);
        for (const field of filterableFields) {
            if (req.query[field]) {
                const column = db_1.suppliers[field];
                if (column) {
                    filters.push((0, drizzle_orm_1.like)(column, `%${req.query[field]}%`));
                }
            }
        }
        // Filter by type
        if (req.query.type) {
            filters.push((0, drizzle_orm_1.eq)(db_1.suppliers.type, req.query.type));
        }
        // Filter by active status
        if (req.query.isActive !== undefined) {
            const isActive = req.query.isActive === 'true';
            filters.push((0, drizzle_orm_1.eq)(db_1.suppliers.isActive, isActive));
        }
        // Build sort dynamically
        const orderBy = [];
        if (req.query.sort) {
            const sortParams = req.query.sort.split(',');
            for (const param of sortParams) {
                const [field, direction] = param.split(':');
                const dir = (0, list_query_util_1.resolveSortDirection)(direction);
                if (!field || !isSortableField(field)) {
                    continue;
                }
                const column = db_1.suppliers[field];
                if (column) {
                    orderBy.push(dir(column));
                }
            }
        }
        else {
            orderBy.push((0, list_query_util_1.resolveSortDirection)('desc')(db_1.suppliers.id));
        }
        // Build the query with joins
        const baseQuery = db_1.db
            .select({
            ...(0, drizzle_orm_1.getTableColumns)(db_1.suppliers),
            billingAddress: billingAddress,
            shippingAddress: shippingAddress,
        })
            .from(db_1.suppliers)
            .leftJoin(billingAddress, (0, drizzle_orm_1.eq)(db_1.suppliers.billingAddressId, billingAddress.id))
            .leftJoin(shippingAddress, (0, drizzle_orm_1.eq)(db_1.suppliers.shippingAddressId, shippingAddress.id));
        const query = filters.length > 0 ? baseQuery.where((0, drizzle_orm_1.and)(...filters)) : baseQuery;
        // Get total count
        const whereCondition = filters.length > 0 ? (0, drizzle_orm_1.and)(...filters) : undefined;
        const filteredCountResult = await db_1.db
            .select({ count: (0, drizzle_orm_1.sql) `cast(count(*) as integer)` })
            .from(db_1.suppliers)
            .where(whereCondition || (0, drizzle_orm_1.sql) `1=1`);
        const filteredCount = filteredCountResult[0].count;
        // Get paginated results
        const orderedQuery = query.orderBy(...orderBy);
        const result = pagination
            ? await orderedQuery.limit(pagination.limit).offset(pagination.offset).all()
            : await orderedQuery.all();
        logger_service_1.LogService.info('Fetched suppliers list', { count: result.length, total: filteredCount });
        res.json({
            data: result,
            pagination: pagination
                ? (0, list_query_util_1.toPagination)(pagination.limit, pagination.offset, filteredCount, pagination.pageNum)
                : {
                    limit: result.length,
                    offset: 0,
                    total: filteredCount,
                    page: 1,
                    totalPages: 1,
                },
        });
    }
    catch (error) {
        logger_service_1.LogService.error('Failed to fetch suppliers', error);
        res.status(500).json({ error: 'Failed to fetch suppliers' });
    }
});
exports.suppliersRouter.get('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid supplier ID' });
    }
    const supplier = await db_1.db
        .select({
        ...(0, drizzle_orm_1.getTableColumns)(db_1.suppliers),
        billingAddress: billingAddress,
        shippingAddress: shippingAddress,
    })
        .from(db_1.suppliers)
        .leftJoin(billingAddress, (0, drizzle_orm_1.eq)(db_1.suppliers.billingAddressId, billingAddress.id))
        .leftJoin(shippingAddress, (0, drizzle_orm_1.eq)(db_1.suppliers.shippingAddressId, shippingAddress.id))
        .where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id))
        .get();
    if (!supplier) {
        logger_service_1.LogService.warn('Supplier not found', { supplierId: id });
        return res.status(404).json({
            error: req.i18n?.t('supplier.notFound') || 'Supplier not found',
        });
    }
    logger_service_1.LogService.info('Fetched supplier details', { supplierId: id, supplierName: supplier.name });
    const bankAccounts = await db_1.db.select().from(db_1.supplierBanks).where((0, drizzle_orm_1.eq)(db_1.supplierBanks.supplierId, id)).all();
    res.json({ ...supplier, bankAccounts });
});
exports.suppliersRouter.post('/', async (req, res) => {
    const { code, name, type, notes, isActive, gstin, billingAddress: bAddr, shippingAddress: sAddr } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Name is required' });
    if (!code)
        return res.status(400).json({ error: 'Code is required' });
    try {
        const result = await db_1.db.transaction(async (tx) => {
            let billingAddressId;
            let shippingAddressId;
            if (bAddr && Object.keys(bAddr).length > 0) {
                const addr = await tx.insert(db_1.addresses).values(bAddr).returning({ id: db_1.addresses.id }).get();
                billingAddressId = addr.id;
            }
            if (sAddr && Object.keys(sAddr).length > 0) {
                const addr = await tx.insert(db_1.addresses).values(sAddr).returning({ id: db_1.addresses.id }).get();
                shippingAddressId = addr.id;
            }
            const supplier = await tx
                .insert(db_1.suppliers)
                .values({
                code,
                name,
                type,
                gstin,
                billingAddressId,
                shippingAddressId,
                notes,
                isActive: isActive !== false,
            })
                .returning()
                .get();
            const bankAccounts = req.body.bankAccounts;
            const createdBanks = [];
            if (Array.isArray(bankAccounts) && bankAccounts.length > 0) {
                for (const bank of bankAccounts) {
                    const b = await tx.insert(db_1.supplierBanks).values({
                        ...bank,
                        supplierId: supplier.id,
                    }).returning().get();
                    createdBanks.push(b);
                }
            }
            return { ...supplier, bankAccounts: createdBanks };
        });
        await (0, audit_service_1.auditLog)({
            action: 'CREATE_SUPPLIER',
            entity: 'SUPPLIER',
            entityId: result.id,
            newValue: result,
        });
        logger_service_1.LogService.info('Supplier created successfully', { supplierId: result.id, supplierName: result.name });
        res.status(201).json(result);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to create supplier', err, { code, name });
        res.status(400).json({
            error: req.i18n?.t('supplier.exists') || 'Supplier already exists or invalid data',
        });
    }
});
exports.suppliersRouter.put('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const existingSupplier = await db_1.db.select().from(db_1.suppliers).where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id)).get();
    if (!existingSupplier)
        return res.status(404).json({
            error: req.i18n?.t('supplier.notFound') || 'Supplier not found',
        });
    const { code, name, type, notes, isActive, gstin, billingAddress: bAddr, shippingAddress: sAddr } = req.body;
    try {
        const oldBanks = await db_1.db.select().from(db_1.supplierBanks).where((0, drizzle_orm_1.eq)(db_1.supplierBanks.supplierId, id)).all();
        const oldSupplier = { ...existingSupplier, bankAccounts: oldBanks };
        const updatedSupplier = await db_1.db.transaction(async (tx) => {
            let bAddrId = existingSupplier.billingAddressId;
            let sAddrId = existingSupplier.shippingAddressId;
            if (bAddr) {
                if (bAddrId) {
                    await tx.update(db_1.addresses).set(bAddr).where((0, drizzle_orm_1.eq)(db_1.addresses.id, bAddrId)).run();
                }
                else if (Object.keys(bAddr).length > 0) {
                    const addr = await tx.insert(db_1.addresses).values(bAddr).returning({ id: db_1.addresses.id }).get();
                    bAddrId = addr.id;
                }
            }
            if (sAddr) {
                if (sAddrId) {
                    await tx.update(db_1.addresses).set(sAddr).where((0, drizzle_orm_1.eq)(db_1.addresses.id, sAddrId)).run();
                }
                else if (Object.keys(sAddr).length > 0) {
                    const addr = await tx.insert(db_1.addresses).values(sAddr).returning({ id: db_1.addresses.id }).get();
                    sAddrId = addr.id;
                }
            }
            await tx
                .update(db_1.suppliers)
                .set({
                code: code ?? existingSupplier.code,
                name: name ?? existingSupplier.name,
                type: type ?? existingSupplier.type,
                gstin: gstin ?? existingSupplier.gstin,
                billingAddressId: bAddrId,
                shippingAddressId: sAddrId,
                notes: notes ?? existingSupplier.notes,
                isActive: typeof isActive === 'boolean' ? isActive : existingSupplier.isActive,
            })
                .where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id))
                .run();
            const bankAccounts = req.body.bankAccounts;
            if (Array.isArray(bankAccounts)) {
                await tx.delete(db_1.supplierBanks).where((0, drizzle_orm_1.eq)(db_1.supplierBanks.supplierId, id)).run();
                for (const bank of bankAccounts) {
                    const { id: bankId, ...bankData } = bank;
                    await tx.insert(db_1.supplierBanks).values({
                        ...bankData,
                        supplierId: id,
                    }).run();
                }
            }
            const finalSupplier = await tx.select().from(db_1.suppliers).where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id)).get();
            const finalBanks = await tx.select().from(db_1.supplierBanks).where((0, drizzle_orm_1.eq)(db_1.supplierBanks.supplierId, id)).all();
            return { ...finalSupplier, bankAccounts: finalBanks };
        });
        await (0, audit_service_1.auditLog)({
            action: 'UPDATE_SUPPLIER',
            entity: 'SUPPLIER',
            entityId: id,
            oldValue: oldSupplier,
            newValue: updatedSupplier,
        });
        logger_service_1.LogService.info('Supplier updated successfully', { supplierId: id, supplierName: updatedSupplier.name });
        res.json(updatedSupplier);
    }
    catch (err) {
        logger_service_1.LogService.error('Failed to update supplier', err, { supplierId: id });
        res.status(400).json({ error: 'Failed to update supplier' });
    }
});
exports.suppliersRouter.delete('/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const supplier = await db_1.db.select().from(db_1.suppliers).where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id)).get();
    if (!supplier) {
        logger_service_1.LogService.warn('Supplier not found for deletion', { supplierId: id });
        return res.status(404).json({
            error: req.i18n?.t('supplier.notFound') || 'Supplier not found',
        });
    }
    const bankAccounts = await db_1.db.select().from(db_1.supplierBanks).where((0, drizzle_orm_1.eq)(db_1.supplierBanks.supplierId, id)).all();
    await db_1.db.delete(db_1.suppliers).where((0, drizzle_orm_1.eq)(db_1.suppliers.id, id)).run();
    await (0, audit_service_1.auditLog)({
        action: 'DELETE_SUPPLIER',
        entity: 'SUPPLIER',
        entityId: id,
        oldValue: { ...supplier, bankAccounts },
    });
    logger_service_1.LogService.info('Supplier deleted successfully', { supplierId: id, supplierName: supplier.name });
    res.status(204).send();
});

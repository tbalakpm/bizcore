"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoicesRouter = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const express_1 = __importDefault(require("express"));
const db_1 = require("../db");
const serial_number_service_1 = require("../services/serial-number.service");
exports.invoicesRouter = express_1.default.Router();
exports.invoicesRouter.get('/stock', async (_req, res) => {
    const data = await db_1.db.select().from(db_1.stockInvoices).orderBy(db_1.stockInvoices.id).all();
    res.json({ data });
});
exports.invoicesRouter.get('/sales', async (_req, res) => {
    const data = await db_1.db.select().from(db_1.salesInvoices).orderBy(db_1.salesInvoices.id).all();
    res.json({ data });
});
exports.invoicesRouter.post('/stock', async (req, res) => {
    const { invoiceDate, totalQty, totalAmount } = req.body;
    const invoiceNumber = await serial_number_service_1.serialNumberService.generateInvoiceNumber('stockInvoice');
    const created = await db_1.db
        .insert(db_1.stockInvoices)
        .values({
        invoiceNumber,
        invoiceDate: invoiceDate || new Date().toISOString().slice(0, 10),
        totalQty: totalQty?.toString(),
        totalAmount: totalAmount?.toString(),
    })
        .returning()
        .get();
    res.status(201).json(created);
});
exports.invoicesRouter.post('/sales', async (req, res) => {
    const { invoiceDate, customerId, refNumber, refDate, totalQty, subtotal, discountType, discountPct, discountAmount, } = req.body;
    if (!customerId) {
        return res.status(400).json({ error: 'customerId is required' });
    }
    const invoiceNumber = await serial_number_service_1.serialNumberService.generateInvoiceNumber('salesInvoice');
    const created = await db_1.db
        .insert(db_1.salesInvoices)
        .values({
        invoiceNumber,
        invoiceDate: invoiceDate || new Date().toISOString().slice(0, 10),
        customerId,
        refNumber,
        refDate,
        totalQty: totalQty?.toString(),
        subtotal: subtotal?.toString(),
        discountType,
        discountPct: discountPct?.toString(),
        discountAmount: discountAmount?.toString(),
    })
        .returning()
        .get();
    res.status(201).json(created);
});
exports.invoicesRouter.get('/stock/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid stock invoice ID' });
    }
    const invoice = await db_1.db.select().from(db_1.stockInvoices).where((0, drizzle_orm_1.eq)(db_1.stockInvoices.id, id)).get();
    if (!invoice) {
        return res.status(404).json({ error: 'Stock invoice not found' });
    }
    return res.json(invoice);
});
exports.invoicesRouter.get('/sales/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ error: 'Invalid sales invoice ID' });
    }
    const invoice = await db_1.db.select().from(db_1.salesInvoices).where((0, drizzle_orm_1.eq)(db_1.salesInvoices.id, id)).get();
    if (!invoice) {
        return res.status(404).json({ error: 'Sales invoice not found' });
    }
    return res.json(invoice);
});

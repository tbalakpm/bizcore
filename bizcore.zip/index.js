"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = require("./app");
const logger_service_1 = require("./core/logger/logger.service");
/* ✅ Graceful shutdown */
const shutdown = (server) => {
    logger_service_1.LogService.info('🛑 Shutting down...');
    server.close(() => {
        logger_service_1.LogService.info('✅ Server closed');
        process.exit(0);
    });
};
(0, app_1.app)()
    .then(({ express, port }) => {
    const server = express.listen(port, () => {
        logger_service_1.LogService.info(`Server (api) listening on http://localhost:${port}`);
    });
    process.on('SIGINT', () => shutdown(server)); // Ctrl+C
    process.on('SIGTERM', () => shutdown(server)); // kill
})
    .catch((err) => {
    logger_service_1.LogService.error('Failed to start server:', err);
    process.exit(1);
});

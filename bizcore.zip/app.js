"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = app;
const node_path_1 = __importDefault(require("node:path"));
const cors_1 = __importDefault(require("cors"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const express_1 = __importDefault(require("express"));
const i18n_1 = require("./middleware/i18n");
const request_id_middleware_1 = require("./middleware/request-id.middleware");
const logger_service_1 = require("./core/logger/logger.service");
const config_1 = require("./config");
const db_1 = require("./db");
const admin_user_seed_1 = require("./db/seed/admin-user.seed");
const states_seed_1 = require("./db/seed/states.seed");
const tax_rate_seed_1 = require("./db/seed/tax-rate.seed");
const auth_1 = require("./routes/auth");
const categories_1 = require("./routes/categories");
const auth_2 = require("./middleware/auth");
const users_1 = require("./routes/users");
const products_1 = require("./routes/products");
const customers_1 = require("./routes/customers");
const logger_1 = require("./middleware/logger");
const suppliers_1 = require("./routes/suppliers");
const inventories_1 = require("./routes/inventories");
const settings_1 = require("./routes/settings");
const invoices_1 = require("./routes/invoices");
const serial_numbers_1 = require("./routes/serial-numbers");
const stock_invoices_1 = require("./routes/stock-invoices");
const sales_invoices_1 = require("./routes/sales-invoices");
const purchase_invoices_1 = require("./routes/purchase-invoices");
const gst_1 = require("./routes/gst");
const pricing_categories_1 = require("./routes/pricing-categories");
const dashboard_1 = require("./routes/dashboard");
const profile_1 = require("./routes/profile");
const attributes_1 = require("./routes/attributes");
const product_templates_1 = require("./routes/product-templates");
const brands_1 = require("./routes/brands");
const tax_rates_1 = require("./routes/tax-rates");
const tax_rules_1 = require("./routes/tax-rules");
const state_router_1 = __importDefault(require("./routes/state.router"));
async function app() {
    console.table(config_1.config);
    logger_service_1.LogService.info(`Starting BizCore API`, { environment: config_1.config.environment });
    await (0, db_1.initializeDatabase)();
    if (config_1.config.autoMigrateOnStartup) {
        await (0, db_1.migrateDatabase)();
    }
    await (0, admin_user_seed_1.createAdminUser)();
    await (0, states_seed_1.seedStates)();
    await (0, tax_rate_seed_1.seedTaxRates)();
    const app = (0, express_1.default)();
    app.use((0, cors_1.default)({
        origin: config_1.config.corsOrigins,
        methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization", "Accept-Language"],
        credentials: true,
    }));
    app.use((0, cookie_parser_1.default)());
    app.use(express_1.default.json());
    app.use(express_1.default.urlencoded({ extended: true }));
    app.use(request_id_middleware_1.requestContextMiddleware);
    app.use(logger_1.logger);
    app.use(i18n_1.i18nMiddleware);
    // Serve the static files from the Angular dist directory
    // Replace 'my-angular-app' with your actual project name from the dist folder
    app.use(express_1.default.static(node_path_1.default.join(__dirname, "/public")));
    app.get("/api/health", (req, res) => {
        res.json({
            status: "ok",
            username: req.user?.username || "",
            lang: req.i18n?.lang || "en",
        });
    });
    // Frontend log ingestion endpoint
    app.post("/api/logs", (req, res) => {
        const { level, message, data } = req.body;
        const safeLevel = ['info', 'warn', 'error', 'debug'].includes(level?.toLowerCase())
            ? level.toLowerCase()
            : 'info';
        logger_service_1.LogService[safeLevel](message, { source: 'frontend', ...(data ?? {}) });
        res.sendStatus(200);
    });
    app.use("/api/auth", auth_1.authRouter);
    app.use("/api/users", auth_2.authRequired, (0, auth_2.requireRole)("admin"), users_1.usersRouter);
    app.use("/api/categories", auth_2.authRequired, categories_1.categoriesRouter);
    app.use("/api/pricing-categories", auth_2.authRequired, pricing_categories_1.pricingCategoriesRouter);
    app.use("/api/products", auth_2.authRequired, products_1.productsRouter);
    app.use("/api/customers", auth_2.authRequired, customers_1.customersRouter);
    app.use("/api/suppliers", auth_2.authRequired, suppliers_1.suppliersRouter);
    app.use("/api/inventories", auth_2.authRequired, inventories_1.inventoriesRouter);
    app.use("/api/settings", auth_2.authRequired, (0, auth_2.requireRole)("admin"), settings_1.settingsRouter);
    app.use("/api/invoices", auth_2.authRequired, invoices_1.invoicesRouter);
    app.use("/api/stock-invoices", auth_2.authRequired, stock_invoices_1.stockInvoicesRouter);
    app.use("/api/sales-invoices", auth_2.authRequired, sales_invoices_1.salesInvoicesRouter);
    app.use("/api/purchase-invoices", auth_2.authRequired, purchase_invoices_1.purchaseInvoicesRouter);
    app.use("/api/serial-numbers", auth_2.authRequired, serial_numbers_1.serialNumbersRouter);
    app.use("/api/gst", auth_2.authRequired, gst_1.gstRouter);
    app.use("/api/dashboard", auth_2.authRequired, dashboard_1.dashboardRouter);
    app.use("/api/profile", auth_2.authRequired, profile_1.profileRouter);
    app.use("/api/attributes", auth_2.authRequired, attributes_1.attributesRouter);
    app.use("/api/product-templates", auth_2.authRequired, product_templates_1.productTemplatesRouter);
    app.use("/api/brands", auth_2.authRequired, brands_1.brandsRouter);
    app.use("/api/tax-rates", auth_2.authRequired, tax_rates_1.taxRatesRouter);
    app.use("/api/tax-rules", auth_2.authRequired, tax_rules_1.taxRulesRouter);
    app.use("/api/states", auth_2.authRequired, state_router_1.default);
    // Handle any requests that don't match the static files by serving the index.html file
    app.get("/{*any}", (req, res, next) => {
        if (req.url.startsWith("/api")) {
            return res.status(404).json({ message: `Url '${req.url}' not found` });
        }
        res.sendFile(node_path_1.default.join(__dirname, "/public/index.html"), (err) => {
            if (err) {
                next(err);
            }
        });
    });
    return { express: app, port: config_1.config.port };
}

"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRequired = authRequired;
exports.requireRole = requireRole;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../config");
const db_1 = require("../db");
const db_2 = require("../db");
const drizzle_orm_1 = require("drizzle-orm");
const request_context_1 = require("../core/logger/request-context");
const logger_service_1 = require("../core/logger/logger.service");
async function authRequired(req, res, next) {
    let token;
    const header = req.headers.authorization;
    if (header && header.startsWith('Bearer ')) {
        token = header.slice(7);
    }
    else if (req.query.token && typeof req.query.token === 'string') {
        // Fallback to query parameter for file downloads
        token = req.query.token;
    }
    if (!token) {
        return res.status(401).json({ error: req.i18n?.t('auth.required') });
    }
    try {
        const payload = jsonwebtoken_1.default.verify(token, config_1.config.jwtSecret);
        const user = await db_1.db
            .select({
            id: db_2.users.id,
            username: db_2.users.username,
            role: db_2.users.role,
            isActive: db_2.users.isActive,
            mustChangePassword: db_2.users.mustChangePassword,
        })
            .from(db_2.users)
            .where((0, drizzle_orm_1.eq)(db_2.users.id, parseInt(payload.sub, 10)))
            .get();
        if (!user || !user.isActive) {
            return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
        }
        if (user.mustChangePassword) {
            return res.status(403).json({ error: 'Password change required', code: 'MUST_CHANGE_PASSWORD' });
        }
        req.user = user;
        (0, request_context_1.setUserId)(user.id);
        next();
    }
    catch (err) {
        req.user = undefined;
        logger_service_1.LogService.error('Auth verification failed');
        return res.status(401).json({ error: req.i18n?.t('auth.invalid') });
    }
}
function requireRole(...allowedRoles) {
    return (req, res, next) => {
        const role = req.user?.role;
        if (!role || !allowedRoles.some((allowedRole) => allowedRole === role)) {
            return res.status(403).json({ error: req.i18n?.t('auth.forbidden') || 'Forbidden' });
        }
        next();
    };
}

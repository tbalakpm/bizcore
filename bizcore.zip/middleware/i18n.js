"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.i18nMiddleware = i18nMiddleware;
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const config_1 = require("../config");
const translations = {};
for (const lang of config_1.config.supportedLangs) {
    const filePath = node_path_1.default.join(__dirname, '..', 'i18n', `${lang}.json`);
    translations[lang] = JSON.parse(node_fs_1.default.readFileSync(filePath, 'utf8'));
}
function i18nMiddleware(req, _res, next) {
    const headerLang = req.headers['accept-language'];
    let lang = config_1.config.defaultLang;
    if (headerLang) {
        const short = headerLang.split(',')[0].split('-')[0];
        if (config_1.config.supportedLangs.includes(short))
            lang = short;
    }
    // req.i118n.lang = lang;
    req.i18n = {
        lang,
        locale: lang, // for compatibility
        t: (key) => translations[lang][key] || translations[config_1.config.defaultLang][key] || key,
    };
    next();
}

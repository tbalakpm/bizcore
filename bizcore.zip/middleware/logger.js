"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = logger;
const logger_service_1 = require("../core/logger/logger.service");
function logger(req, res, next) {
    try {
        const url = (Array.isArray(req.url) ? req.url.join(', ') : req.url);
        const startTime = Date.now();
        const method = req.method;
        const ip = req.ip || 'unknown';
        // Hook into response to capture size and timing
        const originalSend = res.send;
        res.send = function (data) {
            const responseSize = JSON.stringify(data || {}).length || 0;
            const timeTaken = Date.now() - startTime;
            const statusCode = res.statusCode;
            const meta = { method, url, ip, statusCode, timeTaken, responseSize };
            if (statusCode >= 500) {
                logger_service_1.LogService.error(`${method} ${url} - ${statusCode} [${timeTaken}ms, ${responseSize}B]`, undefined, meta);
            }
            else if (statusCode >= 400) {
                logger_service_1.LogService.warn(`${method} ${url} - ${statusCode} [${timeTaken}ms, ${responseSize}B]`, meta);
            }
            else {
                logger_service_1.LogService.info(`${method} ${url} - ${statusCode} [${timeTaken}ms, ${responseSize}B]`, meta);
            }
            return originalSend.call(this, data);
        };
        next();
    }
    catch (err) {
        const url = Array.isArray(req.url) ? req.url.join(', ') : req.url;
        logger_service_1.LogService.error(`${req.method} ${url} – middleware error`, err);
        next();
    }
}

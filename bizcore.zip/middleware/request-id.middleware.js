"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestContextMiddleware = requestContextMiddleware;
const uuid_1 = require("uuid");
const request_context_1 = require("../core/logger/request-context");
/**
 * Middleware that creates an AsyncLocalStorage context per request.
 * Populates requestId (from header or generated UUID) and userId from JWT auth.
 *
 * Must be registered BEFORE the main logger middleware.
 */
function requestContextMiddleware(req, _res, next) {
    const requestId = req.headers['x-request-id'] || (0, uuid_1.v4)();
    const userId = req.user?.id ?? null;
    request_context_1.asyncLocalStorage.run({ requestId, userId }, () => next());
}

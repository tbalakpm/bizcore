"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyPassword = exports.hashPassword = exports.isStrongPassword = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const isStrongPassword = (password) => {
    if (password.length < 8) {
        return false;
    }
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasDigit = /\d/.test(password);
    return hasUpper && hasLower && hasDigit;
};
exports.isStrongPassword = isStrongPassword;
const hashPassword = async (password) => {
    return await bcryptjs_1.default.hash(password, 10);
    // return Bun.password.hash(password, {
    //   algorithm: "bcrypt",
    //   cost: 10,
    // });
};
exports.hashPassword = hashPassword;
const verifyPassword = async (password, hash) => {
    return await bcryptjs_1.default.compare(password, hash);
};
exports.verifyPassword = verifyPassword;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateGtn = exports.shouldGenerateGtn = void 0;
const shouldGenerateGtn = (gtnGeneration) => {
    if (!gtnGeneration) {
        return false;
    }
    const mode = gtnGeneration.trim().toLowerCase();
    if (!mode) {
        return false;
    }
    return !['manual', 'none', 'off', 'false', 'no'].includes(mode);
};
exports.shouldGenerateGtn = shouldGenerateGtn;
const generateGtn = (productCode) => {
    const prefix = (productCode || 'GTN').toUpperCase().slice(0, 10);
    const time = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 10000)
        .toString()
        .padStart(4, '0');
    return `${prefix}-${time}${random}`;
};
exports.generateGtn = generateGtn;

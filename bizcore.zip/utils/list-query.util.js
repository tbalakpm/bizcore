"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveSortDirection = exports.toPagination = exports.parsePagination = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const parsePagination = (query) => {
    const limit = Math.min(parseInt(query.limit || '10', 10) || 10, 100);
    const offsetParam = query.offset;
    const pageParam = query.pageNum ?? query.page;
    const pageNumRaw = pageParam ? parseInt(pageParam, 10) : NaN;
    const pageNum = Number.isFinite(pageNumRaw) && pageNumRaw > 0 ? pageNumRaw : undefined;
    const offset = offsetParam ? Math.max(parseInt(offsetParam, 10) || 0, 0) : Math.max(((pageNum ?? 1) - 1) * limit, 0);
    return { limit, offset, pageNum };
};
exports.parsePagination = parsePagination;
const toPagination = (limit, offset, total, pageNum) => ({
    limit,
    offset,
    total,
    page: pageNum ?? Math.floor(offset / limit) + 1,
    totalPages: Math.ceil(total / limit),
});
exports.toPagination = toPagination;
const resolveSortDirection = (direction) => (direction?.toLowerCase() === 'desc' ? drizzle_orm_1.desc : drizzle_orm_1.asc);
exports.resolveSortDirection = resolveSortDirection;

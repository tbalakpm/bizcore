"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeDate = void 0;
exports.getLocalYYYYMMDD = getLocalYYYYMMDD;
exports.isValidDateString = isValidDateString;
function getLocalYYYYMMDD(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function isValidDateString(s) {
    return /^\d{4}-\d{2}-\d{2}$/.test(s);
}
const normalizeDate = (date) => {
    if (!date) {
        return new Date().toISOString().slice(0, 10);
    }
    return date;
};
exports.normalizeDate = normalizeDate;

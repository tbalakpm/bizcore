"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toPositiveNumber = exports.toOptionalNumber = exports.toNumber = exports.toNumericString = void 0;
const toNumericString = (value) => {
    if (value === undefined || value === null || value === '') {
        return undefined;
    }
    const num = typeof value === 'number' ? value : Number(value);
    if (Number.isNaN(num)) {
        return undefined;
    }
    return num.toString();
};
exports.toNumericString = toNumericString;
const toNumber = (value, fallback = 0) => {
    const num = typeof value === 'number' ? value : Number(value);
    return Number.isNaN(num) ? fallback : num;
};
exports.toNumber = toNumber;
const toOptionalNumber = (value) => {
    if (value === undefined || value === null || value === '') {
        return undefined;
    }
    const num = typeof value === 'number' ? value : Number(value);
    return Number.isNaN(num) ? undefined : num;
};
exports.toOptionalNumber = toOptionalNumber;
const toPositiveNumber = (value, fallback) => {
    const num = typeof value === 'number' ? value : Number(value);
    if (Number.isNaN(num) || num <= 0) {
        return fallback;
    }
    return num;
};
exports.toPositiveNumber = toPositiveNumber;
